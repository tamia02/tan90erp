# Space 03 Role & Permission Matrix

| Capability | Super Admin | Product Engineering Head | R&D Manager | QA Manager | Costing Manager | Product Engineer | R&D Executive | QA Executive | Costing Executive |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| View cockpit and product portfolio | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Create/edit product master | ✓ | ✓ | ✓ | View | View | ✓ assigned | View | View | View |
| Create/edit recipe version | ✓ | ✓ | ✓ | View | View | ✓ assigned | ✓ assigned | View | View |
| Approve/release recipe | ✓ | ✓ | Scoped | QA gate | Cost gate | — | — | — | — |
| Create/edit BOM | ✓ | ✓ | View | View | View | ✓ assigned | View | View | View |
| Approve/release BOM | ✓ | ✓ | Scoped | QA gate | Cost gate | — | — | — | — |
| Create/edit routing | ✓ | ✓ | View | View | View | ✓ assigned | — | View | View |
| Create/edit quality spec | ✓ | ✓ | View | ✓ | View | View | View | ✓ assigned | View |
| Manage temperature profile | ✓ | ✓ | Scoped | ✓ | View | View | ✓ assigned | ✓ assigned | View |
| Run cost simulation | ✓ | ✓ | View | View | ✓ | View | — | — | ✓ assigned |
| Publish standard cost | ✓ | ✓ | — | — | ✓ | — | — | — | — |
| Create ECO | ✓ | ✓ | ✓ | View | View | ✓ assigned | — | — | — |
| Approve/release ECO | ✓ | ✓ | Scoped | QA gate | Cost gate | — | — | — | — |
| Resolve data-quality issues | ✓ | ✓ | Scoped | Scoped | Scoped | Assigned | Assigned | Assigned | Assigned |
| Grant direct user permission | ✓ | Configurable | Delegable ceiling | Delegable ceiling | Delegable ceiling | — | — | — | — |
| View audit | ✓ | ✓ | ✓ | ✓ | ✓ | Scoped | Scoped | Scoped | Scoped |

## Permission dimensions

- Module and page
- View/create/edit/submit/approve/release/archive/export
- Field visibility and editability
- Product family, plant, item class and assigned-record scope
- Delegable ceiling
- Direct user allow/deny
- Temporary expiry and business reason
- Audit and access simulation
