# Tan90 Space 03 — Blueprint

## Product Engineering & Masters Interactive MVP

Blueprint is the authoritative product-definition space for the Tan90 Manufacturing ERP. It bundles product and material masters, formula/recipe management, multi-level BOMs, routings/work centres, quality specifications, temperature profiles, costing, engineering changes, data quality, approvals and audit into one connected workspace.

## Run

- Open `index.html` directly, or
- Windows: run `RUN-WINDOWS.bat`
- macOS/Linux: run `./RUN-MAC-LINUX.sh`, then visit `http://localhost:8083`

All prototype changes are stored in browser local storage. Use a private browser window to start with clean demo data.

## Demo hierarchy

Password displayed for presentation: `demo123`.

- Level 1 — Super Administrator
- Level 2 — Head of Product Engineering
- Level 3 — R&D/Recipe Manager, Quality Engineering Manager, Costing Manager
- Level 4 — Product Engineer, R&D Lab Executive, Quality Specification Executive, Costing Executive

Each persona has different actions and data scope. Access is evaluated from role permissions plus specific-user allow/deny overrides.

## Included modules and working functions

1. **Engineering Cockpit** — portfolio readiness, release gates, approval pressure, open data risks and engineering activity.
2. **Master Catalog** — items/SKUs, materials, vendors, customers, machines/work centres, UOM/conversions and taxonomy.
3. **Product 360** — complete product dossier, linked effective versions, release gates, where-used and downstream consumption.
4. **Recipe Studio** — drag/drop ingredients, scaling, yield, loss, process parameters, version clone and approval submission.
5. **BOM Studio** — drag/drop components, quantities, UOM, scrap, alternates, by-product recovery, where-used and MRP checks.
6. **Routing Studio** — drag/drop and reorder operations, work centres, machines, setup/cycle times, QC checkpoints and capacity preview.
7. **Quality & Temperature** — test methods, acceptance ranges, sampling plans, release gates and time-temperature profiles.
8. **Costing Lab** — material and conversion rollup, rate master, scenarios, annual impact, saved simulations and standard-cost publication.
9. **Engineering Change Control** — ECO board, impact analysis, effectivity and cross-space change scope.
10. **Data Quality & Import** — quality score, validation rules, issue resolution and staged bulk import simulation.
11. **Approvals & Audit** — maker-checker actions, release-gate model and immutable activity timeline.
12. **Space Access Control** — role matrix, hierarchy, direct grants, expiry, reason and access simulator.
13. **Space Connectivity** — published objects, domain events, inbound dependencies and full product lifecycle.

## Important boundary

This package is a complete interactive frontend MVP and client visualisation. It does not claim production authentication, database transactions, server-side policy enforcement, queues, API integrations or Laravel persistence. Those implementation boundaries are documented in `ARCHITECTURE.md`.
