# Research Basis

## Existing Tan90 blueprint

The current Tan90 public prototype describes a cold-chain ERP centred on batch inventory, BOM/MRP, work orders, QC, machine usage, warehouse, logistics, vendor manufacturing and dashboards. Its stated core operational flow is demand → planning → material → production → QC → warehouse → dispatch → closure → reports.

## Uploaded repository findings

The uploaded Laravel repository already contains a deep Product Engineering and Master Data foundation, including models and migrations for:

- Items, categories, UOM and conversions
- Vendors, customers, plants, warehouses and machines
- Finished goods and components
- Recipes, versions and lines
- BOMs, versions and lines
- Work centres, routings and operations
- Process parameters and quality specifications
- Temperature profiles
- Alternate components and substitution rules
- Yield, co-products, by-products and scrap recovery
- Cost rates, sheets, rollups, simulations and variances
- Engineering Change Orders and impact records
- Release gates, approvals, audit and sync jobs

Space 03 therefore does not invent a parallel data model. It visualises and rationalises those capabilities into one clear client-facing engineering workspace.

## Business requirement basis

The supplied requirements define Tan90 as an end-to-end manufacturing ERP covering product/SKU masters, BOM/material planning, production, QC, machine usage, wastage, warehouse and dispatch. Product engineering is the required upstream definition layer for these transactions.

## Design decision

Recipe and BOM remain separate but connected:

- Recipe defines formula/process composition and scaling.
- BOM defines discrete physical components and packaging structure.
- Routing defines how and where the product is made.
- Quality and temperature define the acceptance envelope.
- Costing converts the released definition into a commercial baseline.
- ECO controls every subsequent change.
