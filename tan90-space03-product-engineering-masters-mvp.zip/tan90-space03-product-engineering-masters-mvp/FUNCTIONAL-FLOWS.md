# Space 03 Functional Flows

## 1. New product introduction

```
Requirement / opportunity
→ Product master and revision
→ Recipe and/or BOM
→ Routing and process parameters
→ Quality specification
→ Temperature qualification
→ Cost rollup
→ Cross-functional approval
→ Released effective definition
→ Available to MRP and operations
```

## 2. Recipe development

```
Create recipe version
→ Add ingredients and stages
→ Scale formula
→ Define process parameters
→ Record trial yield/evidence
→ Validate totals and approved materials
→ R&D review
→ QA and costing review
→ Release version
```

## 3. BOM development

```
Create BOM version
→ Drag components into structure
→ Set quantity/UOM/scrap
→ Define alternates/substitution
→ Add by-product recovery
→ Validate recursion/UOM/effectivity
→ Cost impact
→ Approve and release
```

## 4. Routing development

```
Create routing
→ Sequence operations
→ Assign work centre/machine
→ Define setup and cycle time
→ Add critical process parameters
→ Attach in-process QC checkpoint
→ Capacity and calibration check
→ Approve and release
```

## 5. Quality and temperature definition

```
Create specification
→ Select inspection stage
→ Add parameter/test method
→ Set lower/upper limit and UOM
→ Define sampling plan
→ Link instruments/evidence
→ Link qualification profile
→ QA approval and release
```

## 6. Standard costing

```
Released BOM + material rates
+ Released routing + labour/machine rates
+ Overhead rules
− By-product recovery
→ Cost rollup
→ Scenario analysis
→ Finance approval
→ Effective standard cost
```

## 7. Engineering change

```
Problem/opportunity
→ ECO draft
→ Identify affected products
→ Impact recipe/BOM/routing/spec/cost
→ Check inventory, MRP, work orders and validation
→ Define effectivity
→ Complete approvals/evidence
→ Release new versions
→ Notify connected spaces
```

## 8. Bulk master import

```
Upload
→ Column mapping
→ Required/reference/duplicate validation
→ Preview creates/updates/rejects
→ Maker-checker approval
→ Apply versioned changes
→ Audit evidence and issue queue
```
