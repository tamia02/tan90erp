@echo off
start "Tan90 Blueprint" http://localhost:8083
python -m http.server 8083
