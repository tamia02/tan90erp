# Space 03 Architecture — Product Engineering & Masters

## Purpose

Blueprint creates the controlled digital definition used by planning, procurement, production, quality, warehouse, logistics, finance and traceability. Downstream modules reference exact released versions instead of copying product rules.

## Bundled domain modules

### A. Master Data Foundation

- Legal product identity, item/SKU, material/component
- Category/taxonomy, UOM and conversions
- Vendor/customer references
- Machine, work centre and capability
- Temperature class and common quality parameter
- Number series, documents, attachments and ownership

### B. Product Engineering

- Product revision
- Recipe/formula and recipe version
- BOM and BOM version
- Routing and routing operation
- Process parameters
- Alternate components and substitution rules
- Yield, co-product, by-product and scrap recovery

### C. Quality by Design

- Quality specifications and test methods
- Acceptance limits and sampling plan
- Incoming, in-process, final and validation stages
- Temperature profile and qualification envelope
- Release gates and evidence

### D. Commercial Engineering

- Material master rate
- Labour/machine/overhead rate
- Cost sheet, rollup and simulation
- Standard cost publication
- Change-driven cost variance

### E. Change and Governance

- Engineering Change Order
- Change impact
- Effectivity by date, plant, batch or serial range
- Approval workflow and gate decisions
- Immutable audit and version snapshots
- Data-quality rules and staged import

## Suggested Laravel bounded context

```
app/Domain/Blueprint/
  Masters/
  Products/
  Recipes/
  Boms/
  Routings/
  QualitySpecs/
  TemperatureProfiles/
  Costing/
  EngineeringChanges/
  DataGovernance/
  Approvals/
```

Use existing Tan90 master and BomRecipeCosting models as the migration base. Do not duplicate `Item`, `Recipe`, `Bom`, `Routing`, `QualitySpec`, `TemperatureProfile`, `CostSheet`, `EngineeringChangeOrder` or their version models.

## Version/effectivity rule

Operational records must retain immutable references such as:

- `product_revision_id`
- `recipe_version_id`
- `bom_version_id`
- `routing_version_id`
- `quality_spec_version_id`
- `temperature_profile_id`
- `standard_cost_version_id`

Updating a current master must never silently change an already released work order, batch or shipment.

## Release state model

```
Draft → Review → Approved → Released → Superseded → Archived
```

Drafts are editable. Released records are immutable. A change creates a new version and an ECO when operational impact exists.

## Cross-space contracts

### Inputs

- Nexus: user identity, role, hierarchy, plant/team scope
- Origin: source qualification and vendor/material feedback
- Forge: actual yield, cycle, scrap and process capability
- Flow: handling, packaging and delivery performance
- Lens: actual cost, genealogy and variance

### Outputs

- Product revision released
- Recipe version approved
- BOM version approved
- Routing released
- Quality specification released
- Temperature profile qualified
- Standard cost published
- Engineering change effective

## Authorization

Use hierarchical RBAC plus contextual scope:

1. Account must be active.
2. Explicit direct deny wins.
3. Inherited or role deny wins.
4. Valid direct allow may grant within delegation ceiling.
5. Role allow is evaluated.
6. Entity, plant, family, product and assigned-record scope is evaluated.
7. Default deny.

The browser UI is never the enforcement boundary. Laravel policies/gates or a central authorization service must re-evaluate every route, API and business action.

## Event examples

- `ProductRevisionReleased`
- `RecipeVersionApproved`
- `BomVersionApproved`
- `RoutingReleased`
- `QualitySpecReleased`
- `StandardCostPublished`
- `EngineeringChangeEffective`

## Primary integration principle

Blueprint owns definitions; operational spaces own transactions. For example, Blueprint owns the released BOM, while Forge owns the work-order material requirement snapshot generated from it.
