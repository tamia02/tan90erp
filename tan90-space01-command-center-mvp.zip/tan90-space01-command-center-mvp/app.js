'use strict';

/* Tan90 Space 01 — Command Center & My Work
   Standalone frontend MVP. All state is stored locally in the browser. */

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const clone = (value) => JSON.parse(JSON.stringify(value));
const uid = (prefix = 'id') => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
const escapeHtml = (value = '') => String(value).replace(/[&<>'"]/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[char]));
const humanDate = (value) => {
  if (!value) return '—';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString('en-IN', {day:'2-digit', month:'short', year:'numeric'});
};
const humanTime = (value) => {
  if (!value) return '—';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString('en-IN', {day:'2-digit', month:'short', hour:'2-digit', minute:'2-digit'});
};

const ICON_PATHS = {
  grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  home: '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v10h13V10"/><path d="M9.5 20v-6h5v6"/>',
  task: '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/><path d="m7 8 .1.1"/>',
  check: '<path d="m5 12 4 4L19 6"/>',
  approvals: '<path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>',
  alert: '<path d="M10.3 3.7 2.4 17.1A2 2 0 0 0 4.1 20h15.8a2 2 0 0 0 1.7-2.9L13.7 3.7a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4M12 17h.01"/>',
  builder: '<path d="M12 3v18M3 12h18"/><rect x="3" y="3" width="6" height="6" rx="1"/><rect x="15" y="15" width="6" height="6" rx="1"/>',
  roles: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
  users: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/>',
  audit: '<path d="M3 3v5h5"/><path d="M3.1 13a9 9 0 1 0 2.1-6.2L3 8"/><path d="M12 7v5l3 2"/>',
  simulator: '<path d="M4 20V10M9 20V4M14 20v-7M19 20V7"/><path d="M2 20h20"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
  bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/>',
  moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8Z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/>',
  chevron: '<path d="m9 18 6-6-6-6"/>',
  down: '<path d="m6 9 6 6 6-6"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  close: '<path d="M18 6 6 18M6 6l12 12"/>',
  more: '<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
  edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z"/>',
  trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 15H6L5 6M10 11v6M14 11v6"/>',
  copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  lock: '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
  unlock: '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 7.5-2"/>',
  filter: '<path d="M4 4h16l-6 7v6l-4 2v-8Z"/>',
  download: '<path d="M12 3v12M7 10l5 5 5-5"/><path d="M5 21h14"/>',
  upload: '<path d="M12 21V9M7 14l5-5 5 5"/><path d="M5 3h14"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6V21h-4v-.1a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H3v-4h.1a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3V3h4v.1a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.1v4H21a1.7 1.7 0 0 0-1.6 1Z"/>',
  factory: '<path d="M3 21V9l6 3V9l6 3V5h6v16Z"/><path d="M7 17h2M12 17h2M17 17h2"/>',
  quality: '<path d="M9 12l2 2 4-4"/><circle cx="12" cy="12" r="9"/>',
  stock: '<path d="m21 8-9 5-9-5 9-5Z"/><path d="m3 8 9 5 9-5M3 12l9 5 9-5M3 16l9 5 9-5"/>',
  truck: '<path d="M3 6h11v10H3zM14 10h4l3 3v3h-7z"/><circle cx="7" cy="18" r="2"/><circle cx="18" cy="18" r="2"/>',
  waste: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 15H6L5 6"/><path d="M10 10v7M14 10v7"/>',
  machine: '<rect x="3" y="6" width="18" height="14" rx="2"/><path d="M7 10h4M7 14h10M7 18h6M16 3v3M8 3v3"/>',
  chart: '<path d="M3 3v18h18"/><path d="m7 16 4-5 4 3 5-7"/>',
  activity: '<path d="M3 12h4l2-7 4 14 2-7h6"/>',
  flow: '<circle cx="5" cy="6" r="2"/><circle cx="19" cy="18" r="2"/><path d="M7 6h5a4 4 0 0 1 4 4v0a4 4 0 0 0 4 4h-1M5 8v8a2 2 0 0 0 2 2h10"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
  userPlus: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M16 11h6"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="m11 12 8-8 2 2-2 2 2 2-2 2-2-2-4 4"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
  phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.9a2 2 0 0 1-.5 2.1L8 10a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.5c.9.3 1.9.6 2.9.7a2 2 0 0 1 1.7 2Z"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
  map: '<path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3Z"/><path d="M9 3v15M15 6v15"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
  arrowRight: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  grip: '<circle cx="9" cy="5" r="1"/><circle cx="15" cy="5" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="9" cy="19" r="1"/><circle cx="15" cy="19" r="1"/>',
  undo: '<path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 6 6v1"/>',
  redo: '<path d="m15 14 5-5-5-5"/><path d="M20 9H10a6 6 0 0 0-6 6v1"/>',
  desktop: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>',
  tablet: '<rect x="5" y="2" width="14" height="20" rx="2"/><path d="M12 18h.01"/>',
  mobile: '<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M12 18h.01"/>',
  save: '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2Z"/><path d="M17 21v-8H7v8M7 3v5h8"/>',
  publish: '<path d="M12 2v14M7 7l5-5 5 5"/><path d="M5 22h14"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  logout: '<path d="M10 17l5-5-5-5M15 12H3"/><path d="M21 19V5a2 2 0 0 0-2-2h-6"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13"/><path d="M3 6h.01M3 12h.01M3 18h.01"/>',
  board: '<rect x="3" y="3" width="7" height="18" rx="1"/><rect x="14" y="3" width="7" height="10" rx="1"/><rect x="14" y="16" width="7" height="5" rx="1"/>',
  refresh: '<path d="M20 6v5h-5"/><path d="M4 18v-5h5"/><path d="M18.5 9A7 7 0 0 0 6 6.5L4 8M5.5 15A7 7 0 0 0 18 17.5l2-1.5"/>',
  columns: '<rect x="3" y="4" width="7" height="16" rx="1"/><rect x="14" y="4" width="7" height="16" rx="1"/>',
  tag: '<path d="M20.6 13.6 11 4H4v7l9.6 9.6a2 2 0 0 0 2.8 0l4.2-4.2a2 2 0 0 0 0-2.8Z"/><circle cx="7.5" cy="7.5" r=".5"/>',
  play: '<circle cx="12" cy="12" r="9"/><path d="m10 8 6 4-6 4Z"/>'
};

function icon(name, size = 18) {
  return `<svg aria-hidden="true" viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${ICON_PATHS[name] || ICON_PATHS.grid}</svg>`;
}

const permissionCatalog = [
  {group:'Dashboard', code:'space.dashboard.view', name:'View Command Center', description:'Open role-aware cockpit and authorised widgets'},
  {group:'Dashboard', code:'space.dashboard.drilldown', name:'Use KPI drilldowns', description:'Open plant, SKU, batch, machine and warehouse details'},
  {group:'Dashboard', code:'space.dashboard.saved_view', name:'Manage saved views', description:'Save filters, columns and queue layouts'},
  {group:'Work', code:'space.tasks.view', name:'View task queue', description:'View authorised work assigned to self or team'},
  {group:'Work', code:'space.tasks.claim', name:'Claim unassigned task', description:'Take ownership of an eligible task'},
  {group:'Work', code:'space.tasks.update', name:'Update task progress', description:'Add notes, evidence and change in-progress state'},
  {group:'Work', code:'space.tasks.complete', name:'Complete operational task', description:'Post GRN, complete inspection, issue material or close POD'},
  {group:'Work', code:'space.tasks.reassign', name:'Reassign task', description:'Move task to another authorised employee'},
  {group:'Approvals', code:'space.approvals.view', name:'View approvals', description:'Access approval queue within assigned scope'},
  {group:'Approvals', code:'space.approvals.approve', name:'Approve request', description:'Approve within configured amount and process limits'},
  {group:'Approvals', code:'space.approvals.reject', name:'Reject request', description:'Reject with mandatory reason'},
  {group:'Approvals', code:'space.approvals.return', name:'Return for correction', description:'Send request back to originator'},
  {group:'Exceptions', code:'space.exceptions.view', name:'View exceptions', description:'See shortage, delay, quality, wastage and downtime alerts'},
  {group:'Exceptions', code:'space.exceptions.ack', name:'Acknowledge exception', description:'Confirm that an exception is being handled'},
  {group:'Exceptions', code:'space.exceptions.assign', name:'Assign exception', description:'Assign an exception owner and target time'},
  {group:'Exceptions', code:'space.exceptions.resolve', name:'Resolve exception', description:'Close exception with root cause and resolution evidence'},
  {group:'Builder', code:'space.builder.personal', name:'Customise personal dashboard', description:'Reorder and resize unlocked personal widgets'},
  {group:'Builder', code:'space.builder.team', name:'Build team dashboard', description:'Create defaults for managed team members'},
  {group:'Builder', code:'space.builder.role', name:'Build role dashboard', description:'Publish a template for a subordinate role'},
  {group:'Builder', code:'space.builder.org', name:'Build organisation dashboard', description:'Publish organisation-wide dashboard baseline'},
  {group:'Builder', code:'space.builder.publish', name:'Publish dashboard', description:'Publish draft layouts to target users'},
  {group:'Builder', code:'space.builder.lock', name:'Lock widget properties', description:'Lock visibility, position, size or configuration'},
  {group:'Access', code:'space.roles.view', name:'View roles', description:'Review roles and effective access'},
  {group:'Access', code:'space.roles.manage', name:'Manage subordinate roles', description:'Create and update roles below own hierarchy level'},
  {group:'Access', code:'space.roles.delegate', name:'Delegate permissions', description:'Mark permissions that subordinate managers may grant'},
  {group:'Access', code:'space.users.view', name:'View users', description:'View users within authorised hierarchy and scope'},
  {group:'Access', code:'space.users.manage', name:'Manage subordinate users', description:'Create, activate, transfer and assign roles'},
  {group:'Access', code:'space.users.direct_grant', name:'Grant user-specific access', description:'Add temporary allow or deny directly to a subordinate'},
  {group:'Governance', code:'space.audit.view', name:'View activity and audit', description:'View task, approval and access changes'},
  {group:'Governance', code:'space.audit.export', name:'Export audit', description:'Download authorised audit records'},
  {group:'Governance', code:'space.simulator.view', name:'Use access simulator', description:'Explain why a user is allowed or denied'},
  {group:'Governance', code:'space.export', name:'Export operational data', description:'Export current authorised queue or report'},
  {group:'Fields', code:'field.financial_value.view', name:'View financial values', description:'View PO, invoice, claim and cost values'},
  {group:'Fields', code:'field.vendor_contact.view', name:'View vendor contact', description:'View vendor phone and email'},
  {group:'Fields', code:'field.internal_notes.view', name:'View internal notes', description:'View confidential management and QA notes'}
];

const widgetCatalog = [
  {id:'production', name:'Today Production', category:'Operations', icon:'factory', color:'#0fbd8c', soft:'#e7fbf4', permission:'widget.production.view', defaultSpan:3, description:'Output, target and shift progress'},
  {id:'pendingQc', name:'Pending QC', category:'Quality', icon:'quality', color:'#7857e8', soft:'#f1edff', permission:'widget.qc.view', defaultSpan:3, description:'Incoming, in-process and final inspections'},
  {id:'lowStock', name:'Low Stock', category:'Inventory', icon:'stock', color:'#e99a18', soft:'#fff6df', permission:'widget.stock.view', defaultSpan:3, description:'Critical materials and shortage risk'},
  {id:'dispatch', name:'Dispatch Closure', category:'Logistics', icon:'truck', color:'#2979ff', soft:'#eaf2ff', permission:'widget.dispatch.view', defaultSpan:3, description:'POD and shipment closure rate'},
  {id:'wastage', name:'Wastage', category:'Production', icon:'waste', color:'#df5062', soft:'#fff0f2', permission:'widget.wastage.view', defaultSpan:3, description:'Shift wastage and top reasons'},
  {id:'machine', name:'Machine Utilisation', category:'Production', icon:'machine', color:'#14a3b8', soft:'#e8f9fb', permission:'widget.machine.view', defaultSpan:3, description:'Runtime, downtime and availability'},
  {id:'productionTrend', name:'Production Trend', category:'Operations', icon:'chart', color:'#0fbd8c', soft:'#e7fbf4', permission:'widget.production.view', defaultSpan:8, description:'Target vs actual output'},
  {id:'myTasks', name:'My Task Queue', category:'Personal', icon:'task', color:'#2979ff', soft:'#eaf2ff', permission:'space.tasks.view', defaultSpan:4, description:'Priority work requiring action'},
  {id:'approvalQueue', name:'Approval Queue', category:'Governance', icon:'approvals', color:'#7857e8', soft:'#f1edff', permission:'space.approvals.view', defaultSpan:6, description:'Requests waiting for approval'},
  {id:'exceptions', name:'Exception Radar', category:'Governance', icon:'alert', color:'#df5062', soft:'#fff0f2', permission:'space.exceptions.view', defaultSpan:6, description:'Operational risks and SLA breaches'},
  {id:'processFlow', name:'E2E Flow Readiness', category:'Operations', icon:'flow', color:'#14a3b8', soft:'#e8f9fb', permission:'space.dashboard.view', defaultSpan:6, description:'Inbound to dispatch process health'},
  {id:'unitPerformance', name:'Unit Performance', category:'Management', icon:'chart', color:'#2979ff', soft:'#eaf2ff', permission:'space.dashboard.drilldown', defaultSpan:6, description:'Plant output and quality comparison'},
  {id:'activity', name:'Live Activity', category:'Governance', icon:'activity', color:'#0fbd8c', soft:'#e7fbf4', permission:'space.audit.view', defaultSpan:4, description:'Latest operational actions'},
  {id:'quickActions', name:'Quick Actions', category:'Personal', icon:'plus', color:'#0fbd8c', soft:'#e7fbf4', permission:'space.tasks.update', defaultSpan:4, description:'Start common authorised workflows'},
  {id:'sla', name:'SLA Performance', category:'Management', icon:'calendar', color:'#e99a18', soft:'#fff6df', permission:'space.dashboard.drilldown', defaultSpan:4, description:'On-time task and approval completion'}
];

const widgetPermissionCodes = [...new Set(widgetCatalog.map((w) => w.permission).filter((p) => p.startsWith('widget.')))];
widgetPermissionCodes.forEach((code) => {
  if (!permissionCatalog.some((item) => item.code === code)) {
    const widget = widgetCatalog.find((item) => item.permission === code);
    permissionCatalog.push({group:'Widgets', code, name:`View ${widget.name} widget`, description:`Display ${widget.name} data in dashboards`});
  }
});

const rolesSeed = [
  {
    id:'role-super-admin', name:'Super Admin', label:'Level 1 · Organisation', level:1, parentId:null, color:'#0fbd8c', soft:'#e7fbf4',
    description:'Controls Space 01 across every unit, hierarchy, role, user and dashboard.', scope:{type:'all', values:['All Units']},
    allow:['*'], deny:[], delegate:['*'], widgetIds:widgetCatalog.map((w) => w.id),
    dashboardRights:{personal:true, team:true, role:true, org:true, publish:true, lock:true}
  },
  {
    id:'role-operations-manager', name:'Operations Manager', label:'Level 2 · Vertical / Plant', level:2, parentId:'role-super-admin', color:'#2979ff', soft:'#eaf2ff',
    description:'Controls plant operations, team workload, approvals, exceptions and subordinate access.', scope:{type:'plant', values:['Bangalore Unit']},
    allow:[
      'space.dashboard.view','space.dashboard.drilldown','space.dashboard.saved_view','space.tasks.view','space.tasks.claim','space.tasks.update','space.tasks.complete','space.tasks.reassign',
      'space.approvals.view','space.approvals.approve','space.approvals.reject','space.approvals.return','space.exceptions.view','space.exceptions.ack','space.exceptions.assign','space.exceptions.resolve',
      'space.builder.personal','space.builder.team','space.builder.role','space.builder.publish','space.builder.lock','space.roles.view','space.roles.manage','space.roles.delegate',
      'space.users.view','space.users.manage','space.users.direct_grant','space.audit.view','space.audit.export','space.simulator.view','space.export','field.financial_value.view','field.vendor_contact.view','field.internal_notes.view',
      'widget.production.view','widget.qc.view','widget.stock.view','widget.dispatch.view','widget.wastage.view','widget.machine.view'
    ],
    deny:['space.builder.org'],
    delegate:[
      'space.dashboard.view','space.dashboard.drilldown','space.dashboard.saved_view','space.tasks.view','space.tasks.claim','space.tasks.update','space.tasks.complete',
      'space.approvals.view','space.exceptions.view','space.exceptions.ack','space.builder.personal','space.export','field.vendor_contact.view','field.internal_notes.view',
      'widget.production.view','widget.qc.view','widget.stock.view','widget.dispatch.view','widget.wastage.view','widget.machine.view'
    ],
    widgetIds:widgetCatalog.map((w) => w.id), dashboardRights:{personal:true, team:true, role:true, org:false, publish:true, lock:true}
  },
  {
    id:'role-quality-manager', name:'Quality Manager', label:'Level 2 · Quality', level:2, parentId:'role-super-admin', color:'#7857e8', soft:'#f1edff',
    description:'Controls QC workload, holds, quality approvals, CAPA exceptions and QA team dashboards.', scope:{type:'plant', values:['Bangalore Unit','Chennai Unit']},
    allow:[
      'space.dashboard.view','space.dashboard.drilldown','space.dashboard.saved_view','space.tasks.view','space.tasks.claim','space.tasks.update','space.tasks.complete','space.tasks.reassign',
      'space.approvals.view','space.approvals.approve','space.approvals.reject','space.approvals.return','space.exceptions.view','space.exceptions.ack','space.exceptions.assign','space.exceptions.resolve',
      'space.builder.personal','space.builder.team','space.builder.role','space.builder.publish','space.builder.lock','space.roles.view','space.roles.manage','space.roles.delegate',
      'space.users.view','space.users.manage','space.users.direct_grant','space.audit.view','space.audit.export','space.simulator.view','space.export','field.vendor_contact.view','field.internal_notes.view',
      'widget.production.view','widget.qc.view','widget.stock.view','widget.wastage.view','widget.machine.view'
    ], deny:['space.builder.org','field.financial_value.view'],
    delegate:['space.dashboard.view','space.dashboard.drilldown','space.tasks.view','space.tasks.claim','space.tasks.update','space.tasks.complete','space.exceptions.view','space.exceptions.ack','space.builder.personal','field.internal_notes.view','widget.production.view','widget.qc.view','widget.stock.view','widget.wastage.view','widget.machine.view'],
    widgetIds:['production','pendingQc','lowStock','wastage','machine','productionTrend','myTasks','approvalQueue','exceptions','processFlow','unitPerformance','activity','quickActions','sla'],
    dashboardRights:{personal:true, team:true, role:true, org:false, publish:true, lock:true}
  },
  {
    id:'role-production-executive', name:'Production Executive', label:'Level 3 · Production', level:3, parentId:'role-operations-manager', color:'#14a3b8', soft:'#e8f9fb',
    description:'Executes work orders, material issues, output, wastage and machine tasks.', scope:{type:'assigned', values:['Bangalore Unit','Shift A','Assigned Records']},
    allow:['space.dashboard.view','space.dashboard.saved_view','space.tasks.view','space.tasks.claim','space.tasks.update','space.tasks.complete','space.exceptions.view','space.exceptions.ack','space.builder.personal','space.export','widget.production.view','widget.stock.view','widget.wastage.view','widget.machine.view'],
    deny:['field.financial_value.view','field.vendor_contact.view','field.internal_notes.view'], delegate:[],
    widgetIds:['production','lowStock','wastage','machine','productionTrend','myTasks','exceptions','processFlow','quickActions','sla'], dashboardRights:{personal:true,team:false,role:false,org:false,publish:false,lock:false}
  },
  {
    id:'role-qc-executive', name:'QC Executive', label:'Level 3 · Quality', level:3, parentId:'role-quality-manager', color:'#7857e8', soft:'#f1edff',
    description:'Performs incoming, in-process and final QC inspections and acknowledges holds.', scope:{type:'assigned', values:['Bangalore Unit','QC Team','Assigned Batches']},
    allow:['space.dashboard.view','space.dashboard.saved_view','space.tasks.view','space.tasks.claim','space.tasks.update','space.tasks.complete','space.exceptions.view','space.exceptions.ack','space.builder.personal','space.export','field.internal_notes.view','widget.production.view','widget.qc.view','widget.stock.view','widget.wastage.view'],
    deny:['field.financial_value.view','field.vendor_contact.view'], delegate:[],
    widgetIds:['production','pendingQc','lowStock','wastage','productionTrend','myTasks','exceptions','processFlow','activity','quickActions','sla'], dashboardRights:{personal:true,team:false,role:false,org:false,publish:false,lock:false}
  },
  {
    id:'role-store-executive', name:'Store Executive', label:'Level 3 · Store / GRN', level:3, parentId:'role-operations-manager', color:'#e99a18', soft:'#fff6df',
    description:'Handles inward queue, GRN, putaway, material issues and stock exceptions.', scope:{type:'assigned', values:['Bangalore Unit','RM Warehouse','Assigned Records']},
    allow:['space.dashboard.view','space.dashboard.saved_view','space.tasks.view','space.tasks.claim','space.tasks.update','space.tasks.complete','space.exceptions.view','space.exceptions.ack','space.builder.personal','space.export','field.vendor_contact.view','widget.stock.view','widget.qc.view'],
    deny:['field.financial_value.view','field.internal_notes.view'], delegate:[],
    widgetIds:['pendingQc','lowStock','myTasks','exceptions','processFlow','activity','quickActions','sla'], dashboardRights:{personal:true,team:false,role:false,org:false,publish:false,lock:false}
  },
  {
    id:'role-logistics-executive', name:'Logistics Executive', label:'Level 3 · Dispatch', level:3, parentId:'role-operations-manager', color:'#2979ff', soft:'#eaf2ff',
    description:'Handles dispatch planning, POD upload, closure and delayed shipment exceptions.', scope:{type:'assigned', values:['Bangalore Unit','FG Warehouse','Assigned Shipments']},
    allow:['space.dashboard.view','space.dashboard.saved_view','space.tasks.view','space.tasks.claim','space.tasks.update','space.tasks.complete','space.exceptions.view','space.exceptions.ack','space.builder.personal','space.export','field.vendor_contact.view','widget.stock.view','widget.dispatch.view'],
    deny:['field.financial_value.view','field.internal_notes.view'], delegate:[],
    widgetIds:['lowStock','dispatch','myTasks','exceptions','processFlow','activity','quickActions','sla'], dashboardRights:{personal:true,team:false,role:false,org:false,publish:false,lock:false}
  },
  {
    id:'role-multi-executive', name:'GRN + QC Executive', label:'Level 3 · Multi-module', level:3, parentId:'role-operations-manager', color:'#0fbd8c', soft:'#e7fbf4',
    description:'A cross-trained executive with combined GRN and QC work queues and widgets.', scope:{type:'assigned', values:['Bangalore Unit','RM Warehouse','Assigned Records']},
    allow:['space.dashboard.view','space.dashboard.saved_view','space.tasks.view','space.tasks.claim','space.tasks.update','space.tasks.complete','space.exceptions.view','space.exceptions.ack','space.builder.personal','space.export','field.vendor_contact.view','field.internal_notes.view','widget.stock.view','widget.qc.view'],
    deny:['field.financial_value.view'], delegate:[],
    widgetIds:['pendingQc','lowStock','myTasks','exceptions','processFlow','activity','quickActions','sla'], dashboardRights:{personal:true,team:false,role:false,org:false,publish:false,lock:false}
  }
];

const usersSeed = [
  {id:'u-super', name:'Aarav Malhotra', initials:'AM', roleId:'role-super-admin', level:1, title:'ERP Super Administrator', vertical:'Organisation', plant:'All Units', team:'Governance', managerId:null, email:'aarav@tan90.demo', phone:'+91 98765 01001', status:'active', lastActive:'2026-08-04T02:25:00+05:30', direct:[]},
  {id:'u-ops-manager', name:'Karan Mehta', initials:'KM', roleId:'role-operations-manager', level:2, title:'Head of Operations', vertical:'Operations', plant:'Bangalore Unit', team:'Plant Leadership', managerId:'u-super', email:'karan@tan90.demo', phone:'+91 98765 01002', status:'active', lastActive:'2026-08-04T02:30:00+05:30', direct:[]},
  {id:'u-quality-manager', name:'Meera Iyer', initials:'MI', roleId:'role-quality-manager', level:2, title:'Head of Quality', vertical:'Quality', plant:'Bangalore + Chennai', team:'Quality Leadership', managerId:'u-super', email:'meera@tan90.demo', phone:'+91 98765 01003', status:'active', lastActive:'2026-08-04T01:55:00+05:30', direct:[]},
  {id:'u-prod-exec', name:'Neha Patel', initials:'NP', roleId:'role-production-executive', level:3, title:'Production Executive', vertical:'Production', plant:'Bangalore Unit', team:'Shift A', managerId:'u-ops-manager', email:'neha@tan90.demo', phone:'+91 98765 01004', status:'active', lastActive:'2026-08-04T02:35:00+05:30', direct:[]},
  {id:'u-qc-exec', name:'Riya Nair', initials:'RN', roleId:'role-qc-executive', level:3, title:'QC Executive', vertical:'Quality', plant:'Bangalore Unit', team:'QC Team', managerId:'u-quality-manager', email:'riya@tan90.demo', phone:'+91 98765 01005', status:'active', lastActive:'2026-08-04T02:18:00+05:30', direct:[]},
  {id:'u-store-exec', name:'Vikram Singh', initials:'VS', roleId:'role-store-executive', level:3, title:'Store Executive', vertical:'Stores', plant:'Bangalore Unit', team:'RM Warehouse', managerId:'u-ops-manager', email:'vikram@tan90.demo', phone:'+91 98765 01006', status:'active', lastActive:'2026-08-04T02:12:00+05:30', direct:[]},
  {id:'u-logistics-exec', name:'Aditya Bose', initials:'AB', roleId:'role-logistics-executive', level:3, title:'Logistics Executive', vertical:'Logistics', plant:'Bangalore Unit', team:'Dispatch Desk', managerId:'u-ops-manager', email:'aditya@tan90.demo', phone:'+91 98765 01007', status:'active', lastActive:'2026-08-04T01:48:00+05:30', direct:[]},
  {id:'u-multi-exec', name:'Sana Khan', initials:'SK', roleId:'role-multi-executive', level:3, title:'GRN + QC Executive', vertical:'Stores + Quality', plant:'Bangalore Unit', team:'Inbound Quality', managerId:'u-ops-manager', email:'sana@tan90.demo', phone:'+91 98765 01008', status:'active', lastActive:'2026-08-04T02:28:00+05:30', direct:[{id:'grant-seed', permission:'space.approvals.view', effect:'allow', reason:'Temporary visibility during manager leave', expiresAt:'2026-08-11', grantedBy:'u-ops-manager', grantedAt:'2026-08-03T10:00:00+05:30'}]},
  {id:'u-disabled', name:'Rahul Das', initials:'RD', roleId:'role-production-executive', level:3, title:'Production Executive', vertical:'Production', plant:'Bangalore Unit', team:'Shift B', managerId:'u-ops-manager', email:'rahul@tan90.demo', phone:'+91 98765 01009', status:'disabled', lastActive:'2026-07-29T18:20:00+05:30', direct:[]}
];

const tasksSeed = [
  {id:'TSK-1042', type:'GRN', module:'Inbound', title:'Post GRN for PCM Compound A01', description:'Vendor invoice and unloading confirmation are complete. Verify accepted quantity and post GRN.', plant:'Bangalore Unit', team:'RM Warehouse', assignedTo:'u-store-exec', status:'todo', priority:'high', due:'Today · 09:30', age:'1h 12m', action:'Post GRN', permission:'space.tasks.complete', batch:'VLOT-PCM-240804-18', quantity:'1,250 kg', reference:'PO-2608-014', value:'₹8,42,500', vendor:'CryoChem Industries', evidence:'Invoice, weighment, unloading photos', timeline:[['Gate entry completed','Security Desk · 07:42'],['Unloading verified','Vikram Singh · 08:18'],['Incoming QC accepted','Riya Nair · 08:43']]},
  {id:'TSK-1043', type:'QC', module:'Quality', title:'Incoming QC — Sachet Film roll', description:'Sample received from GRN draft. Record thickness, seal strength and visual inspection result.', plant:'Bangalore Unit', team:'QC Team', assignedTo:'u-qc-exec', status:'in_progress', priority:'high', due:'Today · 09:15', age:'46m', action:'Complete Inspection', permission:'space.tasks.complete', batch:'VLOT-FILM-240804-07', quantity:'28 rolls', reference:'GRN-D-00821', value:'₹2,18,400', vendor:'FlexiPack Pvt Ltd', evidence:'Sampling plan AQL 1.5', timeline:[['Sample created','Sana Khan · 08:06'],['Inspection started','Riya Nair · 08:29']]},
  {id:'TSK-1044', type:'Material Issue', module:'Production', title:'Issue PCM and film to WO-2608-031', description:'Production plan is released. Scan requested batches and confirm material handover to Shift A.', plant:'Bangalore Unit', team:'Shift A', assignedTo:'u-prod-exec', status:'todo', priority:'high', due:'Today · 10:00', age:'32m', action:'Confirm Issue', permission:'space.tasks.complete', batch:'RM Pick List 1462', quantity:'PCM 620 kg · Film 6,000 pcs', reference:'WO-2608-031', value:'₹4,71,000', vendor:'Internal Store', evidence:'Batch scan required', timeline:[['Work order released','Karan Mehta · 08:35'],['Pick list generated','System · 08:36']]},
  {id:'TSK-1045', type:'Job Card', module:'Production', title:'Record Shift A output — Line 2', description:'Capture good output, rejection, wastage, downtime and operator sign-off for the running job card.', plant:'Bangalore Unit', team:'Shift A', assignedTo:'u-prod-exec', status:'in_progress', priority:'medium', due:'Today · 14:00', age:'2h 04m', action:'Record Output', permission:'space.tasks.update', batch:'TS-BLR-240804-A2', quantity:'Target 8,000 pcs', reference:'JC-2608-087', value:'₹6,16,000', vendor:'Internal Production', evidence:'Machine counter + supervisor sign-off', timeline:[['Job card started','Neha Patel · 06:08'],['First hour output recorded','Neha Patel · 07:16']]},
  {id:'TSK-1046', type:'Quality Hold', module:'Quality', title:'Review sealing variation hold', description:'Five samples are below seal strength threshold. Review machine settings and decide release, rework or rejection.', plant:'Bangalore Unit', team:'QC Team', assignedTo:'u-quality-manager', status:'blocked', priority:'high', due:'Overdue · 35m', age:'3h 22m', action:'Review Hold', permission:'space.exceptions.resolve', batch:'TS-BLR-240804-A1', quantity:'1,820 pcs on hold', reference:'QH-2608-019', value:'₹1,40,140', vendor:'Internal Production', evidence:'Lab result + machine parameters', timeline:[['Deviation detected','Riya Nair · 06:32'],['Batch placed on hold','Riya Nair · 06:38'],['Manager review requested','System · 06:40']]},
  {id:'TSK-1047', type:'POD', module:'Dispatch', title:'Upload POD and close shipment', description:'Vehicle reached customer site. Upload signed POD, confirm delivered quantity and close dispatch.', plant:'Bangalore Unit', team:'Dispatch Desk', assignedTo:'u-logistics-exec', status:'todo', priority:'medium', due:'Today · 11:00', age:'48m', action:'Close Dispatch', permission:'space.tasks.complete', batch:'Multiple FG batches', quantity:'3,200 sachets', reference:'DSP-2608-044', value:'₹3,84,000', vendor:'SwiftTrans Logistics', evidence:'Signed POD required', timeline:[['Vehicle dispatched','Aditya Bose · 02 Aug 18:40'],['Customer arrival confirmed','GPS · 08:21']]},
  {id:'TSK-1048', type:'Approval', module:'Procurement', title:'Approve emergency PCM purchase', description:'Low-stock risk requires an expedited PO for 800 kg PCM. Review price variance and delivery date.', plant:'Bangalore Unit', team:'Plant Leadership', assignedTo:'u-ops-manager', status:'todo', priority:'high', due:'Today · 09:45', age:'27m', action:'Open Approval', permission:'space.approvals.approve', batch:'Not applicable', quantity:'800 kg', reference:'PR-2608-029', value:'₹5,36,000', vendor:'CryoChem Industries', evidence:'Three quotations + shortage calculation', timeline:[['MRP shortage created','System · 07:58'],['PR submitted','Purchase Executive · 08:23']]},
  {id:'TSK-1049', type:'Cycle Count', module:'Inventory', title:'Count PCM bin RM-A-07', description:'System vs physical stock variance exceeded tolerance. Recount and submit evidence.', plant:'Bangalore Unit', team:'RM Warehouse', assignedTo:'u-store-exec', status:'todo', priority:'medium', due:'Today · 13:00', age:'1h 40m', action:'Submit Count', permission:'space.tasks.update', batch:'Multiple vendor lots', quantity:'System 2,860 kg', reference:'CC-2608-012', value:'₹19,16,200', vendor:'Internal Store', evidence:'Photo + scale reading', timeline:[['Count generated','System · 07:10']]},
  {id:'TSK-1050', type:'Final QC', module:'Quality', title:'Final QC — Thermal Panel batch', description:'Complete appearance, temperature retention and packing verification before FG receipt.', plant:'Chennai Unit', team:'QC Team', assignedTo:'u-qc-exec', status:'todo', priority:'medium', due:'Today · 15:30', age:'22m', action:'Start Inspection', permission:'space.tasks.claim', batch:'TP-CHE-240804-03', quantity:'1,400 panels', reference:'WO-2608-026', value:'₹12,60,000', vendor:'Internal Production', evidence:'Final QC checklist', timeline:[['Production completed','Chennai Shift B · 08:44']]},
  {id:'TSK-1051', type:'Exception', module:'Production', title:'Investigate Line 1 downtime', description:'Unplanned downtime crossed 42 minutes. Confirm reason, owner and restoration ETA.', plant:'Bangalore Unit', team:'Shift A', assignedTo:'u-prod-exec', status:'blocked', priority:'high', due:'Overdue · 18m', age:'55m', action:'Acknowledge', permission:'space.exceptions.ack', batch:'Current running jobs', quantity:'42 min downtime', reference:'EXC-2608-073', value:'Estimated ₹74,000 impact', vendor:'Internal Maintenance', evidence:'Machine alarm history', timeline:[['Downtime alert raised','System · 08:02'],['Maintenance notified','Neha Patel · 08:08']]},
  {id:'TSK-1052', type:'Putaway', module:'Inventory', title:'Put away accepted GRN batches', description:'Allocate accepted PCM and film batches to available bins, scan location and confirm quantity.', plant:'Bangalore Unit', team:'RM Warehouse', assignedTo:'u-multi-exec', status:'todo', priority:'low', due:'Today · 12:30', age:'15m', action:'Confirm Putaway', permission:'space.tasks.complete', batch:'GRN-2608-118 / 119', quantity:'1,100 kg + 16 rolls', reference:'PA-2608-038', value:'₹8,88,000', vendor:'Multiple vendors', evidence:'Bin scan', timeline:[['GRN posted','System · 08:50']]},
  {id:'TSK-1053', type:'QC', module:'Quality', title:'In-process check — Line 3', description:'Record fill weight and leak test at the second hourly checkpoint.', plant:'Bangalore Unit', team:'Inbound Quality', assignedTo:'u-multi-exec', status:'todo', priority:'medium', due:'Today · 10:30', age:'10m', action:'Complete Inspection', permission:'space.tasks.complete', batch:'TS-BLR-240804-A3', quantity:'Sample 13 units', reference:'IPQC-2608-211', value:'—', vendor:'Internal Production', evidence:'Digital gauge readings', timeline:[['Checkpoint created','System · 09:01']]},
  {id:'TSK-1054', type:'Approval', module:'Quality', title:'Approve partial acceptance of film', description:'QC proposes accepting 24 of 28 rolls and rejecting 4 rolls due to surface damage.', plant:'Bangalore Unit', team:'Quality Leadership', assignedTo:'u-quality-manager', status:'todo', priority:'medium', due:'Today · 10:15', age:'18m', action:'Open Approval', permission:'space.approvals.approve', batch:'VLOT-FILM-240804-07', quantity:'24 accept · 4 reject', reference:'QA-2608-055', value:'₹31,200 rejection', vendor:'FlexiPack Pvt Ltd', evidence:'Inspection images', timeline:[['QC result submitted','Riya Nair · 08:57']]},
  {id:'TSK-1055', type:'GRN', module:'Inbound', title:'Validate vendor invoice mismatch', description:'PO rate and invoice rate differ by 3.8%. Confirm approved amendment or return to procurement.', plant:'Bangalore Unit', team:'Inbound Quality', assignedTo:'u-multi-exec', status:'blocked', priority:'medium', due:'Today · 11:30', age:'35m', action:'Request Clarification', permission:'space.tasks.update', batch:'VLOT-PCM-240804-19', quantity:'500 kg', reference:'GRN-D-00824', value:'₹3,48,700', vendor:'ThermaCore Materials', evidence:'Invoice + PO comparison', timeline:[['Mismatch detected','System · 08:38']]}
];

const approvalsSeed = [
  {id:'APR-2608-201', type:'Purchase Requisition', title:'Emergency PCM purchase — 800 kg', requester:'Anuj Sharma', department:'Procurement', plant:'Bangalore Unit', amount:'₹5,36,000', numericAmount:536000, risk:'High', sla:'42 min left', status:'pending', permission:'space.approvals.approve', details:'Material shortage will stop Line 2 after 16 hours. Vendor promises next-day delivery at 4.2% premium.', reference:'PR-2608-029'},
  {id:'APR-2608-202', type:'Quality Disposition', title:'Partial acceptance — Film roll lot', requester:'Riya Nair', department:'Quality', plant:'Bangalore Unit', amount:'₹31,200 impact', numericAmount:31200, risk:'Medium', sla:'1h 18m left', status:'pending', permission:'space.approvals.approve', details:'Accept 24 rolls and reject 4 with visible surface damage. Production continuity remains protected.', reference:'QA-2608-055'},
  {id:'APR-2608-203', type:'Inventory Adjustment', title:'PCM cycle-count variance adjustment', requester:'Vikram Singh', department:'Stores', plant:'Bangalore Unit', amount:'₹18,760 impact', numericAmount:18760, risk:'Medium', sla:'3h 10m left', status:'pending', permission:'space.approvals.approve', details:'Physical stock is 28 kg below system. Recount and weighment evidence attached.', reference:'ADJ-2608-011'},
  {id:'APR-2608-204', type:'Dispatch Exception', title:'Approve alternate vehicle for pharma order', requester:'Aditya Bose', department:'Logistics', plant:'Bangalore Unit', amount:'₹9,500 extra freight', numericAmount:9500, risk:'Low', sla:'4h 05m left', status:'pending', permission:'space.approvals.approve', details:'Original vehicle broke down. Alternate reefer can preserve committed delivery date.', reference:'DSP-X-2608-009'},
  {id:'APR-2608-205', type:'Wastage Approval', title:'Close sachet sealing wastage incident', requester:'Neha Patel', department:'Production', plant:'Bangalore Unit', amount:'₹42,800 loss', numericAmount:42800, risk:'High', sla:'Overdue 24m', status:'pending', permission:'space.approvals.approve', details:'Scrap exceeded shift threshold. Root cause points to worn heater band; maintenance action recorded.', reference:'WST-2608-018'}
];

const exceptionsSeed = [
  {id:'EXC-2608-073', category:'Machine', severity:'critical', title:'Line 1 unplanned downtime', description:'Downtime crossed 42 minutes and current ETA is not confirmed.', plant:'Bangalore Unit', owner:'Neha Patel', ownerId:'u-prod-exec', age:'55m', impact:'Output risk: 1,180 pcs', status:'open', rule:'Downtime > 30 min', reference:'MCH-L1'},
  {id:'EXC-2608-074', category:'Quality', severity:'critical', title:'Sealing strength below specification', description:'Five samples failed minimum seal-strength threshold; 1,820 pcs are on hold.', plant:'Bangalore Unit', owner:'Meera Iyer', ownerId:'u-quality-manager', age:'3h 22m', impact:'₹1.40L inventory on hold', status:'acknowledged', rule:'QC result below LSL', reference:'QH-2608-019'},
  {id:'EXC-2608-075', category:'Inventory', severity:'high', title:'PCM projected shortage in 16 hours', description:'Open purchase orders will not arrive before planned Line 2 consumption.', plant:'Bangalore Unit', owner:'Karan Mehta', ownerId:'u-ops-manager', age:'1h 16m', impact:'Potential production stop', status:'open', rule:'Coverage < 24 h', reference:'RM-PCM-A01'},
  {id:'EXC-2608-076', category:'Dispatch', severity:'high', title:'POD pending beyond SLA', description:'Customer delivery was confirmed by GPS but signed POD is not uploaded.', plant:'Bangalore Unit', owner:'Aditya Bose', ownerId:'u-logistics-exec', age:'5h 40m', impact:'Shipment cannot close', status:'open', rule:'POD > 4 h', reference:'DSP-2608-039'},
  {id:'EXC-2608-077', category:'GRN', severity:'medium', title:'Invoice rate variance 3.8%', description:'Vendor invoice exceeds PO rate and no amendment is attached.', plant:'Bangalore Unit', owner:'Sana Khan', ownerId:'u-multi-exec', age:'35m', impact:'₹12,700 variance', status:'open', rule:'Rate variance > 2%', reference:'GRN-D-00824'},
  {id:'EXC-2608-078', category:'Wastage', severity:'medium', title:'Shift wastage above target', description:'Line 2 wastage reached 3.1% against 1.8% configured threshold.', plant:'Bangalore Unit', owner:'Neha Patel', ownerId:'u-prod-exec', age:'1h 48m', impact:'300 pcs rejected', status:'acknowledged', rule:'Wastage > 1.8%', reference:'JC-2608-087'},
  {id:'EXC-2608-079', category:'Approval', severity:'low', title:'Purchase approval approaching SLA', description:'Emergency PCM purchase has 42 minutes left before escalation.', plant:'Bangalore Unit', owner:'Karan Mehta', ownerId:'u-ops-manager', age:'27m', impact:'Production continuity', status:'open', rule:'Approval SLA < 60m', reference:'APR-2608-201'}
];

const auditSeed = [
  {id:'AUD-001', at:'2026-08-04T02:30:00+05:30', actor:'Karan Mehta', actorId:'u-ops-manager', action:'Published team dashboard', object:'Bangalore Operations', category:'Dashboard', result:'Success', detail:'Published version 7 with locked Production and Exception widgets.'},
  {id:'AUD-002', at:'2026-08-04T02:28:00+05:30', actor:'Sana Khan', actorId:'u-multi-exec', action:'Completed incoming QC', object:'VLOT-PCM-240804-18', category:'Task', result:'Success', detail:'Accepted 1,250 kg. Result released to GRN queue.'},
  {id:'AUD-003', at:'2026-08-04T02:18:00+05:30', actor:'Riya Nair', actorId:'u-qc-exec', action:'Placed batch on hold', object:'TS-BLR-240804-A1', category:'Quality', result:'Success', detail:'Seal strength failed on 5 samples.'},
  {id:'AUD-004', at:'2026-08-04T01:58:00+05:30', actor:'Aarav Malhotra', actorId:'u-super', action:'Updated manager permission ceiling', object:'Operations Manager', category:'Access', result:'Success', detail:'Enabled delegation of space.dashboard.saved_view.'},
  {id:'AUD-005', at:'2026-08-04T01:42:00+05:30', actor:'Neha Patel', actorId:'u-prod-exec', action:'Recorded production output', object:'JC-2608-087', category:'Task', result:'Success', detail:'Recorded 2,860 good units and 92 rejected units.'},
  {id:'AUD-006', at:'2026-08-04T01:20:00+05:30', actor:'Unknown request', actorId:null, action:'Denied direct API action', object:'space.approvals.approve', category:'Security', result:'Denied', detail:'Production Executive attempted approval action without permission.'}
];

const defaultLayouts = {
  organisation: [
    {id:'production',span:3,locked:true,mandatory:true},{id:'pendingQc',span:3,locked:true,mandatory:true},{id:'lowStock',span:3,locked:true,mandatory:true},{id:'dispatch',span:3,locked:true,mandatory:true},
    {id:'productionTrend',span:8,locked:false},{id:'myTasks',span:4,locked:false},{id:'approvalQueue',span:6,locked:false},{id:'exceptions',span:6,locked:true},
    {id:'processFlow',span:6,locked:false},{id:'unitPerformance',span:6,locked:false},{id:'activity',span:4,locked:false},{id:'quickActions',span:4,locked:false},{id:'sla',span:4,locked:false}
  ],
  manager: [
    {id:'production',span:3,locked:true,mandatory:true},{id:'pendingQc',span:3,locked:true,mandatory:true},{id:'lowStock',span:3,locked:false},{id:'machine',span:3,locked:false},
    {id:'productionTrend',span:8,locked:false},{id:'myTasks',span:4,locked:false},{id:'approvalQueue',span:6,locked:true},{id:'exceptions',span:6,locked:true},
    {id:'processFlow',span:6,locked:false},{id:'unitPerformance',span:6,locked:false},{id:'activity',span:4,locked:false},{id:'quickActions',span:4,locked:false},{id:'sla',span:4,locked:false}
  ],
  executive: [
    {id:'production',span:3,locked:true,mandatory:true},{id:'pendingQc',span:3,locked:false},{id:'lowStock',span:3,locked:false},{id:'wastage',span:3,locked:false},
    {id:'myTasks',span:6,locked:true,mandatory:true},{id:'exceptions',span:6,locked:true},{id:'productionTrend',span:8,locked:false},{id:'quickActions',span:4,locked:false},
    {id:'processFlow',span:8,locked:false},{id:'sla',span:4,locked:false}
  ]
};

const STORAGE_KEY = 'tan90-space01-command-center-v1';
const stored = (() => {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'); } catch { return {}; }
})();

const state = {
  currentUserId: stored.currentUserId || null,
  view: stored.view || 'dashboard',
  theme: stored.theme || 'light',
  sidebarOpen: false,
  roles: stored.roles || clone(rolesSeed),
  users: stored.users || clone(usersSeed),
  tasks: stored.tasks || clone(tasksSeed),
  approvals: stored.approvals || clone(approvalsSeed),
  exceptions: stored.exceptions || clone(exceptionsSeed),
  audit: stored.audit || clone(auditSeed),
  layouts: stored.layouts || {},
  builder: Object.assign({targetType:'personal',targetId:null,device:'desktop',selectedWidgetId:null,search:'',history:[],future:[]}, stored.builder || {}),
  roleStudio: Object.assign({roleId:'role-operations-manager',tab:'permissions',group:'All',search:''}, stored.roleStudio || {}),
  work: Object.assign({view:'board',tab:'active',search:'',priority:'all',module:'all'}, stored.work || {}),
  approvalFilter: stored.approvalFilter || 'pending',
  exceptionFilter: stored.exceptionFilter || 'all',
  userSearch: stored.userSearch || '',
  userView: stored.userView || 'cards',
  auditSearch: stored.auditSearch || '',
  simulator: Object.assign({userId:'u-prod-exec',permission:'space.approvals.approve',plant:'Bangalore Unit',result:null}, stored.simulator || {}),
  overlay: null
};

function persist() {
  const safe = {
    currentUserId: state.currentUserId, view: state.view, theme: state.theme, roles: state.roles, users: state.users,
    tasks: state.tasks, approvals: state.approvals, exceptions: state.exceptions, audit: state.audit, layouts: state.layouts,
    builder: state.builder, roleStudio: state.roleStudio, work: state.work, approvalFilter: state.approvalFilter,
    exceptionFilter: state.exceptionFilter, userSearch: state.userSearch, userView: state.userView,
    auditSearch: state.auditSearch, simulator: state.simulator
  };
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(safe)); } catch (_) { /* opaque/file origins may disable storage */ }
}

function roleById(id) { return state.roles.find((role) => role.id === id); }
function userById(id) { return state.users.find((user) => user.id === id); }
function currentUser() { return userById(state.currentUserId); }
function currentRole() { const user = currentUser(); return user ? roleById(user.roleId) : null; }
function isActiveGrant(grant) {
  if (!grant.expiresAt) return true;
  const expiry = new Date(`${grant.expiresAt}T23:59:59`);
  return expiry.getTime() >= Date.now();
}

function resolvePermission(user, permission, context = {}) {
  const role = roleById(user?.roleId);
  const trace = [];
  if (!user || user.status !== 'active') {
    trace.push({step:'Identity', result:'DENY', detail:'User is missing or disabled.'});
    return {allowed:false, source:'identity', trace};
  }
  trace.push({step:'Identity', result:'PASS', detail:`${user.name} is active at hierarchy level ${user.level}.`});

  const direct = (user.direct || []).filter(isActiveGrant).filter((grant) => grant.permission === permission || grant.permission === '*');
  const directDeny = direct.find((grant) => grant.effect === 'deny');
  if (directDeny) {
    trace.push({step:'Direct override', result:'DENY', detail:`Explicit user deny: ${directDeny.reason}.`});
    return {allowed:false, source:'direct-deny', trace, grant:directDeny};
  }
  const directAllow = direct.find((grant) => grant.effect === 'allow');
  if (directAllow) trace.push({step:'Direct override', result:'ALLOW', detail:`User-specific allow until ${directAllow.expiresAt || 'no expiry'}.`});
  else trace.push({step:'Direct override', result:'NONE', detail:'No active user-specific override.'});

  const roleDenied = role?.deny?.includes(permission);
  if (roleDenied) {
    trace.push({step:'Role policy', result:'DENY', detail:`${role.name} explicitly denies this permission.`});
    return {allowed:false, source:'role-deny', trace};
  }
  const roleAllowed = role?.allow?.includes('*') || role?.allow?.includes(permission);
  trace.push({step:'Role policy', result:roleAllowed ? 'ALLOW' : 'NO GRANT', detail:roleAllowed ? `${role.name} includes ${permission}.` : `${role?.name || 'Role'} does not include ${permission}.`});

  let scopePass = true;
  if (context.plant && role?.scope?.type !== 'all') {
    scopePass = role.scope.values.some((value) => value === context.plant || value.includes(context.plant) || context.plant.includes(value));
    if (role.scope.type === 'assigned' && context.assignedTo && context.assignedTo !== user.id && user.level >= 3) scopePass = false;
  }
  trace.push({step:'Data scope', result:scopePass ? 'PASS' : 'DENY', detail:scopePass ? `Resource is inside ${role?.scope?.type || 'configured'} scope.` : `Resource is outside ${role?.scope?.type || 'configured'} scope.`});

  const allowed = Boolean((directAllow || roleAllowed) && scopePass);
  trace.push({step:'Final decision', result:allowed ? 'ALLOW' : 'DENY', detail:allowed ? 'Least-privilege checks passed.' : 'No applicable allow remained after scope checks.'});
  return {allowed, source:directAllow ? 'direct-allow' : roleAllowed ? 'role' : 'default-deny', trace};
}

function has(permission, context = {}) { return resolvePermission(currentUser(), permission, context).allowed; }
function canDelegate(permission) {
  const role = currentRole();
  return Boolean(role?.delegate?.includes('*') || role?.delegate?.includes(permission));
}
function isSubordinate(actor, subject) {
  if (!actor || !subject || actor.id === subject.id) return false;
  if (actor.level >= subject.level) return false;
  if (actor.level === 1) return true;
  let cursor = subject;
  while (cursor?.managerId) {
    if (cursor.managerId === actor.id) return true;
    cursor = userById(cursor.managerId);
  }
  return false;
}
function visibleUsersFor(actor = currentUser()) {
  if (!actor) return [];
  if (actor.level === 1) return state.users;
  return state.users.filter((user) => user.id === actor.id || isSubordinate(actor, user));
}
function visibleTasksFor(user = currentUser()) {
  if (!user) return [];
  if (user.level === 1) return state.tasks;
  if (user.level === 2) return state.tasks.filter((task) => task.plant.includes(user.plant.split(' + ')[0]) || task.assignedTo === user.id || isSubordinate(user, userById(task.assignedTo)));
  return state.tasks.filter((task) => task.assignedTo === user.id || (!task.assignedTo && has(task.permission, task)));
}
function visibleApprovalsFor(user = currentUser()) {
  if (!user || !resolvePermission(user, 'space.approvals.view').allowed) return [];
  if (user.level === 1) return state.approvals;
  return state.approvals.filter((approval) => approval.plant.includes(user.plant.split(' + ')[0]));
}
function visibleExceptionsFor(user = currentUser()) {
  if (!user || !resolvePermission(user, 'space.exceptions.view').allowed) return [];
  if (user.level === 1) return state.exceptions;
  if (user.level === 2) return state.exceptions.filter((item) => item.plant.includes(user.plant.split(' + ')[0]));
  return state.exceptions.filter((item) => item.ownerId === user.id || item.plant.includes(user.plant));
}

function logAudit(action, object, category = 'System', result = 'Success', detail = '') {
  const user = currentUser();
  state.audit.unshift({id:uid('AUD'), at:new Date().toISOString(), actor:user?.name || 'System', actorId:user?.id || null, action, object, category, result, detail});
  persist();
}

function layoutKey(type, id) { return `${type}:${id || 'default'}`; }
function seedLayoutFor(user) {
  if (user.level === 1) return clone(defaultLayouts.organisation);
  if (user.level === 2) return clone(defaultLayouts.manager);
  return clone(defaultLayouts.executive);
}
function getPersonalLayout(user = currentUser()) {
  const key = layoutKey('personal', user.id);
  if (!state.layouts[key]) state.layouts[key] = seedLayoutFor(user);
  return state.layouts[key];
}
function getBuilderTarget() {
  const user = currentUser();
  if (!state.builder.targetId) state.builder.targetId = user.id;
  const type = state.builder.targetType;
  const id = state.builder.targetId;
  const key = layoutKey(type, id);
  if (!state.layouts[key]) {
    if (type === 'personal') state.layouts[key] = seedLayoutFor(userById(id) || user);
    else if (type === 'team') state.layouts[key] = clone(defaultLayouts.manager);
    else if (type === 'role') {
      const role = roleById(id);
      state.layouts[key] = clone(role?.level === 3 ? defaultLayouts.executive : defaultLayouts.manager);
    } else state.layouts[key] = clone(defaultLayouts.organisation);
  }
  return {key, layout:state.layouts[key]};
}

const navItems = [
  {id:'dashboard', label:'Command Center', icon:'home', permission:'space.dashboard.view', group:'Space 01'},
  {id:'work', label:'My Work', icon:'task', permission:'space.tasks.view', group:'Space 01', count:() => visibleTasksFor().filter((t) => t.status !== 'done').length},
  {id:'approvals', label:'Approvals', icon:'approvals', permission:'space.approvals.view', group:'Space 01', count:() => visibleApprovalsFor().filter((a) => a.status === 'pending').length},
  {id:'exceptions', label:'Alerts & Exceptions', icon:'alert', permission:'space.exceptions.view', group:'Space 01', count:() => visibleExceptionsFor().filter((e) => e.status !== 'resolved').length},
  {id:'builder', label:'Dashboard Builder', icon:'builder', permission:'space.builder.personal', group:'Personalisation'},
  {id:'roles', label:'Roles & Permissions', icon:'roles', permission:'space.roles.view', group:'Access Control'},
  {id:'users', label:'Users & Direct Grants', icon:'users', permission:'space.users.view', group:'Access Control'},
  {id:'audit', label:'Activity & Audit', icon:'audit', permission:'space.audit.view', group:'Governance'},
  {id:'simulator', label:'Access Simulator', icon:'simulator', permission:'space.simulator.view', group:'Governance'}
];

const pageMeta = {
  dashboard:{title:'Command Center', eyebrow:'Space 01 · Live Operations', description:'Role-aware cockpit with live KPIs, assigned work, approvals, alerts and cross-process readiness.'},
  work:{title:'My Work', eyebrow:'Actionable Queue', description:'One operational queue for GRN, QC, material issue, job cards, approvals, POD and exception actions.'},
  approvals:{title:'Approval Center', eyebrow:'Controlled Decisions', description:'Risk, amount, SLA and supporting evidence together before approve, reject or return.'},
  exceptions:{title:'Alerts & Exceptions', eyebrow:'Operational Risk', description:'Shortage, delay, quality hold, high wastage, GRN variance and downtime in one response center.'},
  builder:{title:'Dashboard Builder', eyebrow:'Permission-aware Personalisation', description:'Drag, resize, lock and publish dashboards at organisation, role, team or individual level.'},
  roles:{title:'Role Permission Studio', eyebrow:'Three-level Hierarchy', description:'Control pages, actions, widgets, fields, scopes and delegation ceilings for Space 01.'},
  users:{title:'Users & Direct Grants', eyebrow:'Hierarchy-aware User Control', description:'Manage subordinate users and add time-bound user-specific permissions without changing shared roles.'},
  audit:{title:'Activity & Audit', eyebrow:'Accountability', description:'Trace operational actions, access changes, dashboard publishes and denied requests.'},
  simulator:{title:'Access Simulator', eyebrow:'Explain Effective Access', description:'Test a user, permission and resource scope to understand every allow or deny decision.'}
};

function renderLogin() {
  const groups = [
    {level:1, title:'Super Administration', subtitle:'Organisation-wide control, hierarchy and governance'},
    {level:2, title:'Managers', subtitle:'Plant or vertical control with delegated ceilings'},
    {level:3, title:'Executives', subtitle:'Assigned work with permission-aware personal dashboards'}
  ];
  const accounts = groups.map((group) => {
    const users = state.users.filter((user) => user.level === group.level && user.status === 'active');
    return `<section class="hierarchy-group">
      <div class="hierarchy-head"><div class="level-badge">L${group.level}</div><div><strong>${group.title}</strong><span>${group.subtitle}</span></div><div class="level-label">Hierarchy level ${group.level}</div></div>
      <div class="persona-grid">${users.map((user) => {
        const role = roleById(user.roleId);
        return `<button class="persona-card" data-action="login" data-user="${user.id}">
          <span class="persona-avatar" style="background:linear-gradient(145deg,${role.color}bb,${role.color}66)">${escapeHtml(user.initials)}</span>
          <span class="persona-copy"><strong>${escapeHtml(user.name)}</strong><small>${escapeHtml(role.name)} · ${escapeHtml(user.plant)}</small><span class="persona-tags"><span>${escapeHtml(user.vertical)}</span><span>${role.level === 1 ? 'Full control' : role.level === 2 ? 'Delegated control' : 'My work'}</span></span></span>
          <span class="persona-enter">${icon('arrowRight',16)}</span>
        </button>`;
      }).join('')}</div>
    </section>`;
  }).join('');

  return `<main class="login-screen">
    <section class="login-story">
      <div class="brand-lockup"><div class="brand-mark">T90<small>°</small></div><div class="brand-copy"><strong>Tan90 Pulse</strong><span>Command Center & My Work</span></div></div>
      <div class="login-hero"><span class="live-chip"><i></i> Space 01 Interactive MVP</span><h1>One screen to<br><em>see, decide & act.</em></h1><p>Live manufacturing KPIs, personal work, approvals, exceptions, dashboard personalisation and hierarchy-aware access control—combined into one focused operational space.</p>
        <div class="flow-strip"><span class="flow-node">Demand</span><span class="flow-arrow">→</span><span class="flow-node">Inbound</span><span class="flow-arrow">→</span><span class="flow-node">Production</span><span class="flow-arrow">→</span><span class="flow-node">Quality</span><span class="flow-arrow">→</span><span class="flow-node">Warehouse</span><span class="flow-arrow">→</span><span class="flow-node">Dispatch</span></div>
      </div>
      <div class="login-metrics"><div class="login-metric"><strong>3</strong><span>Hierarchy levels</span></div><div class="login-metric"><strong>15</strong><span>Role-aware widgets</span></div><div class="login-metric"><strong>40+</strong><span>Granular permissions</span></div></div>
    </section>
    <section class="login-accounts"><div class="login-title-row"><div><h2>Choose a demo persona</h2><p>Accounts are categorised hierarchy-wise so the client can compare effective access.</p></div><label class="dark-search">${icon('search')}<input id="loginSearch" placeholder="Search person, role or unit…"></label></div><div class="hierarchy-groups" id="loginGroups">${accounts}</div><div class="login-note">Demo data is local to this browser. No password required.</div></section>
  </main>`;
}

function renderSidebar() {
  const user = currentUser();
  const role = currentRole();
  const groups = [...new Set(navItems.map((item) => item.group))];
  return `<aside class="sidebar ${state.sidebarOpen ? 'open' : ''}" id="sidebar">
    <div class="mac-dots"><i></i><i></i><i></i></div>
    <div class="sidebar-brand"><div class="brand-mark">T90<small>°</small></div><div><strong>Tan90 Pulse</strong><small>Space 01 · MVP</small></div></div>
    <div class="user-context"><div class="user-context-top"><span class="persona-avatar" style="background:linear-gradient(145deg,${role.color}bb,${role.color}66)">${escapeHtml(user.initials)}</span><div><strong>${escapeHtml(user.name)}</strong><small>${escapeHtml(role.name)}</small></div><button class="context-switch" data-action="switch-persona" title="Switch demo persona">${icon('refresh',14)}</button></div><div class="context-tags"><span>L${user.level}</span><span>${escapeHtml(user.plant)}</span><span>${escapeHtml(role.scope.type)}</span></div></div>
    <div class="sidebar-scroll">${groups.map((group) => {
      const items = navItems.filter((item) => item.group === group);
      return `<div class="nav-heading">${group}</div><nav class="nav-list">${items.map((item) => {
        const allowed = has(item.permission);
        const count = allowed && item.count ? item.count() : 0;
        return `<button class="nav-item ${state.view === item.id ? 'active' : ''}" data-action="navigate" data-view="${item.id}" ${allowed ? '' : 'disabled'}>${icon(item.icon,16)}<span>${item.label}</span>${allowed ? (count ? `<span class="nav-count">${count}</span>` : '') : `<span class="nav-lock">${icon('lock',12)}</span>`}</button>`;
      }).join('')}</nav>`;
    }).join('')}</div>
    <div class="sidebar-footer"><div class="sidebar-mini-card">${icon('shield',16)}<div><strong>Effective access</strong><span>${role.allow.includes('*') ? 'Organisation-wide' : `${role.allow.length} role grants`}</span></div><button data-action="navigate" data-view="simulator" title="Open simulator">${icon('chevron',13)}</button></div></div>
  </aside>`;
}

function renderTopbar() {
  const user = currentUser();
  const role = currentRole();
  const meta = pageMeta[state.view] || pageMeta.dashboard;
  return `<header class="topbar">
    <button class="icon-btn mobile-menu" data-action="toggle-sidebar" aria-label="Open navigation">${icon('menu')}</button>
    <div class="breadcrumbs"><span>Tan90 Pulse</span>${icon('chevron',12)}<strong>${meta.title}</strong></div>
    <label class="global-search">${icon('search')}<input id="globalSearch" placeholder="Search tasks, approvals, users or commands…" autocomplete="off"><span class="search-shortcut">Ctrl K</span></label>
    <div class="top-actions"><button class="icon-btn" data-action="theme" title="Switch theme">${icon(state.theme === 'dark' ? 'sun' : 'moon')} </button><button class="icon-btn" data-action="notifications" title="Notifications">${icon('bell')}<i class="notification-dot"></i></button><button class="profile-trigger" data-action="switch-persona"><span class="persona-avatar" style="background:linear-gradient(145deg,${role.color}bb,${role.color}66)">${escapeHtml(user.initials)}</span><span class="profile-copy"><strong>${escapeHtml(user.name)}</strong><span>${escapeHtml(role.name)}</span></span>${icon('down',13)}</button></div>
  </header>`;
}

function pageHeader(actions = '') {
  const meta = pageMeta[state.view] || pageMeta.dashboard;
  return `<div class="page-head"><div><span class="eyebrow"><i></i>${meta.eyebrow}</span><h1>${meta.title}</h1><p>${meta.description}</p></div><div class="page-actions">${actions}</div></div>`;
}

function renderShell() {
  const page = renderPage();
  return `<div class="app-shell" data-theme="${state.theme}">${renderSidebar()}<main class="main">${renderTopbar()}<div class="page">${page}</div></main></div>`;
}

function renderPage() {
  if (!navItems.find((item) => item.id === state.view && has(item.permission))) state.view = 'dashboard';
  const renderers = {dashboard:renderDashboard, work:renderWork, approvals:renderApprovals, exceptions:renderExceptions, builder:renderBuilder, roles:renderRoles, users:renderUsers, audit:renderAudit, simulator:renderSimulator};
  return (renderers[state.view] || renderDashboard)();
}

function metricCard(widgetId, label, value, delta, meta, iconName, color, soft, down = false) {
  const widget = widgetCatalog.find((item) => item.id === widgetId);
  if (widget && !has(widget.permission)) return '';
  return `<article class="metric-card" style="--metric:${color};--metric-soft:${soft}"><div class="metric-top"><div><div class="metric-label">${label}</div></div><div class="metric-icon">${icon(iconName,17)}</div></div><div class="metric-value">${value}</div><div class="metric-bottom"><span class="metric-delta ${down ? 'down' : ''}">${delta}</span><span class="metric-meta">${meta}</span></div></article>`;
}

function renderDashboard() {
  const user = currentUser();
  const activeTasks = visibleTasksFor().filter((task) => task.status !== 'done');
  const activeApprovals = visibleApprovalsFor().filter((approval) => approval.status === 'pending');
  const openExceptions = visibleExceptionsFor().filter((item) => item.status !== 'resolved');
  const layout = getPersonalLayout(user).filter((item) => {
    const widget = widgetCatalog.find((w) => w.id === item.id);
    return widget && has(widget.permission);
  });
  const actions = `${has('space.builder.personal') ? `<button class="btn" data-action="navigate" data-view="builder">${icon('builder',15)} Customise</button>` : ''}<button class="btn btn-primary" data-action="quick-create">${icon('plus',15)} Quick action</button>`;
  return `${pageHeader(actions)}<div class="dashboard-shell">
    <div class="dashboard-topline"><section class="command-banner"><div class="command-banner-content"><div><span class="live-chip"><i></i> Live · ${escapeHtml(user.plant)}</span><h2>Good ${new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 18 ? 'afternoon' : 'evening'}, ${escapeHtml(user.name.split(' ')[0])}.</h2><p>${user.level === 1 ? 'Organisation cockpit is showing cross-unit decisions, exceptions and governance activity.' : user.level === 2 ? 'Your plant and subordinate team queues are prioritised by operational impact and SLA.' : 'Only your authorised widgets and assigned operational work are visible here.'}</p><div class="command-banner-actions"><button class="btn btn-primary" data-action="navigate" data-view="work">${icon('task',14)} Open my work <span class="stat-chip">${activeTasks.length}</span></button>${has('space.approvals.view') ? `<button class="btn" data-action="navigate" data-view="approvals">${icon('approvals',14)} ${activeApprovals.length} approvals</button>` : ''}<button class="btn" data-action="navigate" data-view="exceptions">${icon('alert',14)} ${openExceptions.length} exceptions</button></div></div><div class="shift-score"><div><strong>87%</strong><span>Shift health</span></div></div></div></section>
    <section class="now-card"><h3>Live operating pulse</h3><p>Auto-refreshed demo snapshot</p><div class="now-line"><div><strong>Line 2</strong><span>Thermal Sachet · WO-2608-031</span></div><i class="live-pulse"></i></div><div class="now-line"><div><strong>Inbound dock 1</strong><span>2 vehicles unloading</span></div><span class="status status-green">On track</span></div><div class="now-line"><div><strong>Next escalation</strong><span>PCM purchase approval</span></div><strong>42m</strong></div></section></div>
    <div class="card-grid">${metricCard('production','TODAY PRODUCTION','18,420','+8.4%','vs plan','factory','#0fbd8c','#e7fbf4')}${metricCard('pendingQc','PENDING QC','34','6 critical','batches','quality','#7857e8','#f1edff',true)}${metricCard('lowStock','LOW STOCK','12','3 immediate','materials','stock','#e99a18','#fff6df',true)}${metricCard('dispatch','DISPATCH CLOSURE','91%','+4.2%','POD uploaded','truck','#2979ff','#eaf2ff')}${metricCard('wastage','WASTAGE','2.1%','0.3% above','target 1.8%','waste','#df5062','#fff0f2',true)}${metricCard('machine','MACHINE UTILISATION','82%','+5.8%','6 active','machine','#14a3b8','#e8f9fb')}</div>
    <section class="widget-grid">${layout.map(renderDashboardWidget).join('')}</section>
  </div>`;
}

function widgetShell(item, body, subtitle) {
  const widget = widgetCatalog.find((w) => w.id === item.id);
  if (!widget) return '';
  return `<article class="widget" style="--span:${item.span};--widget-color:${widget.color};--widget-soft:${widget.soft}" data-locked="${Boolean(item.locked)}"><header class="widget-head"><div class="widget-title"><span class="widget-icon">${icon(widget.icon,16)}</span><div><h3>${escapeHtml(widget.name)}</h3><p>${escapeHtml(subtitle || widget.description)}</p></div></div><div class="widget-actions"><button class="widget-action" data-action="widget-drilldown" data-widget="${widget.id}" title="Drill down">${icon('eye',13)}</button><button class="widget-action" data-action="widget-menu" data-widget="${widget.id}" title="Options">${icon('more',13)}</button></div></header><div class="widget-body">${body}</div></article>`;
}

function renderDashboardWidget(item) {
  const tasks = visibleTasksFor().filter((task) => task.status !== 'done');
  const approvals = visibleApprovalsFor().filter((approval) => approval.status === 'pending');
  const exceptions = visibleExceptionsFor().filter((exception) => exception.status !== 'resolved');
  const renderers = {
    production:() => `<div class="metric-value">18,420</div><div class="chart-legend"><span class="legend-item"><i style="--legend:#0fbd8c"></i>Target 17,000</span><span class="legend-item"><i style="--legend:#2979ff"></i>Good output 17,960</span></div><div class="flow-bar" style="margin-top:18px"><i style="--value:92%"></i></div>`,
    pendingQc:() => `<div class="metric-value">34</div><div class="task-mini-list" style="margin-top:14px"><div class="task-mini"><span class="task-type-icon" style="--task-color:#7857e8;--task-soft:#f1edff">${icon('quality',14)}</span><div><strong>Incoming</strong><span>14 batches · 3 high priority</span></div><b>14</b></div><div class="task-mini"><span class="task-type-icon" style="--task-color:#7857e8;--task-soft:#f1edff">${icon('quality',14)}</span><div><strong>In-process + final</strong><span>20 checkpoints</span></div><b>20</b></div></div>`,
    lowStock:() => `<div class="metric-value">12</div><div class="exception-list" style="margin-top:14px"><div class="exception-row" style="--severity:#df5062"><i></i><div><strong>PCM Compound A01</strong><span>16h coverage</span></div><b>Critical</b></div><div class="exception-row" style="--severity:#e99a18"><i></i><div><strong>Sachet Film 200</strong><span>2.4 days coverage</span></div><b>Low</b></div></div>`,
    dispatch:() => `<div class="metric-value">91%</div><div class="flow-map" style="margin-top:18px"><div class="flow-stage"><label>Dispatched</label><div class="flow-bar"><i style="--value:96%"></i></div><b>48</b></div><div class="flow-stage"><label>POD received</label><div class="flow-bar"><i style="--value:91%"></i></div><b>44</b></div><div class="flow-stage"><label>Closed</label><div class="flow-bar"><i style="--value:86%"></i></div><b>41</b></div></div>`,
    wastage:() => `<div class="metric-value">2.1%</div><div class="flow-map" style="margin-top:18px"><div class="flow-stage"><label>Sealing</label><div class="flow-bar"><i style="--value:72%;background:#df5062"></i></div><b>145</b></div><div class="flow-stage"><label>Leakage</label><div class="flow-bar"><i style="--value:38%;background:#e99a18"></i></div><b>78</b></div><div class="flow-stage"><label>Handling</label><div class="flow-bar"><i style="--value:22%;background:#2979ff"></i></div><b>44</b></div></div>`,
    machine:() => `<div class="metric-value">82%</div><div class="flow-map" style="margin-top:18px"><div class="flow-stage"><label>Line 1</label><div class="flow-bar"><i style="--value:64%;background:#df5062"></i></div><b>Down</b></div><div class="flow-stage"><label>Line 2</label><div class="flow-bar"><i style="--value:92%"></i></div><b>Run</b></div><div class="flow-stage"><label>Line 3</label><div class="flow-bar"><i style="--value:88%"></i></div><b>Run</b></div></div>`,
    productionTrend:() => `<div class="chart-wrap"><canvas id="productionTrendCanvas"></canvas></div><div class="chart-legend"><span class="legend-item"><i style="--legend:#0fbd8c"></i>Actual</span><span class="legend-item"><i style="--legend:#91a0b5"></i>Target</span><span class="legend-item"><i style="--legend:#2979ff"></i>Good output</span></div>`,
    myTasks:() => `<div class="task-mini-list">${tasks.slice(0,4).map((task) => `<div class="task-mini"><span class="task-type-icon" style="--task-color:${task.priority === 'high' ? '#df5062' : task.priority === 'medium' ? '#e99a18' : '#2979ff'};--task-soft:${task.priority === 'high' ? '#fff0f2' : task.priority === 'medium' ? '#fff6df' : '#eaf2ff'}">${icon(task.type.includes('QC') ? 'quality' : task.type.includes('POD') ? 'truck' : 'task',14)}</span><div><strong>${escapeHtml(task.title)}</strong><span>${escapeHtml(task.due)} · ${escapeHtml(task.id)}</span></div><button data-action="open-task" data-id="${task.id}">${icon('chevron',13)}</button></div>`).join('') || emptyInline('No active tasks')}</div>`,
    approvalQueue:() => `<div class="task-mini-list">${approvals.slice(0,4).map((approval) => `<div class="task-mini"><span class="task-type-icon" style="--task-color:#7857e8;--task-soft:#f1edff">${icon('approvals',14)}</span><div><strong>${escapeHtml(approval.title)}</strong><span>${escapeHtml(approval.amount)} · ${escapeHtml(approval.sla)}</span></div><button data-action="open-approval" data-id="${approval.id}">${icon('chevron',13)}</button></div>`).join('') || emptyInline('No pending approvals')}</div>`,
    exceptions:() => `<div class="exception-list">${exceptions.slice(0,5).map((exception) => `<div class="exception-row" style="--severity:${severityColor(exception.severity)}"><i></i><div><strong>${escapeHtml(exception.title)}</strong><span>${escapeHtml(exception.plant)} · ${escapeHtml(exception.age)}</span></div><b>${escapeHtml(exception.severity)}</b></div>`).join('') || emptyInline('No open exceptions')}</div>`,
    processFlow:() => `<div class="flow-map">${[['Inbound',88],['GRN + QC',76],['Production',92],['Final QC',81],['Warehouse',90],['Dispatch',86]].map(([label,value]) => `<div class="flow-stage"><label>${label}</label><div class="flow-bar"><i style="--value:${value}%"></i></div><b>${value}%</b></div>`).join('')}</div>`,
    unitPerformance:() => `<div class="chart-wrap"><canvas id="unitPerformanceCanvas"></canvas></div><div class="chart-legend"><span class="legend-item"><i style="--legend:#0fbd8c"></i>Bangalore</span><span class="legend-item"><i style="--legend:#2979ff"></i>Chennai</span><span class="legend-item"><i style="--legend:#7857e8"></i>Pune</span></div>`,
    activity:() => `<div class="task-mini-list">${state.audit.slice(0,4).map((log) => `<div class="task-mini"><span class="task-type-icon" style="--task-color:#0fbd8c;--task-soft:#e7fbf4">${icon('activity',14)}</span><div><strong>${escapeHtml(log.action)}</strong><span>${escapeHtml(log.actor)} · ${humanTime(log.at)}</span></div></div>`).join('')}</div>`,
    quickActions:() => `<div class="task-mini-list">${[['Post a GRN','task'],['Complete QC','quality'],['Record output','factory'],['Upload POD','truck']].map(([label,ic]) => `<button class="task-mini" style="width:100%;text-align:left" data-action="quick-create" data-kind="${label}"><span class="task-type-icon" style="--task-color:#0fbd8c;--task-soft:#e7fbf4">${icon(ic,14)}</span><div><strong>${label}</strong><span>Start authorised workflow</span></div>${icon('plus',13)}</button>`).join('')}</div>`,
    sla:() => `<div class="metric-value">93.4%</div><div class="flow-map" style="margin-top:17px"><div class="flow-stage"><label>Tasks</label><div class="flow-bar"><i style="--value:94%"></i></div><b>94%</b></div><div class="flow-stage"><label>Approvals</label><div class="flow-bar"><i style="--value:88%;background:#e99a18"></i></div><b>88%</b></div><div class="flow-stage"><label>Exceptions</label><div class="flow-bar"><i style="--value:91%;background:#2979ff"></i></div><b>91%</b></div></div>`
  };
  return widgetShell(item, (renderers[item.id] || (() => emptyInline('Widget preview')))());
}

function emptyInline(text) { return `<div class="empty-state" style="padding:18px"><p>${escapeHtml(text)}</p></div>`; }
function severityColor(severity) { return severity === 'critical' ? '#df5062' : severity === 'high' ? '#e46a3d' : severity === 'medium' ? '#e99a18' : '#2979ff'; }

function renderWork() {
  const visible = visibleTasksFor();
  const filtered = visible.filter((task) => {
    const q = state.work.search.toLowerCase();
    const searchPass = !q || [task.id, task.title, task.type, task.module, task.reference, task.plant].join(' ').toLowerCase().includes(q);
    const priorityPass = state.work.priority === 'all' || task.priority === state.work.priority;
    const modulePass = state.work.module === 'all' || task.module === state.work.module;
    const tabPass = state.work.tab === 'all' || (state.work.tab === 'active' ? task.status !== 'done' : task.status === state.work.tab);
    return searchPass && priorityPass && modulePass && tabPass;
  });
  const actions = `<button class="btn" data-action="export-work">${icon('download',15)} Export</button><button class="btn btn-primary" data-action="quick-create">${icon('plus',15)} Start work</button>`;
  const statusColumns = [
    {id:'todo', label:'To do'}, {id:'in_progress', label:'In progress'}, {id:'blocked', label:'Blocked'}, {id:'done', label:'Completed'}
  ];
  const tabs = [['active','Active'],['todo','To do'],['in_progress','In progress'],['blocked','Blocked'],['done','Completed'],['all','All']];
  return `${pageHeader(actions)}
    <div class="tabs">${tabs.map(([id,label]) => `<button data-action="work-tab" data-tab="${id}" class="${state.work.tab === id ? 'active' : ''}">${label} <span class="stat-chip">${id === 'active' ? visible.filter((t) => t.status !== 'done').length : id === 'all' ? visible.length : visible.filter((t) => t.status === id).length}</span></button>`).join('')}</div>
    <div class="toolbar"><label class="search-field">${icon('search')}<input id="workSearch" value="${escapeHtml(state.work.search)}" placeholder="Search task, batch, PO, WO or shipment…"></label><select class="select-control" id="workPriority"><option value="all">All priorities</option>${['high','medium','low'].map((p) => `<option value="${p}" ${state.work.priority === p ? 'selected' : ''}>${p[0].toUpperCase()+p.slice(1)}</option>`).join('')}</select><select class="select-control" id="workModule"><option value="all">All modules</option>${[...new Set(visible.map((t) => t.module))].map((m) => `<option value="${m}" ${state.work.module === m ? 'selected' : ''}>${m}</option>`).join('')}</select><div class="segmented"><button data-action="work-view" data-mode="board" class="${state.work.view === 'board' ? 'active' : ''}" title="Board">${icon('board',15)}</button><button data-action="work-view" data-mode="list" class="${state.work.view === 'list' ? 'active' : ''}" title="List">${icon('list',15)}</button></div><button class="btn btn-sm">${icon('columns',14)} Saved view</button></div>
    ${state.work.view === 'board' ? `<div class="board">${statusColumns.map((column) => { const items = filtered.filter((task) => task.status === column.id); return `<section class="board-column"><header class="board-head"><strong>${column.label}</strong><span>${items.length}</span></header><div class="board-cards">${items.map(taskCard).join('') || emptyInline('No tasks')}</div></section>`; }).join('')}</div>` : renderTaskTable(filtered)}
  `;
}

function taskCard(task) {
  return `<article class="task-card" data-action="open-task" data-id="${task.id}"><div class="task-card-top"><span class="status priority-${task.priority}">${escapeHtml(task.priority)}</span><span class="muted mono">${escapeHtml(task.id)}</span></div><h4>${escapeHtml(task.title)}</h4><p>${escapeHtml(task.description)}</p><div class="task-card-foot"><div class="avatar-stack"><span>${escapeHtml(userById(task.assignedTo)?.initials || '—')}</span></div><span>${escapeHtml(task.due)}</span></div></article>`;
}

function renderTaskTable(tasks) {
  return `<div class="table-wrap"><table><thead><tr><th>Task</th><th>Module</th><th>Priority</th><th>Plant / Team</th><th>Assignee</th><th>Due / SLA</th><th>Status</th><th>Action</th></tr></thead><tbody>${tasks.map((task) => `<tr><td><div class="table-primary"><span class="task-type-icon" style="--task-color:${task.priority === 'high' ? '#df5062' : task.priority === 'medium' ? '#e99a18' : '#2979ff'};--task-soft:${task.priority === 'high' ? '#fff0f2' : task.priority === 'medium' ? '#fff6df' : '#eaf2ff'}">${icon(task.type.includes('QC') ? 'quality' : task.type.includes('POD') ? 'truck' : 'task',14)}</span><div><strong>${escapeHtml(task.title)}</strong><span>${escapeHtml(task.id)} · ${escapeHtml(task.reference)}</span></div></div></td><td>${escapeHtml(task.module)}<div class="muted">${escapeHtml(task.type)}</div></td><td><span class="status priority-${task.priority}">${escapeHtml(task.priority)}</span></td><td>${escapeHtml(task.plant)}<div class="muted">${escapeHtml(task.team)}</div></td><td>${escapeHtml(userById(task.assignedTo)?.name || 'Unassigned')}</td><td>${escapeHtml(task.due)}<div class="muted">Age ${escapeHtml(task.age)}</div></td><td><span class="status ${task.status === 'done' ? 'status-green' : task.status === 'blocked' ? 'status-red' : task.status === 'in_progress' ? 'status-blue' : 'status-gray'}">${task.status.replace('_',' ')}</span></td><td><button class="btn btn-xs" data-action="open-task" data-id="${task.id}">Open</button></td></tr>`).join('') || `<tr><td colspan="8">${emptyInline('No tasks match the current view.')}</td></tr>`}</tbody></table></div><div class="pagination"><span>Showing ${tasks.length} authorised tasks</span><div class="pagination-buttons"><button>‹</button><button class="active">1</button><button>2</button><button>›</button></div></div>`;
}

function renderApprovals() {
  const all = visibleApprovalsFor();
  const filtered = all.filter((approval) => state.approvalFilter === 'all' || approval.status === state.approvalFilter);
  const pendingValue = all.filter((a) => a.status === 'pending').reduce((total,a) => total + a.numericAmount,0);
  const actions = `<button class="btn" data-action="export-approvals">${icon('download',15)} Export</button><button class="btn" data-action="navigate" data-view="simulator">${icon('shield',15)} Test access</button>`;
  if (!has('space.approvals.view')) return `${pageHeader()}${lockedPage('Approval Center','Your current role does not include approval visibility.')}`;
  return `${pageHeader(actions)}<div class="approval-summary"><div class="summary-card"><span>Pending requests</span><strong>${all.filter((a) => a.status === 'pending').length}</strong></div><div class="summary-card"><span>Pending value</span><strong>₹${(pendingValue/100000).toFixed(1)}L</strong></div><div class="summary-card"><span>High risk</span><strong>${all.filter((a) => a.status === 'pending' && a.risk === 'High').length}</strong></div><div class="summary-card"><span>Overdue</span><strong>${all.filter((a) => a.sla.toLowerCase().includes('overdue')).length}</strong></div></div>
  <div class="tabs">${[['pending','Pending'],['approved','Approved'],['rejected','Rejected'],['returned','Returned'],['all','All']].map(([id,label]) => `<button data-action="approval-filter" data-filter="${id}" class="${state.approvalFilter === id ? 'active' : ''}">${label}</button>`).join('')}</div>
  <div>${filtered.map((approval) => `<article class="approval-card"><div><div class="flex items-center gap-8"><span class="status ${approval.risk === 'High' ? 'status-red' : approval.risk === 'Medium' ? 'status-amber' : 'status-blue'}">${escapeHtml(approval.risk)} risk</span><span class="muted mono">${escapeHtml(approval.id)}</span></div><h3>${escapeHtml(approval.title)}</h3><p>${escapeHtml(approval.details)}</p><div class="approval-meta"><span>${escapeHtml(approval.type)}</span><span>${escapeHtml(approval.department)}</span><span>${escapeHtml(approval.plant)}</span><span>Requested by ${escapeHtml(approval.requester)}</span><span>${escapeHtml(approval.sla)}</span><span>${has('field.financial_value.view') ? escapeHtml(approval.amount) : 'Value masked'}</span></div></div><div class="approval-buttons">${approval.status === 'pending' ? `${has('space.approvals.return') ? `<button class="btn btn-sm" data-action="approval-action" data-id="${approval.id}" data-result="returned">Return</button>` : ''}${has('space.approvals.reject') ? `<button class="btn btn-sm btn-danger" data-action="approval-action" data-id="${approval.id}" data-result="rejected">Reject</button>` : ''}${has('space.approvals.approve') ? `<button class="btn btn-sm btn-primary" data-action="approval-action" data-id="${approval.id}" data-result="approved">${icon('check',13)} Approve</button>` : ''}` : `<span class="status ${approval.status === 'approved' ? 'status-green' : approval.status === 'rejected' ? 'status-red' : 'status-amber'}">${approval.status}</span>`}<button class="row-action" data-action="open-approval" data-id="${approval.id}">${icon('eye',13)}</button></div></article>`).join('') || emptyPanel('No approvals','There are no approvals in this status for your scope.')}</div>`;
}

function renderExceptions() {
  const all = visibleExceptionsFor();
  const filtered = all.filter((exception) => state.exceptionFilter === 'all' || exception.severity === state.exceptionFilter || exception.status === state.exceptionFilter || exception.category.toLowerCase() === state.exceptionFilter);
  const counts = {all:all.length,critical:all.filter((e)=>e.severity==='critical').length,high:all.filter((e)=>e.severity==='high').length,medium:all.filter((e)=>e.severity==='medium').length,acknowledged:all.filter((e)=>e.status==='acknowledged').length};
  const actions = `<button class="btn" data-action="export-exceptions">${icon('download',15)} Export</button><button class="btn btn-primary" data-action="exception-create">${icon('plus',15)} Log exception</button>`;
  return `${pageHeader(actions)}<div class="exception-grid"><aside class="panel exception-sidebar"><h3>Exception filters</h3><div class="filter-list">${[['all','All exceptions'],['critical','Critical'],['high','High'],['medium','Medium'],['acknowledged','Acknowledged'],['machine','Machine'],['quality','Quality'],['inventory','Inventory'],['dispatch','Dispatch']].map(([id,label]) => `<button class="filter-item ${state.exceptionFilter === id ? 'active' : ''}" data-action="exception-filter" data-filter="${id}">${icon(id === 'machine' ? 'machine' : id === 'quality' ? 'quality' : id === 'inventory' ? 'stock' : id === 'dispatch' ? 'truck' : 'alert',14)}<span>${label}</span><span>${counts[id] ?? all.filter((e)=>e.category.toLowerCase()===id).length}</span></button>`).join('')}</div><div class="locked-callout" style="margin-top:13px">${icon('info',16)}<div><strong>Role-aware alerts</strong><span>Executives see owned or assigned exceptions. Managers see their plant/team. Super Admin sees all units.</span></div></div></aside><section>${filtered.map((exception) => `<article class="exception-card" style="--severity:${severityColor(exception.severity)}"><i class="exception-severity"></i><div><div class="flex items-center gap-8"><span class="status ${exception.severity === 'critical' ? 'status-red' : exception.severity === 'high' ? 'status-amber' : 'status-blue'}">${escapeHtml(exception.severity)}</span><span class="mono muted">${escapeHtml(exception.id)}</span></div><h3>${escapeHtml(exception.title)}</h3><p>${escapeHtml(exception.description)}</p><div class="exception-meta"><span>${escapeHtml(exception.category)}</span><span>${escapeHtml(exception.plant)}</span><span>Owner: ${escapeHtml(exception.owner)}</span><span>Age: ${escapeHtml(exception.age)}</span><span>${escapeHtml(exception.impact)}</span><span>Rule: ${escapeHtml(exception.rule)}</span></div></div><div class="exception-card-actions">${exception.status === 'open' && has('space.exceptions.ack') ? `<button class="btn btn-sm" data-action="exception-action" data-id="${exception.id}" data-result="acknowledged">Acknowledge</button>` : ''}${exception.status !== 'resolved' && has('space.exceptions.assign') ? `<button class="btn btn-sm" data-action="exception-assign" data-id="${exception.id}">Assign</button>` : ''}${exception.status !== 'resolved' && has('space.exceptions.resolve') ? `<button class="btn btn-sm btn-primary" data-action="exception-action" data-id="${exception.id}" data-result="resolved">Resolve</button>` : `<span class="status ${exception.status === 'resolved' ? 'status-green' : 'status-blue'}">${exception.status}</span>`}</div></article>`).join('') || emptyPanel('No matching exceptions','No exceptions are available for the current filter and access scope.')}</section></div>`;
}

function lockedPage(title, text) { return `<div class="panel"><div class="empty-state"><div class="metric-icon">${icon('lock',22)}</div><h3>${escapeHtml(title)} is restricted</h3><p>${escapeHtml(text)}</p><button class="btn" data-action="navigate" data-view="simulator">Explain access</button></div></div>`; }
function emptyPanel(title, text) { return `<div class="panel"><div class="empty-state"><div class="metric-icon">${icon('check',22)}</div><h3>${escapeHtml(title)}</h3><p>${escapeHtml(text)}</p></div></div>`; }

function builderTargetOptions() {
  const user = currentUser();
  const role = currentRole();
  const options = [{type:'personal',label:'My personal dashboard',allowed:role.dashboardRights.personal}];
  if (role.dashboardRights.team) options.push({type:'team',label:'Team dashboard',allowed:true});
  if (role.dashboardRights.role) options.push({type:'role',label:'Role template',allowed:true});
  if (role.dashboardRights.org) options.push({type:'organisation',label:'Organisation baseline',allowed:true});
  return options;
}

function targetIdOptions(type) {
  const user = currentUser();
  if (type === 'personal') {
    const users = user.level === 1 ? state.users.filter((u) => u.status === 'active') : user.level === 2 ? visibleUsersFor().filter((u) => u.status === 'active') : [user];
    return users.map((u) => ({id:u.id,label:`${u.name} · ${roleById(u.roleId).name}`}));
  }
  if (type === 'team') {
    const teams = [...new Set(visibleUsersFor().map((u) => u.team))];
    return teams.map((team) => ({id:team,label:team}));
  }
  if (type === 'role') {
    return state.roles.filter((role) => role.level > user.level).map((role) => ({id:role.id,label:`${role.name} · L${role.level}`}));
  }
  return [{id:'default',label:'All units · Organisation'}];
}

function canEditBuilderTarget() {
  const role = currentRole();
  const type = state.builder.targetType;
  if (type === 'personal') return role.dashboardRights.personal;
  if (type === 'team') return role.dashboardRights.team;
  if (type === 'role') return role.dashboardRights.role;
  return role.dashboardRights.org;
}

function renderBuilder() {
  if (!has('space.builder.personal')) return `${pageHeader()}${lockedPage('Dashboard Builder','This role does not have dashboard personalisation permission.')}`;
  const targetTypes = builderTargetOptions();
  if (!targetTypes.some((item) => item.type === state.builder.targetType)) state.builder.targetType = targetTypes[0].type;
  let targetOptions = targetIdOptions(state.builder.targetType);
  if (!targetOptions.some((item) => item.id === state.builder.targetId)) state.builder.targetId = targetOptions[0]?.id || currentUser().id;
  const {layout} = getBuilderTarget();
  const selected = layout.find((item) => item.id === state.builder.selectedWidgetId) || null;
  const editable = canEditBuilderTarget();
  const availableWidgets = widgetCatalog.filter((widget) => has(widget.permission));
  const groups = [...new Set(availableWidgets.map((widget) => widget.category))];
  const actions = `<button class="btn" data-action="builder-reset">${icon('refresh',15)} Reset</button><button class="btn" data-action="builder-preview">${icon('eye',15)} Preview</button>${has('space.builder.publish') && editable ? `<button class="btn btn-primary" data-action="builder-publish">${icon('publish',15)} Publish</button>` : `<button class="btn btn-primary" data-action="builder-save">${icon('save',15)} Save personal</button>`}`;
  return `${pageHeader(actions)}<div class="builder-shell">
    <aside class="panel builder-sidebar"><div class="builder-library"><div class="builder-library-head"><h3>Widget library</h3><span class="stat-chip">${availableWidgets.length} allowed</span></div><label class="library-search">${icon('search',14)}<input id="builderSearch" value="${escapeHtml(state.builder.search)}" placeholder="Search widgets…"></label>${groups.map((group) => { const widgets = availableWidgets.filter((widget) => widget.category === group && (!state.builder.search || widget.name.toLowerCase().includes(state.builder.search.toLowerCase()))); if (!widgets.length) return ''; return `<div class="library-group-title">${group}</div><div class="library-list">${widgets.map((widget) => { const added = layout.some((item) => item.id === widget.id); return `<div class="library-item ${added ? 'disabled' : ''}"><span class="widget-icon" style="--widget-color:${widget.color};--widget-soft:${widget.soft};color:${widget.color};background:${widget.soft}">${icon(widget.icon,14)}</span><div><strong>${escapeHtml(widget.name)}</strong><span>${escapeHtml(widget.description)}</span></div><button data-action="builder-add" data-widget="${widget.id}" ${added || !editable ? 'disabled' : ''}>${icon(added ? 'check' : 'plus',12)}</button></div>`; }).join('')}</div>`; }).join('')}</div></aside>
    <main class="builder-main"><div class="builder-toolbar"><select class="select-control" id="builderTargetType">${targetTypes.map((item) => `<option value="${item.type}" ${state.builder.targetType === item.type ? 'selected' : ''}>${item.label}</option>`).join('')}</select><select class="select-control" id="builderTargetId">${targetOptions.map((item) => `<option value="${escapeHtml(item.id)}" ${state.builder.targetId === item.id ? 'selected' : ''}>${escapeHtml(item.label)}</option>`).join('')}</select><div class="segmented"><button data-action="builder-device" data-device="desktop" class="${state.builder.device === 'desktop' ? 'active' : ''}" title="Desktop">${icon('desktop',14)}</button><button data-action="builder-device" data-device="tablet" class="${state.builder.device === 'tablet' ? 'active' : ''}" title="Tablet">${icon('tablet',14)}</button><button data-action="builder-device" data-device="mobile" class="${state.builder.device === 'mobile' ? 'active' : ''}" title="Mobile">${icon('mobile',14)}</button></div><button class="square-btn" data-action="builder-undo" ${state.builder.history.length ? '' : 'disabled'} title="Undo">${icon('undo',14)}</button><button class="square-btn" data-action="builder-redo" ${state.builder.future.length ? '' : 'disabled'} title="Redo">${icon('redo',14)}</button><span class="stat-chip">${editable ? 'Editable' : 'Read-only'}</span></div>
      <div class="builder-canvas-wrap"><div class="builder-frame ${state.builder.device}"><div class="builder-grid" id="builderGrid">${layout.length ? layout.map((item) => renderBuilderWidget(item, editable)).join('') : `<div class="builder-empty"><div>${icon('builder',34)}<strong>Start with a clean dashboard</strong><span>Add authorised widgets from the library.</span></div></div>`}</div></div></div></main>
    <aside class="panel builder-properties">${selected ? renderWidgetProperties(selected, editable) : `<h3>Widget properties</h3><p>Select a widget on the canvas to configure size, visibility and locks.</p><div class="empty-state" style="padding:28px 8px"><div class="metric-icon">${icon('settings',20)}</div><h3>No widget selected</h3><p>Click any canvas widget to edit its properties.</p></div>`}</aside>
  </div>`;
}

function renderBuilderWidget(item, editable) {
  const widget = widgetCatalog.find((entry) => entry.id === item.id);
  if (!widget) return '';
  const locked = Boolean(item.locked || item.mandatory) && currentUser().level >= 3;
  return `<article class="builder-widget ${state.builder.selectedWidgetId === item.id ? 'selected' : ''} ${item.locked ? 'locked' : ''}" style="--span:${item.span}" draggable="${editable && !locked}" data-builder-widget="${item.id}" data-action="builder-select" data-widget="${item.id}"><header class="builder-widget-head"><span class="drag-handle">${icon('grip',14)}</span><span class="widget-icon" style="width:26px;height:26px;border-radius:8px;color:${widget.color};background:${widget.soft}">${icon(widget.icon,12)}</span><strong>${escapeHtml(item.customTitle || widget.name)}</strong><div class="builder-widget-tools"><button data-action="builder-select" data-widget="${item.id}" title="Configure">${icon('settings',11)}</button>${!item.mandatory ? `<button data-action="builder-remove" data-widget="${item.id}" ${!editable || locked ? 'disabled' : ''} title="Remove">${icon('close',11)}</button>` : ''}</div></header><div class="builder-placeholder">${placeholderForWidget(widget)}</div></article>`;
}

function placeholderForWidget(widget) {
  if (['production','pendingQc','lowStock','dispatch','wastage','machine','sla'].includes(widget.id)) return `<div style="text-align:center"><div class="metric-value" style="font-size:23px">${widget.id === 'production' ? '18,420' : widget.id === 'pendingQc' ? '34' : widget.id === 'lowStock' ? '12' : widget.id === 'dispatch' ? '91%' : widget.id === 'wastage' ? '2.1%' : widget.id === 'machine' ? '82%' : '93.4%'}</div><span class="muted" style="font-size:7px">Live preview</span></div>`;
  if (widget.id === 'myTasks' || widget.id === 'approvalQueue' || widget.id === 'exceptions' || widget.id === 'activity' || widget.id === 'quickActions') return `<div class="task-mini-list" style="width:100%"><div class="task-mini"><span class="task-type-icon" style="--task-color:${widget.color};--task-soft:${widget.soft}">${icon(widget.icon,12)}</span><div><strong>Preview row</strong><span>Permission-aware content</span></div></div><div class="task-mini"><span class="task-type-icon" style="--task-color:${widget.color};--task-soft:${widget.soft}">${icon(widget.icon,12)}</span><div><strong>Preview row</strong><span>Scope-filtered data</span></div></div></div>`;
  return `<div class="placeholder-bars">${[35,58,44,72,62,88,78,92].map((height) => `<i style="--h:${height}%"></i>`).join('')}</div>`;
}

function renderWidgetProperties(item, editable) {
  const widget = widgetCatalog.find((entry) => entry.id === item.id);
  const canLock = has('space.builder.lock') && currentUser().level <= 2;
  const effectiveLocked = item.mandatory && currentUser().level >= 3;
  return `<h3>${escapeHtml(widget.name)}</h3><p>${escapeHtml(widget.description)}</p><div class="field"><label>Custom title</label><input id="widgetCustomTitle" value="${escapeHtml(item.customTitle || '')}" placeholder="Use default title" ${!editable || effectiveLocked ? 'disabled' : ''}></div><div class="property-section"><h4>Widget width</h4><div class="size-options">${[[3,'Small'],[4,'Medium'],[6,'Wide'],[8,'Large'],[12,'Full']].map(([span,label]) => `<button data-action="builder-size" data-widget="${item.id}" data-span="${span}" class="${item.span === span ? 'active' : ''}" ${!editable || effectiveLocked ? 'disabled' : ''}>${label}</button>`).join('')}</div></div><div class="property-section"><h4>Inheritance & locks</h4><div class="toggle-row"><label>Mandatory widget</label><button class="switch ${item.mandatory ? 'on' : ''}" data-action="builder-toggle-property" data-widget="${item.id}" data-property="mandatory" ${!canLock ? 'disabled' : ''}><i></i></button></div><div class="toggle-row"><label>Lock position and size</label><button class="switch ${item.locked ? 'on' : ''}" data-action="builder-toggle-property" data-widget="${item.id}" data-property="locked" ${!canLock ? 'disabled' : ''}><i></i></button></div><div class="toggle-row"><label>Compact density</label><button class="switch ${item.compact ? 'on' : ''}" data-action="builder-toggle-property" data-widget="${item.id}" data-property="compact" ${!editable || effectiveLocked ? 'disabled' : ''}><i></i></button></div></div><div class="property-section"><h4>Data access</h4><div class="permission-note">${icon('shield',13)} Widget requires <span class="mono">${escapeHtml(widget.permission)}</span>. Layout permission never bypasses underlying data permission.</div></div>${!item.mandatory ? `<div class="property-section"><button class="btn btn-danger btn-sm" style="width:100%" data-action="builder-remove" data-widget="${item.id}" ${!editable || effectiveLocked ? 'disabled' : ''}>${icon('trash',13)} Remove widget</button></div>` : ''}`;
}

function rolePermissionState(role, code) {
  if (role.deny.includes(code)) return 'deny';
  if (role.allow.includes('*') || role.allow.includes(code)) return 'allow';
  return 'inherit';
}
function canEditRole(role) {
  const actor = currentUser();
  if (!actor || !has('space.roles.manage')) return false;
  if (role.level <= actor.level) return false;
  return actor.level === 1 || role.parentId === actor.roleId || role.level === 3;
}
function permissionEditableForRole(role, code) {
  if (!canEditRole(role)) return false;
  if (currentUser().level === 1) return true;
  return canDelegate(code);
}

function renderRoles() {
  const selectedRole = roleById(state.roleStudio.roleId) || state.roles.find((role) => role.level > currentUser().level) || currentRole();
  state.roleStudio.roleId = selectedRole.id;
  const editable = canEditRole(selectedRole);
  const actions = `${has('space.roles.manage') ? `<button class="btn" data-action="create-role">${icon('plus',15)} New role</button>` : ''}${editable ? `<button class="btn btn-primary" data-action="save-role">${icon('save',15)} Save & publish</button>` : ''}`;
  const rolesVisible = state.roles.filter((role) => currentUser().level === 1 || role.level >= currentUser().level);
  const allowedCount = permissionCatalog.filter((permission) => rolePermissionState(selectedRole, permission.code) === 'allow').length;
  const delegatedCount = selectedRole.delegate.includes('*') ? permissionCatalog.length : selectedRole.delegate.length;
  const assignedCount = state.users.filter((user) => user.roleId === selectedRole.id).length;
  return `${pageHeader(actions)}<section class="hierarchy-strip"><div class="hierarchy-level"><span>Level 1</span><strong>Super Admin</strong><p>Organisation-wide policy, dashboards, managers and every operational scope.</p></div><div class="hierarchy-level"><span>Level 2</span><strong>Manager</strong><p>Plant or vertical scope, subordinate role creation, team dashboards and direct grants.</p></div><div class="hierarchy-level"><span>Level 3</span><strong>Executive</strong><p>Assigned work, authorised views and personal customisation of unlocked widgets.</p></div></section>
    <div class="role-layout"><aside class="panel role-list">${rolesVisible.map((role) => `<div class="role-card ${role.id === selectedRole.id ? 'active' : ''}" data-action="select-role" data-role="${role.id}"><span class="role-orb" style="--role-color:${role.color};--role-soft:${role.soft}">L${role.level}</span><div><strong>${escapeHtml(role.name)}</strong><span>${escapeHtml(role.label)}</span></div><b>${state.users.filter((user) => user.roleId === role.id).length}</b></div>`).join('')}</aside>
      <section class="panel role-studio"><div class="studio-head"><span class="role-orb" style="--role-color:${selectedRole.color};--role-soft:${selectedRole.soft}">L${selectedRole.level}</span><div><h2>${escapeHtml(selectedRole.name)}</h2><p>${escapeHtml(selectedRole.description)} · Scope: ${escapeHtml(selectedRole.scope.type)}</p></div><div class="studio-stats"><div class="studio-stat"><strong>${allowedCount}</strong><span>Allowed</span></div><div class="studio-stat"><strong>${delegatedCount}</strong><span>Delegable</span></div><div class="studio-stat"><strong>${assignedCount}</strong><span>Users</span></div></div></div>
      <div class="studio-tabs">${[['permissions','Permissions'],['scope','Data scope'],['widgets','Widget access'],['dashboard','Dashboard rights'],['users','Assigned users'],['effective','Effective preview']].map(([id,label]) => `<button data-action="role-tab" data-tab="${id}" class="${state.roleStudio.tab === id ? 'active' : ''}">${label}</button>`).join('')}</div><div class="studio-body">${renderRoleTab(selectedRole, editable)}</div></section></div>`;
}

function renderRoleTab(role, editable) {
  const tabs = {
    permissions:() => renderPermissionMatrix(role, editable),
    scope:() => renderRoleScope(role, editable),
    widgets:() => renderRoleWidgets(role, editable),
    dashboard:() => renderRoleDashboardRights(role, editable),
    users:() => renderRoleUsers(role),
    effective:() => renderEffectiveRole(role)
  };
  return (tabs[state.roleStudio.tab] || tabs.permissions)();
}

function renderPermissionMatrix(role) {
  const groups = ['All', ...new Set(permissionCatalog.map((permission) => permission.group))];
  const q = state.roleStudio.search.toLowerCase();
  const permissions = permissionCatalog.filter((permission) => (state.roleStudio.group === 'All' || permission.group === state.roleStudio.group) && (!q || `${permission.name} ${permission.code} ${permission.description}`.toLowerCase().includes(q)));
  return `<div class="permission-toolbar"><label class="search-field"><span>${icon('search',14)}</span><input id="permissionSearch" value="${escapeHtml(state.roleStudio.search)}" placeholder="Search permission or code…"></label><select class="select-control" id="permissionGroup">${groups.map((group) => `<option value="${group}" ${state.roleStudio.group === group ? 'selected' : ''}>${group}</option>`).join('')}</select><span class="stat-chip">${permissions.length} permissions</span></div>
    <div class="locked-callout" style="margin-bottom:10px">${icon('shield',16)}<div><strong>Delegation ceiling enforced</strong><span>A manager can alter only subordinate roles and only permissions marked delegable by the manager's own role.</span></div></div>
    <div class="permission-matrix"><table><thead><tr><th>Permission</th><th>State</th><th>Delegable</th><th>Parent ceiling</th><th>Effective</th></tr></thead><tbody>${permissions.map((permission) => {
      const stateValue = rolePermissionState(role, permission.code);
      const editable = permissionEditableForRole(role, permission.code);
      const parent = roleById(role.parentId);
      const parentAllows = !parent || parent.allow.includes('*') || parent.allow.includes(permission.code);
      const parentDelegates = !parent || parent.delegate.includes('*') || parent.delegate.includes(permission.code);
      const effective = stateValue === 'allow' && parentAllows;
      return `<tr><td><div class="permission-name"><strong>${escapeHtml(permission.name)}</strong><span>${escapeHtml(permission.description)}</span><code class="permission-code">${escapeHtml(permission.code)}</code></div></td><td class="permission-cell"><div class="tri-toggle"><button class="inherit ${stateValue === 'inherit' ? 'active' : ''}" data-action="permission-state" data-role="${role.id}" data-code="${permission.code}" data-state="inherit" ${editable ? '' : 'disabled'} title="Inherit">I</button><button class="allow ${stateValue === 'allow' ? 'active' : ''}" data-action="permission-state" data-role="${role.id}" data-code="${permission.code}" data-state="allow" ${editable && parentAllows && parentDelegates ? '' : 'disabled'} title="Allow">${icon('check',12)}</button><button class="deny ${stateValue === 'deny' ? 'active' : ''}" data-action="permission-state" data-role="${role.id}" data-code="${permission.code}" data-state="deny" ${editable ? '' : 'disabled'} title="Deny">${icon('close',12)}</button></div></td><td class="permission-cell"><button class="checkbox ${role.delegate.includes('*') || role.delegate.includes(permission.code) ? 'on' : ''}" data-action="permission-delegate" data-role="${role.id}" data-code="${permission.code}" ${editable && stateValue === 'allow' && currentUser().level < 2 ? '' : 'disabled'}>${icon('check',11)}</button></td><td class="permission-cell"><span class="status ${parentAllows && parentDelegates ? 'status-green' : parentAllows ? 'status-amber' : 'status-red'}">${parentAllows ? (parentDelegates ? 'Grantable' : 'Use only') : 'Blocked'}</span></td><td class="permission-cell"><span class="status ${effective ? 'status-green' : 'status-red'}">${effective ? 'Allowed' : 'Denied'}</span></td></tr>`;
    }).join('')}</tbody></table></div>`;
}

function renderRoleScope(role, editable) {
  const scopeTypes = [
    {id:'all',name:'All organisation',desc:'All units, plants, teams and records'},
    {id:'plant',name:'Assigned plants',desc:'Records from selected manufacturing units'},
    {id:'team',name:'Managed team',desc:'Own team and subordinate records'},
    {id:'assigned',name:'Assigned records',desc:'Only self-assigned or explicitly shared records'}
  ];
  const dataDimensions = [
    ['Plant','Bangalore Unit, Chennai Unit, Pune Unit'],['Warehouse','RM Warehouse, FG Warehouse, Dispatch Staging'],['Team','Shift A, QC Team, Inbound Quality'],['Record ownership','Assigned, created, managed team'],['Time','Current shift, current day, date range'],['Status','Open, in progress, completed, archived']
  ];
  return `<div class="scope-grid">${scopeTypes.map((scope) => `<button class="scope-card" style="text-align:left;cursor:pointer;${role.scope.type === scope.id ? 'border-color:rgba(15,189,140,.35);background:var(--brand-soft)' : ''}" data-action="role-scope-type" data-role="${role.id}" data-scope="${scope.id}" ${editable ? '' : 'disabled'}><strong>${scope.name}</strong><p>${scope.desc}</p><span class="status ${role.scope.type === scope.id ? 'status-green' : 'status-gray'}">${role.scope.type === scope.id ? 'Selected' : 'Available'}</span></button>`).join('')}</div><div class="property-section"><h4>Scope dimensions</h4><div class="scope-grid">${dataDimensions.map(([name,values]) => `<div class="scope-card"><strong>${name}</strong><p>${values}</p><div class="scope-options">${role.scope.values.slice(0,3).map((value) => `<span class="scope-option active">${escapeHtml(value)}</span>`).join('')}<span class="scope-option">Configure</span></div></div>`).join('')}</div></div>`;
}

function renderRoleWidgets(role, editable) {
  return `<div class="widget-permission-grid">${widgetCatalog.map((widget) => { const allowed = role.widgetIds.includes(widget.id) && rolePermissionState(role, widget.permission) !== 'deny'; return `<div class="widget-permission"><span class="widget-icon" style="color:${widget.color};background:${widget.soft}">${icon(widget.icon,14)}</span><div><strong>${escapeHtml(widget.name)}</strong><span>${escapeHtml(widget.permission)}</span></div><button class="switch ${allowed ? 'on' : ''}" data-action="role-widget-toggle" data-role="${role.id}" data-widget="${widget.id}" ${editable && permissionEditableForRole(role, widget.permission) ? '' : 'disabled'}><i></i></button></div>`; }).join('')}</div><div class="locked-callout" style="margin-top:12px">${icon('info',16)}<div><strong>Widget access is not layout access</strong><span>A user needs both the widget permission and a dashboard layout containing that widget. Hidden buttons do not grant data access.</span></div></div>`;
}

function renderRoleDashboardRights(role, editable) {
  const rights = [['personal','Customise personal dashboard'],['team','Build team dashboard'],['role','Build role template'],['org','Build organisation baseline'],['publish','Publish dashboards'],['lock','Lock widget properties']];
  return `<div class="scope-grid">${rights.map(([key,label]) => `<div class="scope-card"><div class="toggle-row"><div><strong>${label}</strong><p>${key === 'personal' ? 'Reorder and resize unlocked widgets.' : key === 'team' ? 'Create defaults for directly managed teams.' : key === 'role' ? 'Publish default layout for subordinate role.' : key === 'org' ? 'Control organisation-wide starting layout.' : key === 'publish' ? 'Move a saved draft into active use.' : 'Lock visibility, position, size or configuration.'}</p></div><button class="switch ${role.dashboardRights[key] ? 'on' : ''}" data-action="role-dashboard-right" data-role="${role.id}" data-right="${key}" ${editable ? '' : 'disabled'}><i></i></button></div></div>`).join('')}</div>`;
}

function renderRoleUsers(role) {
  const users = state.users.filter((user) => user.roleId === role.id);
  return `<div class="table-wrap"><table><thead><tr><th>User</th><th>Plant / Team</th><th>Manager</th><th>Direct overrides</th><th>Status</th></tr></thead><tbody>${users.map((user) => `<tr><td><div class="table-primary"><span class="mini-avatar">${escapeHtml(user.initials)}</span><div><strong>${escapeHtml(user.name)}</strong><span>${escapeHtml(user.title)}</span></div></div></td><td>${escapeHtml(user.plant)}<div class="muted">${escapeHtml(user.team)}</div></td><td>${escapeHtml(userById(user.managerId)?.name || '—')}</td><td>${(user.direct || []).filter(isActiveGrant).length}</td><td><span class="status ${user.status === 'active' ? 'status-green' : 'status-red'}">${user.status}</span></td></tr>`).join('') || `<tr><td colspan="5">${emptyInline('No users assigned to this role.')}</td></tr>`}</tbody></table></div>`;
}

function renderEffectiveRole(role) {
  const assigned = state.users.filter((user) => user.roleId === role.id);
  const allowed = permissionCatalog.filter((permission) => rolePermissionState(role, permission.code) === 'allow');
  const denied = permissionCatalog.filter((permission) => rolePermissionState(role, permission.code) === 'deny');
  const widgets = widgetCatalog.filter((widget) => role.widgetIds.includes(widget.id));
  return `<div class="effect-preview"><h4>Effective access preview before publish</h4><div class="effect-grid"><div class="effect-box"><strong>${allowed.length}</strong><span>Explicit permissions</span></div><div class="effect-box"><strong>${denied.length}</strong><span>Explicit denies</span></div><div class="effect-box"><strong>${widgets.length}</strong><span>Available widgets</span></div><div class="effect-box"><strong>${assigned.length}</strong><span>Impacted users</span></div></div></div><div class="scope-grid" style="margin-top:12px"><div class="scope-card"><strong>Allowed routes</strong><p>${['Command Center','My Work',hasRolePermission(role,'space.approvals.view') ? 'Approvals' : null,hasRolePermission(role,'space.exceptions.view') ? 'Exceptions' : null,hasRolePermission(role,'space.builder.personal') ? 'Dashboard Builder' : null].filter(Boolean).join(' · ')}</p></div><div class="scope-card"><strong>Data scope</strong><p>${escapeHtml(role.scope.type)} · ${escapeHtml(role.scope.values.join(' · '))}</p></div><div class="scope-card"><strong>Delegation</strong><p>${role.delegate.includes('*') ? 'All authorised permissions' : `${role.delegate.length} permissions can be delegated`}</p></div><div class="scope-card"><strong>Safety result</strong><p>${denied.length ? `${denied.length} explicit denies take precedence.` : 'Default deny applies to every unlisted permission.'}</p></div></div>`;
}
function hasRolePermission(role, code) { return role.allow.includes('*') || role.allow.includes(code); }

function renderUsers() {
  const actor = currentUser();
  const users = visibleUsersFor(actor).filter((user) => {
    const q = state.userSearch.toLowerCase();
    return !q || [user.name,user.title,user.plant,user.team,roleById(user.roleId)?.name,user.email].join(' ').toLowerCase().includes(q);
  });
  const actions = `${has('space.users.manage') ? `<button class="btn" data-action="create-user">${icon('userPlus',15)} New user</button>` : ''}<button class="btn btn-primary" data-action="navigate" data-view="roles">${icon('roles',15)} Role studio</button>`;
  return `${pageHeader(actions)}<div class="toolbar"><label class="search-field">${icon('search')}<input id="userSearch" value="${escapeHtml(state.userSearch)}" placeholder="Search user, role, team or plant…"></label><select class="select-control"><option>All levels</option><option>Level 2 Managers</option><option>Level 3 Executives</option></select><select class="select-control"><option>All statuses</option><option>Active</option><option>Disabled</option></select><div class="segmented"><button data-action="user-view" data-mode="cards" class="${state.userView === 'cards' ? 'active' : ''}">${icon('grid',14)}</button><button data-action="user-view" data-mode="list" class="${state.userView === 'list' ? 'active' : ''}">${icon('list',14)}</button></div></div>${state.userView === 'cards' ? `<div class="user-card-grid">${users.map(renderUserCard).join('')}</div>` : renderUserTable(users)}`;
}

function renderUserCard(user) {
  const role = roleById(user.roleId);
  const direct = (user.direct || []).filter(isActiveGrant);
  const manageable = has('space.users.manage') && (currentUser().id === user.id || isSubordinate(currentUser(), user));
  return `<article class="user-card"><span class="user-status status ${user.status === 'active' ? 'status-green' : 'status-red'}">${user.status}</span><div class="user-card-avatar" style="background:linear-gradient(145deg,${role.color}bb,${role.color}66)">${escapeHtml(user.initials)}</div><h3>${escapeHtml(user.name)}</h3><p>${escapeHtml(user.title)}</p><div class="user-role-pill">${escapeHtml(role.name)} · L${user.level}</div><div class="user-details"><div class="user-detail">${icon('map',13)} ${escapeHtml(user.plant)} · ${escapeHtml(user.team)}</div><div class="user-detail">${icon('users',13)} Manager: ${escapeHtml(userById(user.managerId)?.name || 'Organisation')}</div><div class="user-detail">${icon('mail',13)} ${escapeHtml(user.email)}</div><div class="user-detail">${icon('audit',13)} Active ${humanTime(user.lastActive)}</div></div>${direct.length ? `<div class="direct-grants">${direct.slice(0,3).map((grant) => `<span class="grant-pill ${grant.effect === 'deny' ? 'deny' : ''}">${grant.effect}: ${grant.permission.split('.').slice(-2).join('.')}</span>`).join('')}${direct.length > 3 ? `<span class="grant-pill">+${direct.length-3}</span>` : ''}</div>` : ''}<div class="user-card-actions">${has('space.users.direct_grant') && isSubordinate(currentUser(),user) ? `<button class="row-action" data-action="direct-grant" data-id="${user.id}" title="Direct permission">${icon('key',14)}</button>` : ''}${manageable ? `<button class="row-action" data-action="edit-user" data-id="${user.id}" title="Edit user">${icon('edit',14)}</button>` : ''}<button class="row-action" data-action="view-user-access" data-id="${user.id}" title="Effective access">${icon('shield',14)}</button><button class="row-action" data-action="user-activity" data-id="${user.id}" title="Activity">${icon('audit',14)}</button></div></article>`;
}

function renderUserTable(users) {
  return `<div class="table-wrap"><table><thead><tr><th>User</th><th>Hierarchy / role</th><th>Plant / team</th><th>Manager</th><th>Direct grants</th><th>Last active</th><th>Status</th><th>Actions</th></tr></thead><tbody>${users.map((user) => { const role = roleById(user.roleId); const direct = (user.direct || []).filter(isActiveGrant); return `<tr><td><div class="table-primary"><span class="mini-avatar" style="background:${role.color}">${escapeHtml(user.initials)}</span><div><strong>${escapeHtml(user.name)}</strong><span>${escapeHtml(user.email)}</span></div></div></td><td>L${user.level} · ${escapeHtml(role.name)}<div class="muted">${escapeHtml(user.title)}</div></td><td>${escapeHtml(user.plant)}<div class="muted">${escapeHtml(user.team)}</div></td><td>${escapeHtml(userById(user.managerId)?.name || '—')}</td><td>${direct.length}${direct.length ? `<div class="muted">${direct.filter((g)=>g.effect==='allow').length} allow · ${direct.filter((g)=>g.effect==='deny').length} deny</div>` : ''}</td><td>${humanTime(user.lastActive)}</td><td><span class="status ${user.status === 'active' ? 'status-green' : 'status-red'}">${user.status}</span></td><td><div class="row-actions">${has('space.users.direct_grant') && isSubordinate(currentUser(),user) ? `<button class="row-action" data-action="direct-grant" data-id="${user.id}">${icon('key',13)}</button>` : ''}<button class="row-action" data-action="view-user-access" data-id="${user.id}">${icon('shield',13)}</button><button class="row-action" data-action="user-activity" data-id="${user.id}">${icon('audit',13)}</button></div></td></tr>`; }).join('')}</tbody></table></div>`;
}

function renderAudit() {
  const q = state.auditSearch.toLowerCase();
  const logs = state.audit.filter((log) => {
    if (!q) return true;
    return [log.actor,log.action,log.object,log.category,log.result,log.detail].join(' ').toLowerCase().includes(q);
  });
  const denied = state.audit.filter((log) => log.result === 'Denied').length;
  const actions = `${has('space.audit.export') ? `<button class="btn" data-action="export-audit">${icon('download',15)} Export CSV</button>` : ''}<button class="btn btn-primary" data-action="navigate" data-view="simulator">${icon('simulator',15)} Access simulator</button>`;
  return `${pageHeader(actions)}<div class="audit-kpis"><div class="audit-stat"><span class="metric-icon">${icon('activity',16)}</span><div><strong>${state.audit.length}</strong><span>Recorded events</span></div></div><div class="audit-stat"><span class="metric-icon" style="color:#2979ff;background:#eaf2ff">${icon('users',16)}</span><div><strong>${new Set(state.audit.map((log)=>log.actorId).filter(Boolean)).size}</strong><span>Active actors</span></div></div><div class="audit-stat"><span class="metric-icon" style="color:#7857e8;background:#f1edff">${icon('builder',16)}</span><div><strong>${state.audit.filter((log)=>log.category==='Dashboard').length}</strong><span>Dashboard changes</span></div></div><div class="audit-stat"><span class="metric-icon" style="color:#df5062;background:#fff0f2">${icon('shield',16)}</span><div><strong>${denied}</strong><span>Denied actions</span></div></div></div><div class="toolbar"><label class="search-field">${icon('search')}<input id="auditSearch" value="${escapeHtml(state.auditSearch)}" placeholder="Search actor, action, object or result…"></label><select class="select-control"><option>All categories</option><option>Task</option><option>Access</option><option>Dashboard</option><option>Security</option></select><select class="select-control"><option>All results</option><option>Success</option><option>Denied</option></select></div><div class="table-wrap"><table><thead><tr><th>Time</th><th>Actor</th><th>Action</th><th>Object</th><th>Category</th><th>Result</th><th>Detail</th></tr></thead><tbody>${logs.map((log) => `<tr><td class="nowrap">${humanTime(log.at)}</td><td><div class="table-primary"><span class="mini-avatar">${escapeHtml(log.actor.split(' ').map((part)=>part[0]).join('').slice(0,2))}</span><div><strong>${escapeHtml(log.actor)}</strong><span>${escapeHtml(log.actorId || 'external/system')}</span></div></div></td><td>${escapeHtml(log.action)}</td><td class="mono">${escapeHtml(log.object)}</td><td><span class="status status-gray">${escapeHtml(log.category)}</span></td><td><span class="status ${log.result === 'Success' ? 'status-green' : 'status-red'}">${escapeHtml(log.result)}</span></td><td>${escapeHtml(log.detail)}</td></tr>`).join('')}</tbody></table></div>`;
}

function renderSimulator() {
  const actor = currentUser();
  const users = actor.level === 1 ? state.users : visibleUsersFor(actor);
  const result = state.simulator.result;
  const actions = `<button class="btn" data-action="simulator-reset">${icon('refresh',15)} Reset</button>`;
  return `${pageHeader(actions)}<div class="simulator"><section class="panel simulator-form"><div class="panel-head"><div><h3>Test access decision</h3><p>Choose a user, permission and resource context.</p></div>${icon('shield',18)}</div><div class="panel-body"><div class="field"><label>User</label><select id="simUser">${users.map((user) => `<option value="${user.id}" ${state.simulator.userId === user.id ? 'selected' : ''}>${escapeHtml(user.name)} · ${escapeHtml(roleById(user.roleId).name)}</option>`).join('')}</select></div><div class="field" style="margin-top:10px"><label>Permission</label><select id="simPermission">${permissionCatalog.map((permission) => `<option value="${permission.code}" ${state.simulator.permission === permission.code ? 'selected' : ''}>${escapeHtml(permission.name)} · ${escapeHtml(permission.code)}</option>`).join('')}</select></div><div class="field" style="margin-top:10px"><label>Resource plant</label><select id="simPlant">${['Bangalore Unit','Chennai Unit','Pune Unit'].map((plant) => `<option value="${plant}" ${state.simulator.plant === plant ? 'selected' : ''}>${plant}</option>`).join('')}</select></div><div class="field" style="margin-top:10px"><label>Assigned user</label><select id="simAssigned"><option value="">Not assigned</option>${state.users.filter((u)=>u.level===3).map((user) => `<option value="${user.id}">${escapeHtml(user.name)}</option>`).join('')}</select></div><button class="btn btn-primary" style="width:100%;margin-top:12px" data-action="run-simulator">${icon('play',14)} Evaluate access</button></div></section><section class="panel simulator-result">${result ? renderSimulationResult(result) : `<div class="empty-state"><div class="metric-icon">${icon('simulator',22)}</div><h3>No decision yet</h3><p>Run a simulation to see identity, direct grant, role policy, scope and final-decision steps.</p></div>`}</section></div>`;
}

function renderSimulationResult(result) {
  const decision = result.allowed ? 'Allowed' : 'Denied';
  return `<div class="decision-badge ${result.allowed ? 'allowed' : 'denied'}">${icon(result.allowed ? 'check' : 'close',34)}</div><h2>${decision}</h2><p>Decision source: <span class="mono">${escapeHtml(result.source)}</span>. Every step below is evaluated server-side in the production architecture.</p><div class="decision-trace">${result.trace.map((step,index) => `<div class="trace-step"><b>${index+1}</b><div><strong>${escapeHtml(step.step)}</strong><span>${escapeHtml(step.detail)}</span></div><em style="color:${step.result === 'ALLOW' || step.result === 'PASS' ? '#0d895c' : step.result === 'DENY' ? '#bd394b' : '#a86a08'}">${escapeHtml(step.result)}</em></div>`).join('')}</div>`;
}

function renderOverlay() {
  const root = $('#overlayRoot');
  if (!root) return;
  if (!state.overlay) { root.innerHTML = ''; return; }
  const overlay = state.overlay;
  const renderers = {
    task:() => renderTaskDrawer(overlay.id),
    approval:() => renderApprovalModal(overlay.id),
    action:() => renderActionModal(overlay),
    grant:() => renderGrantModal(overlay.id),
    userAccess:() => renderUserAccessModal(overlay.id),
    userActivity:() => renderUserActivityModal(overlay.id),
    editUser:() => renderEditUserModal(overlay.id),
    createUser:() => renderEditUserModal(null),
    createRole:() => renderCreateRoleModal(),
    notifications:() => renderNotificationsModal(),
    quick:() => renderQuickActionModal(overlay.kind),
    command:() => renderCommandPalette(overlay.query || ''),
    exceptionAssign:() => renderExceptionAssignModal(overlay.id),
    exceptionCreate:() => renderExceptionCreateModal(),
    builderPreview:() => renderBuilderPreviewModal(),
    userRole:() => renderUserRoleModal(overlay.id)
  };
  root.innerHTML = (renderers[overlay.type] || (() => ''))();
}

function overlayCloseButton() { return `<button class="modal-close" data-action="close-overlay" aria-label="Close">${icon('close',16)}</button>`; }

function renderTaskDrawer(taskId) {
  const task = state.tasks.find((item) => item.id === taskId);
  if (!task) return '';
  const assignee = userById(task.assignedTo);
  const value = has('field.financial_value.view', task) ? task.value : '•••••• (masked)';
  const vendor = has('field.vendor_contact.view', task) ? task.vendor : 'Restricted vendor data';
  const canUpdate = has('space.tasks.update', task);
  const canComplete = has(task.permission, task);
  const canReassign = has('space.tasks.reassign', task) && currentUser().level <= 2;
  return `<div class="drawer-overlay" data-action="close-overlay-bg"><aside class="drawer"><header class="drawer-head"><div><div class="flex items-center gap-8"><span class="status priority-${task.priority}">${escapeHtml(task.priority)}</span><span class="mono muted">${escapeHtml(task.id)}</span></div><h2>${escapeHtml(task.title)}</h2><p>${escapeHtml(task.module)} · ${escapeHtml(task.type)} · ${escapeHtml(task.plant)}</p></div>${overlayCloseButton()}</header><div class="drawer-body"><p style="font-size:9px;line-height:1.65;color:var(--muted);margin-top:0">${escapeHtml(task.description)}</p><div class="detail-grid"><div class="detail-box"><span>Reference</span><strong>${escapeHtml(task.reference)}</strong></div><div class="detail-box"><span>Batch / lot</span><strong>${escapeHtml(task.batch)}</strong></div><div class="detail-box"><span>Quantity</span><strong>${escapeHtml(task.quantity)}</strong></div><div class="detail-box"><span>Financial value</span><strong>${escapeHtml(value)}</strong></div><div class="detail-box"><span>Vendor / source</span><strong>${escapeHtml(vendor)}</strong></div><div class="detail-box"><span>Assigned to</span><strong>${escapeHtml(assignee?.name || 'Unassigned')}</strong></div><div class="detail-box"><span>Due / SLA</span><strong>${escapeHtml(task.due)}</strong></div><div class="detail-box"><span>Current status</span><strong>${escapeHtml(task.status.replace('_',' '))}</strong></div></div><div class="property-section"><h4>Evidence requirement</h4><div class="locked-callout">${icon('upload',15)}<div><strong>${escapeHtml(task.evidence)}</strong><span>Production implementation should validate required evidence before state transition.</span></div></div></div><div class="property-section"><h4>Timeline</h4><div class="timeline">${task.timeline.map(([title,meta]) => `<div class="timeline-item"><i class="timeline-dot"></i><strong>${escapeHtml(title)}</strong><span>${escapeHtml(meta)}</span></div>`).join('')}</div></div>${has('field.internal_notes.view', task) ? `<div class="property-section"><h4>Internal note</h4><div class="detail-box"><strong>Prioritise this task because it blocks the next manufacturing step.</strong></div></div>` : ''}</div><footer class="drawer-foot">${canReassign ? `<button class="btn" data-action="task-reassign" data-id="${task.id}">${icon('users',14)} Reassign</button>` : ''}${canUpdate && task.status === 'todo' ? `<button class="btn" data-action="task-start" data-id="${task.id}">${icon('play',14)} Start</button>` : ''}${canUpdate ? `<button class="btn" data-action="task-note" data-id="${task.id}">${icon('edit',14)} Add note</button>` : ''}${canComplete && task.status !== 'done' ? `<button class="btn btn-primary" data-action="task-complete" data-id="${task.id}">${icon('check',14)} ${escapeHtml(task.action)}</button>` : ''}</footer></aside></div>`;
}

function renderApprovalModal(id) {
  const approval = state.approvals.find((item) => item.id === id);
  if (!approval) return '';
  return `<div class="overlay" data-action="close-overlay-bg"><section class="modal"><header class="modal-head"><div><h2>${escapeHtml(approval.title)}</h2><p>${escapeHtml(approval.id)} · ${escapeHtml(approval.type)}</p></div>${overlayCloseButton()}</header><div class="modal-body"><div class="detail-grid"><div class="detail-box"><span>Requester</span><strong>${escapeHtml(approval.requester)}</strong></div><div class="detail-box"><span>Department</span><strong>${escapeHtml(approval.department)}</strong></div><div class="detail-box"><span>Plant</span><strong>${escapeHtml(approval.plant)}</strong></div><div class="detail-box"><span>Value / impact</span><strong>${has('field.financial_value.view') ? escapeHtml(approval.amount) : 'Masked'}</strong></div><div class="detail-box"><span>Risk</span><strong>${escapeHtml(approval.risk)}</strong></div><div class="detail-box"><span>SLA</span><strong>${escapeHtml(approval.sla)}</strong></div></div><div class="property-section"><h4>Decision context</h4><p class="muted" style="font-size:9px;line-height:1.65">${escapeHtml(approval.details)}</p></div><div class="property-section"><h4>Supporting documents</h4><div class="task-mini-list"><div class="task-mini"><span class="task-type-icon">${icon('task',14)}</span><div><strong>Request summary</strong><span>${escapeHtml(approval.reference)} · verified</span></div>${icon('check',13)}</div><div class="task-mini"><span class="task-type-icon">${icon('audit',14)}</span><div><strong>Approval history</strong><span>No previous rejection</span></div>${icon('check',13)}</div></div></div></div><footer class="modal-foot">${approval.status === 'pending' ? `${has('space.approvals.return') ? `<button class="btn" data-action="approval-action" data-id="${approval.id}" data-result="returned">Return</button>` : ''}${has('space.approvals.reject') ? `<button class="btn btn-danger" data-action="approval-action" data-id="${approval.id}" data-result="rejected">Reject</button>` : ''}${has('space.approvals.approve') ? `<button class="btn btn-primary" data-action="approval-action" data-id="${approval.id}" data-result="approved">${icon('check',14)} Approve</button>` : ''}` : `<span class="status ${approval.status === 'approved' ? 'status-green' : 'status-red'}">${approval.status}</span>`}</footer></section></div>`;
}

function renderActionModal(overlay) {
  const titleMap = {taskComplete:'Complete operational task', taskNote:'Add task note', taskReassign:'Reassign task', approval:'Confirm approval decision', exception:'Update exception'};
  const title = titleMap[overlay.kind] || 'Confirm action';
  const task = overlay.id ? state.tasks.find((item) => item.id === overlay.id) : null;
  return `<div class="overlay" data-action="close-overlay-bg"><section class="modal"><header class="modal-head"><div><h2>${title}</h2><p>${escapeHtml(task?.title || overlay.label || 'Add required details before confirmation.')}</p></div>${overlayCloseButton()}</header><div class="modal-body"><div class="form-grid">${overlay.kind === 'taskReassign' ? `<div class="field full"><label>Assign to</label><select id="actionAssignee">${visibleUsersFor().filter((user)=>user.level===3 && user.status==='active').map((user)=>`<option value="${user.id}">${escapeHtml(user.name)} · ${escapeHtml(roleById(user.roleId).name)}</option>`).join('')}</select></div>` : ''}${overlay.kind === 'taskComplete' ? `<div class="field"><label>Result</label><select id="actionResult"><option>Completed successfully</option><option>Partially completed</option><option>Requires review</option></select></div><div class="field"><label>Evidence reference</label><input id="actionEvidence" placeholder="Photo, document or scan reference"></div>` : ''}<div class="field full"><label>Reason / note <span style="color:var(--red)">*</span></label><textarea id="actionReason" placeholder="Record a clear, auditable reason…"></textarea><span class="help-text">Mandatory for privileged decisions and task state changes.</span></div></div></div><footer class="modal-foot"><button class="btn" data-action="close-overlay">Cancel</button><button class="btn btn-primary" data-action="confirm-action" data-kind="${overlay.kind}" data-id="${overlay.id || ''}" data-result="${overlay.result || ''}">${icon('check',14)} Confirm</button></footer></section></div>`;
}

function renderGrantModal(userId) {
  const user = userById(userId);
  if (!user) return '';
  const delegable = permissionCatalog.filter((permission) => canDelegate(permission.code));
  const active = (user.direct || []).filter(isActiveGrant);
  return `<div class="overlay" data-action="close-overlay-bg"><section class="modal modal-lg"><header class="modal-head"><div><h2>Direct access · ${escapeHtml(user.name)}</h2><p>Add a user-specific allow or deny without changing the shared role. Parent ceiling and scope remain enforced.</p></div>${overlayCloseButton()}</header><div class="modal-body"><div class="locked-callout">${icon('shield',16)}<div><strong>Manager safety boundary</strong><span>You can grant only permissions marked delegable in your own role, only to a subordinate, and only inside your data scope.</span></div></div><div class="form-grid" style="margin-top:12px"><div class="field full"><label>Permission</label><select id="grantPermission">${delegable.map((permission) => `<option value="${permission.code}">${escapeHtml(permission.name)} · ${escapeHtml(permission.code)}</option>`).join('')}</select></div><div class="field"><label>Effect</label><select id="grantEffect"><option value="allow">Allow extra access</option><option value="deny">Explicitly deny</option></select></div><div class="field"><label>Expiry date</label><input id="grantExpiry" type="date" value="${new Date(Date.now()+7*86400000).toISOString().slice(0,10)}"></div><div class="field full"><label>Business reason</label><textarea id="grantReason" placeholder="Example: cover incoming QC during approved leave"></textarea></div></div><div class="property-section"><h4>Active direct overrides</h4>${active.length ? `<div class="table-wrap"><table style="min-width:700px"><thead><tr><th>Effect</th><th>Permission</th><th>Reason</th><th>Expiry</th><th>Action</th></tr></thead><tbody>${active.map((grant) => `<tr><td><span class="status ${grant.effect === 'allow' ? 'status-green' : 'status-red'}">${grant.effect}</span></td><td class="mono">${escapeHtml(grant.permission)}</td><td>${escapeHtml(grant.reason)}</td><td>${humanDate(grant.expiresAt)}</td><td><button class="row-action" data-action="revoke-grant" data-user="${user.id}" data-grant="${grant.id}">${icon('trash',13)}</button></td></tr>`).join('')}</tbody></table></div>` : emptyInline('No active user-specific overrides.')}</div></div><footer class="modal-foot"><button class="btn" data-action="close-overlay">Cancel</button><button class="btn btn-primary" data-action="save-grant" data-user="${user.id}">${icon('key',14)} Add direct access</button></footer></section></div>`;
}

function renderUserAccessModal(userId) {
  const user = userById(userId);
  if (!user) return '';
  const role = roleById(user.roleId);
  const effective = permissionCatalog.map((permission) => ({...permission, decision:resolvePermission(user, permission.code)}));
  const allowed = effective.filter((item)=>item.decision.allowed);
  const denied = effective.filter((item)=>!item.decision.allowed);
  const activeGrants = (user.direct || []).filter(isActiveGrant);
  return `<div class="overlay" data-action="close-overlay-bg"><section class="modal modal-lg"><header class="modal-head"><div><h2>Effective access · ${escapeHtml(user.name)}</h2><p>${escapeHtml(role.name)} · ${escapeHtml(user.plant)} · ${escapeHtml(user.team)}</p></div>${overlayCloseButton()}</header><div class="modal-body"><div class="effect-preview"><h4>Resolved access summary</h4><div class="effect-grid"><div class="effect-box"><strong>${allowed.length}</strong><span>Allowed permissions</span></div><div class="effect-box"><strong>${denied.length}</strong><span>Denied permissions</span></div><div class="effect-box"><strong>${activeGrants.length}</strong><span>Direct overrides</span></div><div class="effect-box"><strong>${role.widgetIds.filter((id)=>widgetCatalog.some((w)=>w.id===id && resolvePermission(user,w.permission).allowed)).length}</strong><span>Usable widgets</span></div></div></div><div class="tabs" style="margin-top:12px"><button class="active">Effective permissions</button><button>Direct overrides</button><button>Widgets</button><button>Scope</button></div><div class="permission-matrix"><table><thead><tr><th>Permission</th><th>Role state</th><th>Direct override</th><th>Effective</th><th>Reason</th></tr></thead><tbody>${effective.map((item) => { const grant = activeGrants.find((g)=>g.permission===item.code); return `<tr><td><div class="permission-name"><strong>${escapeHtml(item.name)}</strong><code class="permission-code">${escapeHtml(item.code)}</code></div></td><td><span class="status ${rolePermissionState(role,item.code)==='allow'?'status-green':rolePermissionState(role,item.code)==='deny'?'status-red':'status-gray'}">${rolePermissionState(role,item.code)}</span></td><td>${grant ? `<span class="status ${grant.effect==='allow'?'status-green':'status-red'}">${grant.effect}</span>` : '—'}</td><td><span class="status ${item.decision.allowed?'status-green':'status-red'}">${item.decision.allowed?'allowed':'denied'}</span></td><td>${escapeHtml(item.decision.trace.at(-1)?.detail || '')}</td></tr>`; }).join('')}</tbody></table></div></div><footer class="modal-foot"><button class="btn" data-action="close-overlay">Close</button>${has('space.users.direct_grant') && isSubordinate(currentUser(),user) ? `<button class="btn btn-primary" data-action="direct-grant" data-id="${user.id}">${icon('key',14)} Add direct access</button>` : ''}</footer></section></div>`;
}

function renderUserActivityModal(userId) {
  const user = userById(userId);
  if (!user) return '';
  const logs = state.audit.filter((log) => log.actorId === user.id);
  return `<div class="overlay" data-action="close-overlay-bg"><section class="modal"><header class="modal-head"><div><h2>${escapeHtml(user.name)} · Activity</h2><p>Operational and access events visible within your audit scope.</p></div>${overlayCloseButton()}</header><div class="modal-body"><div class="timeline">${logs.length ? logs.map((log) => `<div class="timeline-item"><i class="timeline-dot"></i><strong>${escapeHtml(log.action)} · ${escapeHtml(log.object)}</strong><span>${humanTime(log.at)} · ${escapeHtml(log.result)} · ${escapeHtml(log.detail)}</span></div>`).join('') : `<div class="empty-state"><p>No recorded activity for this user.</p></div>`}</div></div><footer class="modal-foot"><button class="btn" data-action="close-overlay">Close</button></footer></section></div>`;
}

function renderEditUserModal(userId) {
  const editing = Boolean(userId);
  const user = editing ? userById(userId) : {name:'',email:'',phone:'',level:3,roleId:'role-production-executive',plant:'Bangalore Unit',team:'Shift A',managerId:currentUser().id,status:'active'};
  if (!user) return '';
  const roles = state.roles.filter((role) => role.level > currentUser().level || role.id === user.roleId);
  const managers = state.users.filter((candidate) => candidate.status === 'active' && candidate.level < user.level && (currentUser().level === 1 || candidate.id === currentUser().id));
  return `<div class="overlay" data-action="close-overlay-bg"><section class="modal"><header class="modal-head"><div><h2>${editing ? 'Edit user' : 'Create subordinate user'}</h2><p>Hierarchy level, role, manager and data scope are enforced together.</p></div>${overlayCloseButton()}</header><div class="modal-body"><div class="form-grid"><div class="field"><label>Full name</label><input id="editUserName" value="${escapeHtml(user.name)}" placeholder="Employee name"></div><div class="field"><label>Email</label><input id="editUserEmail" type="email" value="${escapeHtml(user.email)}" placeholder="name@tan90.demo"></div><div class="field"><label>Phone</label><input id="editUserPhone" value="${escapeHtml(user.phone)}"></div><div class="field"><label>Status</label><select id="editUserStatus"><option value="active" ${user.status==='active'?'selected':''}>Active</option><option value="disabled" ${user.status==='disabled'?'selected':''}>Disabled</option></select></div><div class="field"><label>Role</label><select id="editUserRole">${roles.map((role)=>`<option value="${role.id}" ${user.roleId===role.id?'selected':''}>L${role.level} · ${escapeHtml(role.name)}</option>`).join('')}</select></div><div class="field"><label>Reporting manager</label><select id="editUserManager">${managers.map((manager)=>`<option value="${manager.id}" ${user.managerId===manager.id?'selected':''}>${escapeHtml(manager.name)} · L${manager.level}</option>`).join('')}</select></div><div class="field"><label>Plant</label><select id="editUserPlant">${['Bangalore Unit','Chennai Unit','Pune Unit'].map((plant)=>`<option value="${plant}" ${user.plant===plant?'selected':''}>${plant}</option>`).join('')}</select></div><div class="field"><label>Team</label><input id="editUserTeam" value="${escapeHtml(user.team)}" placeholder="Team or shift"></div></div><div class="locked-callout" style="margin-top:12px">${icon('shield',16)}<div><strong>Hierarchy validation</strong><span>The selected role must be below your hierarchy level. A manager cannot place a user outside the manager's authorised plant scope.</span></div></div></div><footer class="modal-foot"><button class="btn" data-action="close-overlay">Cancel</button><button class="btn btn-primary" data-action="save-user" data-id="${userId || ''}">${icon('save',14)} ${editing?'Save changes':'Create user'}</button></footer></section></div>`;
}

function renderCreateRoleModal() {
  const actor = currentUser();
  return `<div class="overlay" data-action="close-overlay-bg"><section class="modal"><header class="modal-head"><div><h2>Create subordinate role</h2><p>New role starts with default deny and can receive only permissions inside your delegation ceiling.</p></div>${overlayCloseButton()}</header><div class="modal-body"><div class="form-grid"><div class="field"><label>Role name</label><input id="newRoleName" placeholder="Example: Inbound Executive"></div><div class="field"><label>Hierarchy level</label><select id="newRoleLevel">${actor.level === 1 ? '<option value="2">Level 2 · Manager</option>' : ''}<option value="3">Level 3 · Executive</option></select></div><div class="field full"><label>Description</label><textarea id="newRoleDescription" placeholder="Describe the responsibility and intended scope"></textarea></div><div class="field"><label>Parent role</label><select id="newRoleParent">${state.roles.filter((role)=>role.level===actor.level || (actor.level===1 && role.level===2)).map((role)=>`<option value="${role.id}">${escapeHtml(role.name)}</option>`).join('')}</select></div><div class="field"><label>Default scope</label><select id="newRoleScope"><option value="assigned">Assigned records</option><option value="team">Managed team</option><option value="plant">Assigned plant</option></select></div></div><div class="permission-note" style="margin-top:12px">New roles receive no operational permission until explicitly configured in Role Permission Studio.</div></div><footer class="modal-foot"><button class="btn" data-action="close-overlay">Cancel</button><button class="btn btn-primary" data-action="save-new-role">${icon('plus',14)} Create role</button></footer></section></div>`;
}

function renderNotificationsModal() {
  const notifications = [
    ['Critical','Line 1 downtime crossed 42 minutes','2 min ago','machine'],
    ['Approval','PCM emergency purchase needs decision','12 min ago','approvals'],
    ['Quality','Partial film acceptance submitted','18 min ago','quality'],
    ['Task','POD upload is due in 1 hour','28 min ago','truck']
  ];
  return `<div class="overlay" data-action="close-overlay-bg"><section class="modal" style="width:min(520px,calc(100vw - 32px))"><header class="modal-head"><div><h2>Notifications</h2><p>Permission-aware alerts and work updates</p></div>${overlayCloseButton()}</header><div class="modal-body"><div class="task-mini-list">${notifications.map(([type,title,time,ic])=>`<button class="task-mini" style="width:100%;text-align:left" data-action="notification-open" data-label="${escapeHtml(title)}"><span class="task-type-icon" style="--task-color:${type==='Critical'?'#df5062':'#2979ff'};--task-soft:${type==='Critical'?'#fff0f2':'#eaf2ff'}">${icon(ic,14)}</span><div><strong>${escapeHtml(title)}</strong><span>${type} · ${time}</span></div>${icon('chevron',13)}</button>`).join('')}</div></div><footer class="modal-foot"><button class="btn" data-action="close-overlay">Mark all read</button></footer></section></div>`;
}

function renderQuickActionModal(kind = '') {
  const options = [
    {id:'Post a GRN',icon:'task',permission:'space.tasks.complete',description:'Validate received quantity and create an auditable receipt action.'},
    {id:'Complete QC',icon:'quality',permission:'space.tasks.complete',description:'Record inspection result, evidence and disposition.'},
    {id:'Record output',icon:'factory',permission:'space.tasks.update',description:'Capture good output, wastage, downtime and sign-off.'},
    {id:'Upload POD',icon:'truck',permission:'space.tasks.complete',description:'Attach delivery proof and close an authorised shipment.'},
    {id:'Log exception',icon:'alert',permission:'space.exceptions.ack',description:'Create an operational issue with impact, owner and SLA.'}
  ].filter((option)=>has(option.permission));
  return `<div class="overlay" data-action="close-overlay-bg"><section class="modal"><header class="modal-head"><div><h2>Start authorised work</h2><p>Quick actions still enforce task, field and data-scope permissions.</p></div>${overlayCloseButton()}</header><div class="modal-body"><div class="scope-grid">${options.map((option)=>`<button class="scope-card" style="text-align:left;cursor:pointer;${kind===option.id?'border-color:rgba(15,189,140,.35);background:var(--brand-soft)':''}" data-action="quick-select" data-kind="${option.id}"><span class="widget-icon" style="margin-bottom:8px">${icon(option.icon,16)}</span><strong>${option.id}</strong><p>${option.description}</p></button>`).join('')}</div>${kind ? `<div class="property-section"><h4>${escapeHtml(kind)} details</h4><div class="form-grid"><div class="field"><label>Reference</label><input id="quickReference" placeholder="PO, GRN, WO, batch or dispatch"></div><div class="field"><label>Plant</label><select id="quickPlant"><option>Bangalore Unit</option><option>Chennai Unit</option><option>Pune Unit</option></select></div><div class="field full"><label>Note</label><textarea id="quickNote" placeholder="Enter the action context"></textarea></div></div></div>` : ''}</div><footer class="modal-foot"><button class="btn" data-action="close-overlay">Cancel</button>${kind ? `<button class="btn btn-primary" data-action="quick-submit" data-kind="${escapeHtml(kind)}">${icon('check',14)} Create action</button>` : ''}</footer></section></div>`;
}

function commandItems(query = '') {
  const q = query.toLowerCase();
  const nav = navItems.filter((item)=>has(item.permission)).map((item)=>({type:'Navigation',title:item.label,subtitle:pageMeta[item.id]?.description||'',icon:item.icon,action:'navigate',value:item.id}));
  const tasks = visibleTasksFor().map((task)=>({type:'Task',title:task.title,subtitle:`${task.id} · ${task.reference}`,icon:'task',action:'open-task',value:task.id}));
  const users = has('space.users.view') ? visibleUsersFor().map((user)=>({type:'User',title:user.name,subtitle:`${roleById(user.roleId).name} · ${user.plant}`,icon:'users',action:'view-user-access',value:user.id})) : [];
  return [...nav,...tasks,...users].filter((item)=>!q || `${item.title} ${item.subtitle} ${item.type}`.toLowerCase().includes(q)).slice(0,12);
}

function renderCommandPalette(query) {
  const items = commandItems(query);
  return `<div class="overlay" data-action="close-overlay-bg"><section class="modal command-palette"><div class="command-input">${icon('search')}<input id="commandSearch" autofocus value="${escapeHtml(query)}" placeholder="Search anything or type a command…"></div><div class="command-results">${items.map((item,index)=>`<button class="command-result" data-action="command-select" data-command="${item.action}" data-value="${item.value}"><span class="widget-icon">${icon(item.icon,14)}</span><div><strong>${escapeHtml(item.title)}</strong><span>${escapeHtml(item.type)} · ${escapeHtml(item.subtitle)}</span></div><kbd>${index+1}</kbd></button>`).join('') || emptyInline('No matching command.')}</div></section></div>`;
}

function renderExceptionAssignModal(id) {
  const exception = state.exceptions.find((item)=>item.id===id);
  if (!exception) return '';
  const candidates = visibleUsersFor().filter((user)=>user.status==='active' && user.level>=2);
  return `<div class="overlay" data-action="close-overlay-bg"><section class="modal"><header class="modal-head"><div><h2>Assign exception</h2><p>${escapeHtml(exception.title)} · ${escapeHtml(exception.id)}</p></div>${overlayCloseButton()}</header><div class="modal-body"><div class="form-grid"><div class="field full"><label>Owner</label><select id="exceptionOwner">${candidates.map((user)=>`<option value="${user.id}">${escapeHtml(user.name)} · ${escapeHtml(roleById(user.roleId).name)}</option>`).join('')}</select></div><div class="field"><label>Target date</label><input id="exceptionTarget" type="date" value="${new Date(Date.now()+86400000).toISOString().slice(0,10)}"></div><div class="field"><label>Priority</label><select id="exceptionPriority"><option>Critical</option><option>High</option><option>Medium</option></select></div><div class="field full"><label>Assignment note</label><textarea id="exceptionNote" placeholder="Expected action and escalation condition"></textarea></div></div></div><footer class="modal-foot"><button class="btn" data-action="close-overlay">Cancel</button><button class="btn btn-primary" data-action="save-exception-assignment" data-id="${id}">Assign owner</button></footer></section></div>`;
}

function renderExceptionCreateModal() {
  return `<div class="overlay" data-action="close-overlay-bg"><section class="modal"><header class="modal-head"><div><h2>Log operational exception</h2><p>Create an auditable exception inside your authorised plant scope.</p></div>${overlayCloseButton()}</header><div class="modal-body"><div class="form-grid"><div class="field"><label>Category</label><select id="newExceptionCategory"><option>Machine</option><option>Quality</option><option>Inventory</option><option>Dispatch</option><option>GRN</option></select></div><div class="field"><label>Severity</label><select id="newExceptionSeverity"><option value="critical">Critical</option><option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option></select></div><div class="field full"><label>Title</label><input id="newExceptionTitle" placeholder="Clear operational issue"></div><div class="field full"><label>Description</label><textarea id="newExceptionDescription" placeholder="What happened, impact and current containment"></textarea></div><div class="field"><label>Plant</label><select id="newExceptionPlant"><option>Bangalore Unit</option><option>Chennai Unit</option><option>Pune Unit</option></select></div><div class="field"><label>Reference</label><input id="newExceptionReference" placeholder="Batch, machine, GRN or shipment"></div></div></div><footer class="modal-foot"><button class="btn" data-action="close-overlay">Cancel</button><button class="btn btn-primary" data-action="save-new-exception">Create exception</button></footer></section></div>`;
}

function renderBuilderPreviewModal() {
  const {layout} = getBuilderTarget();
  return `<div class="overlay" data-action="close-overlay-bg"><section class="modal modal-lg"><header class="modal-head"><div><h2>Dashboard preview</h2><p>${escapeHtml(state.builder.targetType)} · ${escapeHtml(state.builder.targetId)} · ${layout.length} widgets</p></div>${overlayCloseButton()}</header><div class="modal-body" style="background:var(--bg-elevated)"><div class="builder-frame ${state.builder.device}"><div class="builder-grid">${layout.map((item)=>renderBuilderWidget(item,false)).join('')}</div></div></div><footer class="modal-foot"><button class="btn" data-action="close-overlay">Close preview</button></footer></section></div>`;
}

function render() {
  document.documentElement.dataset.theme = state.theme;
  const app = $('#app');
  if (!app) return;
  app.innerHTML = state.currentUserId ? renderShell() : renderLogin();
  renderOverlay();
  persist();
  requestAnimationFrame(afterRender);
}

function afterRender() {
  drawDashboardCharts();
  const commandInput = $('#commandSearch');
  if (commandInput && state.overlay?.type === 'command') {
    commandInput.focus();
    commandInput.setSelectionRange(commandInput.value.length, commandInput.value.length);
  }
}

function toast(title, message, kind = 'success') {
  const root = $('#toastRoot');
  if (!root) return;
  const node = document.createElement('div');
  node.className = 'toast';
  node.innerHTML = `<span class="toast-icon" style="color:${kind === 'error' ? '#ff8c9b' : '#74e0c2'};background:${kind === 'error' ? 'rgba(223,80,98,.16)' : 'rgba(15,189,140,.15)'}">${icon(kind === 'error' ? 'alert' : 'check',15)}</span><div><strong>${escapeHtml(title)}</strong><span>${escapeHtml(message)}</span></div>`;
  root.appendChild(node);
  setTimeout(() => node.remove(), 4200);
}

function closeOverlay() { state.overlay = null; renderOverlay(); persist(); }
function openOverlay(overlay) { state.overlay = overlay; renderOverlay(); persist(); }
function navigate(view) {
  const nav = navItems.find((item) => item.id === view);
  if (!nav || !has(nav.permission)) { toast('Access denied', 'Your current role does not include this page.', 'error'); return; }
  state.view = view;
  state.sidebarOpen = false;
  state.overlay = null;
  window.scrollTo({top:0,behavior:'smooth'});
  render();
}

function handleClick(event) {
  const target = event.target.closest('[data-action]');
  if (!target || target.disabled) return;
  const action = target.dataset.action;
  const id = target.dataset.id;

  if (action === 'login') {
    state.currentUserId = target.dataset.user;
    state.view = 'dashboard';
    state.builder.targetType = 'personal';
    state.builder.targetId = state.currentUserId;
    state.overlay = null;
    render();
    toast('Demo session started', `${currentUser().name} · ${currentRole().name}`);
    return;
  }
  if (action === 'switch-persona') { state.currentUserId = null; state.overlay = null; render(); return; }
  if (action === 'navigate') { navigate(target.dataset.view); return; }
  if (action === 'toggle-sidebar') { state.sidebarOpen = !state.sidebarOpen; render(); return; }
  if (action === 'theme') { state.theme = state.theme === 'dark' ? 'light' : 'dark'; render(); return; }
  if (action === 'notifications') { openOverlay({type:'notifications'}); return; }
  if (action === 'close-overlay') { closeOverlay(); return; }
  if (action === 'close-overlay-bg') { if (event.target === target) closeOverlay(); return; }
  if (action === 'quick-create') { openOverlay({type:'quick', kind:target.dataset.kind || ''}); return; }
  if (action === 'quick-select') { openOverlay({type:'quick', kind:target.dataset.kind}); return; }
  if (action === 'quick-submit') { submitQuickAction(target.dataset.kind); return; }
  if (action === 'open-task') { openOverlay({type:'task',id}); return; }
  if (action === 'open-approval') { openOverlay({type:'approval',id}); return; }
  if (action === 'work-tab') { state.work.tab = target.dataset.tab; render(); return; }
  if (action === 'work-view') { state.work.view = target.dataset.mode; render(); return; }
  if (action === 'approval-filter') { state.approvalFilter = target.dataset.filter; render(); return; }
  if (action === 'approval-action') { openOverlay({type:'action',kind:'approval',id,result:target.dataset.result,label:`${target.dataset.result} approval`}); return; }
  if (action === 'exception-filter') { state.exceptionFilter = target.dataset.filter; render(); return; }
  if (action === 'exception-action') { openOverlay({type:'action',kind:'exception',id,result:target.dataset.result,label:`${target.dataset.result} exception`}); return; }
  if (action === 'exception-assign') { openOverlay({type:'exceptionAssign',id}); return; }
  if (action === 'exception-create') { openOverlay({type:'exceptionCreate'}); return; }
  if (action === 'save-exception-assignment') { saveExceptionAssignment(id); return; }
  if (action === 'save-new-exception') { saveNewException(); return; }
  if (action === 'task-start') { updateTaskStart(id); return; }
  if (action === 'task-note') { openOverlay({type:'action',kind:'taskNote',id}); return; }
  if (action === 'task-complete') { openOverlay({type:'action',kind:'taskComplete',id}); return; }
  if (action === 'task-reassign') { openOverlay({type:'action',kind:'taskReassign',id}); return; }
  if (action === 'confirm-action') { confirmAction(target.dataset.kind, id, target.dataset.result); return; }
  if (action === 'builder-device') { state.builder.device = target.dataset.device; render(); return; }
  if (action === 'builder-select') { state.builder.selectedWidgetId = target.dataset.widget; render(); return; }
  if (action === 'builder-add') { builderAdd(target.dataset.widget); return; }
  if (action === 'builder-remove') { builderRemove(target.dataset.widget); return; }
  if (action === 'builder-size') { builderSize(target.dataset.widget, Number(target.dataset.span)); return; }
  if (action === 'builder-toggle-property') { builderToggle(target.dataset.widget, target.dataset.property); return; }
  if (action === 'builder-reset') { builderReset(); return; }
  if (action === 'builder-preview') { openOverlay({type:'builderPreview'}); return; }
  if (action === 'builder-save') { logAudit('Saved personal dashboard', `${state.builder.targetType}:${state.builder.targetId}`, 'Dashboard', 'Success', 'Draft layout saved locally.'); toast('Dashboard saved','Your personal layout has been saved.'); return; }
  if (action === 'builder-publish') { builderPublish(); return; }
  if (action === 'builder-undo') { builderUndo(); return; }
  if (action === 'builder-redo') { builderRedo(); return; }
  if (action === 'select-role') { state.roleStudio.roleId = target.dataset.role; state.roleStudio.tab = 'permissions'; render(); return; }
  if (action === 'role-tab') { state.roleStudio.tab = target.dataset.tab; render(); return; }
  if (action === 'permission-state') { updatePermissionState(target.dataset.role,target.dataset.code,target.dataset.state); return; }
  if (action === 'permission-delegate') { togglePermissionDelegate(target.dataset.role,target.dataset.code); return; }
  if (action === 'role-scope-type') { updateRoleScope(target.dataset.role,target.dataset.scope); return; }
  if (action === 'role-widget-toggle') { toggleRoleWidget(target.dataset.role,target.dataset.widget); return; }
  if (action === 'role-dashboard-right') { toggleDashboardRight(target.dataset.role,target.dataset.right); return; }
  if (action === 'save-role') { saveRolePublish(); return; }
  if (action === 'create-role') { openOverlay({type:'createRole'}); return; }
  if (action === 'save-new-role') { saveNewRole(); return; }
  if (action === 'user-view') { state.userView = target.dataset.mode; render(); return; }
  if (action === 'direct-grant') { openOverlay({type:'grant',id}); return; }
  if (action === 'save-grant') { saveDirectGrant(target.dataset.user); return; }
  if (action === 'revoke-grant') { revokeGrant(target.dataset.user,target.dataset.grant); return; }
  if (action === 'view-user-access') { openOverlay({type:'userAccess',id}); return; }
  if (action === 'user-activity') { openOverlay({type:'userActivity',id}); return; }
  if (action === 'edit-user') { openOverlay({type:'editUser',id}); return; }
  if (action === 'create-user') { openOverlay({type:'createUser'}); return; }
  if (action === 'save-user') { saveUser(id || null); return; }
  if (action === 'run-simulator') { runSimulator(); return; }
  if (action === 'simulator-reset') { state.simulator.result = null; render(); return; }
  if (action === 'command-select') { executeCommand(target.dataset.command,target.dataset.value); return; }
  if (action === 'notification-open') { closeOverlay(); toast('Notification opened',target.dataset.label); return; }
  if (action === 'widget-drilldown') { widgetDrilldown(target.dataset.widget); return; }
  if (action === 'widget-menu') { toast('Widget options','Use Dashboard Builder to configure this widget.'); return; }
  if (action.startsWith('export-')) { exportCurrent(action.replace('export-','')); return; }
}

document.addEventListener('click', handleClick);

document.addEventListener('input', (event) => {
  const target = event.target;
  if (target.id === 'loginSearch') {
    const q = target.value.toLowerCase();
    $$('.persona-card').forEach((card) => { card.style.display = card.textContent.toLowerCase().includes(q) ? '' : 'none'; });
    return;
  }
  if (target.id === 'commandSearch') {
    state.overlay = {type:'command',query:target.value};
    renderOverlay();
    return;
  }
  if (target.id === 'widgetCustomTitle') {
    const {layout} = getBuilderTarget();
    const item = layout.find((entry)=>entry.id===state.builder.selectedWidgetId);
    if (item) { item.customTitle = target.value; persist(); }
    return;
  }
  debounceInput(target.id,target.value);
});

let inputTimer = null;
function debounceInput(id,value) {
  clearTimeout(inputTimer);
  inputTimer = setTimeout(() => {
    if (id === 'workSearch') state.work.search = value;
    else if (id === 'userSearch') state.userSearch = value;
    else if (id === 'auditSearch') state.auditSearch = value;
    else if (id === 'permissionSearch') state.roleStudio.search = value;
    else if (id === 'builderSearch') state.builder.search = value;
    else return;
    render();
  }, 220);
}

document.addEventListener('change', (event) => {
  const target = event.target;
  if (target.id === 'workPriority') { state.work.priority = target.value; render(); }
  else if (target.id === 'workModule') { state.work.module = target.value; render(); }
  else if (target.id === 'permissionGroup') { state.roleStudio.group = target.value; render(); }
  else if (target.id === 'builderTargetType') {
    state.builder.targetType = target.value;
    state.builder.targetId = targetIdOptions(target.value)[0]?.id || currentUser().id;
    state.builder.selectedWidgetId = null;
    state.builder.history = [];
    state.builder.future = [];
    render();
  }
  else if (target.id === 'builderTargetId') { state.builder.targetId = target.value; state.builder.selectedWidgetId = null; state.builder.history=[]; state.builder.future=[]; render(); }
  else if (target.id === 'simUser') { state.simulator.userId = target.value; persist(); }
  else if (target.id === 'simPermission') { state.simulator.permission = target.value; persist(); }
  else if (target.id === 'simPlant') { state.simulator.plant = target.value; persist(); }
});

document.addEventListener('keydown', (event) => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
    event.preventDefault();
    if (state.currentUserId) openOverlay({type:'command',query:''});
  }
  if (event.key === 'Escape' && state.overlay) closeOverlay();
  if (state.overlay?.type === 'command' && /^[1-9]$/.test(event.key)) {
    const item = commandItems(state.overlay.query || '')[Number(event.key)-1];
    if (item) executeCommand(item.action,item.value);
  }
});

let draggedWidgetId = null;
document.addEventListener('dragstart', (event) => {
  const widget = event.target.closest('[data-builder-widget]');
  if (!widget || widget.getAttribute('draggable') !== 'true') return;
  draggedWidgetId = widget.dataset.builderWidget;
  widget.classList.add('dragging');
  event.dataTransfer.effectAllowed = 'move';
  event.dataTransfer.setData('text/plain',draggedWidgetId);
});
document.addEventListener('dragover', (event) => {
  const widget = event.target.closest('[data-builder-widget]');
  if (!widget || !draggedWidgetId) return;
  event.preventDefault();
  widget.classList.add('drag-over');
});
document.addEventListener('dragleave', (event) => {
  const widget = event.target.closest('[data-builder-widget]');
  widget?.classList.remove('drag-over');
});
document.addEventListener('drop', (event) => {
  const target = event.target.closest('[data-builder-widget]');
  if (!target || !draggedWidgetId) return;
  event.preventDefault();
  target.classList.remove('drag-over');
  reorderBuilder(draggedWidgetId,target.dataset.builderWidget);
  draggedWidgetId = null;
});
document.addEventListener('dragend', () => {
  $$('.builder-widget').forEach((widget)=>widget.classList.remove('dragging','drag-over'));
  draggedWidgetId = null;
});

function submitQuickAction(kind) {
  const reference = $('#quickReference')?.value.trim();
  const note = $('#quickNote')?.value.trim();
  if (!reference || !note) { toast('Missing details','Reference and note are required.','error'); return; }
  const mapping = {
    'Post a GRN':{type:'GRN',module:'Inbound',action:'Post GRN'},
    'Complete QC':{type:'QC',module:'Quality',action:'Complete Inspection'},
    'Record output':{type:'Job Card',module:'Production',action:'Record Output'},
    'Upload POD':{type:'POD',module:'Dispatch',action:'Close Dispatch'},
    'Log exception':null
  };
  if (kind === 'Log exception') { state.overlay = {type:'exceptionCreate'}; renderOverlay(); return; }
  const config = mapping[kind];
  if (!config) return;
  const newTask = {
    id:`TSK-${Math.floor(1100+Math.random()*800)}`, type:config.type,module:config.module,title:`${kind} · ${reference}`,description:note,
    plant:$('#quickPlant')?.value || currentUser().plant,team:currentUser().team,assignedTo:currentUser().id,status:'todo',priority:'medium',due:'Today',age:'Just now',action:config.action,
    permission:'space.tasks.complete',batch:'To be selected',quantity:'To be entered',reference,value:'—',vendor:'Internal / authorised source',evidence:'Required before completion',timeline:[['Created from quick action',`${currentUser().name} · now`]]
  };
  state.tasks.unshift(newTask);
  logAudit('Created quick action task',newTask.id,'Task','Success',`${kind} · ${reference}`);
  closeOverlay();
  toast('Task created',`${newTask.id} was added to My Work.`);
  if (state.view === 'work' || state.view === 'dashboard') render();
}

function updateTaskStart(id) {
  const task = state.tasks.find((item)=>item.id===id);
  if (!task || !has('space.tasks.update',task)) { toast('Access denied','You cannot start this task.','error'); return; }
  task.status = 'in_progress';
  task.timeline.push(['Task started',`${currentUser().name} · now`]);
  logAudit('Started task',task.id,'Task','Success',task.title);
  closeOverlay();
  toast('Task started',task.title);
  render();
}

function confirmAction(kind,id,result) {
  const reason = $('#actionReason')?.value.trim();
  if (!reason) { toast('Reason required','Add an auditable reason or note before confirming.','error'); return; }
  if (kind === 'taskComplete' || kind === 'taskNote' || kind === 'taskReassign') {
    const task = state.tasks.find((item)=>item.id===id);
    if (!task) return;
    if (kind === 'taskComplete') {
      if (!has(task.permission,task)) { toast('Access denied','Task completion permission is missing.','error'); return; }
      task.status = 'done';
      task.timeline.push([`${task.action} completed`,`${currentUser().name} · now · ${reason}`]);
      logAudit(`Completed ${task.type}`,task.id,'Task','Success',reason);
      toast('Task completed',`${task.id} moved to completed.`);
    } else if (kind === 'taskNote') {
      if (!has('space.tasks.update',task)) { toast('Access denied','Task update permission is missing.','error'); return; }
      task.timeline.push(['Progress note added',`${currentUser().name} · now · ${reason}`]);
      logAudit('Added task note',task.id,'Task','Success',reason);
      toast('Note added',task.id);
    } else {
      if (!has('space.tasks.reassign',task)) { toast('Access denied','Task reassignment permission is missing.','error'); return; }
      const assigneeId = $('#actionAssignee')?.value;
      const assignee = userById(assigneeId);
      if (!assignee || !isSubordinate(currentUser(),assignee)) { toast('Invalid assignee','Choose an authorised subordinate.','error'); return; }
      task.assignedTo = assigneeId;
      task.team = assignee.team;
      task.timeline.push(['Task reassigned',`${currentUser().name} → ${assignee.name} · ${reason}`]);
      logAudit('Reassigned task',task.id,'Task','Success',`${assignee.name} · ${reason}`);
      toast('Task reassigned',`${task.id} → ${assignee.name}`);
    }
  } else if (kind === 'approval') {
    const approval = state.approvals.find((item)=>item.id===id);
    if (!approval) return;
    const permission = result === 'approved' ? 'space.approvals.approve' : result === 'rejected' ? 'space.approvals.reject' : 'space.approvals.return';
    if (!has(permission,approval)) { toast('Access denied',`Missing ${permission}.`,'error'); return; }
    approval.status = result;
    approval.decisionReason = reason;
    approval.decidedBy = currentUser().name;
    approval.decidedAt = new Date().toISOString();
    logAudit(`${result[0].toUpperCase()+result.slice(1)} approval`,approval.id,'Approval','Success',reason);
    toast(`Approval ${result}`,approval.title);
  } else if (kind === 'exception') {
    const exception = state.exceptions.find((item)=>item.id===id);
    if (!exception) return;
    const permission = result === 'resolved' ? 'space.exceptions.resolve' : 'space.exceptions.ack';
    if (!has(permission,exception)) { toast('Access denied',`Missing ${permission}.`,'error'); return; }
    exception.status = result;
    exception.resolution = reason;
    logAudit(`${result[0].toUpperCase()+result.slice(1)} exception`,exception.id,'Exception','Success',reason);
    toast(`Exception ${result}`,exception.title);
  }
  closeOverlay();
  render();
}

function saveExceptionAssignment(id) {
  const exception = state.exceptions.find((item)=>item.id===id);
  const owner = userById($('#exceptionOwner')?.value);
  const note = $('#exceptionNote')?.value.trim();
  if (!exception || !owner || !note) { toast('Missing details','Owner and assignment note are required.','error'); return; }
  if (!has('space.exceptions.assign',exception)) { toast('Access denied','Exception assignment permission is missing.','error'); return; }
  exception.owner = owner.name;
  exception.ownerId = owner.id;
  exception.status = 'acknowledged';
  exception.target = $('#exceptionTarget')?.value;
  logAudit('Assigned exception',exception.id,'Exception','Success',`${owner.name} · ${note}`);
  closeOverlay(); render(); toast('Exception assigned',`${exception.id} → ${owner.name}`);
}

function saveNewException() {
  const title = $('#newExceptionTitle')?.value.trim();
  const description = $('#newExceptionDescription')?.value.trim();
  if (!title || !description) { toast('Missing details','Title and description are required.','error'); return; }
  const category = $('#newExceptionCategory')?.value || 'Operations';
  const exception = {id:`EXC-${Math.floor(260800+Math.random()*900)}`,category,severity:$('#newExceptionSeverity')?.value||'medium',title,description,plant:$('#newExceptionPlant')?.value||currentUser().plant,owner:currentUser().name,ownerId:currentUser().id,age:'Just now',impact:'To be assessed',status:'open',rule:'Manually logged',reference:$('#newExceptionReference')?.value||'—'};
  state.exceptions.unshift(exception);
  logAudit('Logged exception',exception.id,'Exception','Success',title);
  closeOverlay(); render(); toast('Exception created',exception.id);
}

function snapshotBuilder() {
  const {layout} = getBuilderTarget();
  state.builder.history.push(clone(layout));
  if (state.builder.history.length > 20) state.builder.history.shift();
  state.builder.future = [];
}
function builderAdd(widgetId) {
  const widget = widgetCatalog.find((item)=>item.id===widgetId);
  const {layout} = getBuilderTarget();
  if (!widget || !has(widget.permission) || layout.some((item)=>item.id===widgetId) || !canEditBuilderTarget()) return;
  snapshotBuilder();
  layout.push({id:widgetId,span:widget.defaultSpan,locked:false,mandatory:false});
  state.builder.selectedWidgetId = widgetId;
  render();
}
function builderRemove(widgetId) {
  const {layout} = getBuilderTarget();
  const item = layout.find((entry)=>entry.id===widgetId);
  if (!item || item.mandatory || !canEditBuilderTarget() || (item.locked && currentUser().level>=3)) { toast('Widget locked','This widget cannot be removed at your hierarchy level.','error'); return; }
  snapshotBuilder();
  state.layouts[getBuilderTarget().key] = layout.filter((entry)=>entry.id!==widgetId);
  state.builder.selectedWidgetId = null;
  render();
}
function builderSize(widgetId,span) {
  const {layout} = getBuilderTarget();
  const item = layout.find((entry)=>entry.id===widgetId);
  if (!item || !canEditBuilderTarget() || (item.locked && currentUser().level>=3)) return;
  snapshotBuilder(); item.span = span; render();
}
function builderToggle(widgetId,property) {
  const {layout} = getBuilderTarget();
  const item = layout.find((entry)=>entry.id===widgetId);
  if (!item) return;
  if (['locked','mandatory'].includes(property) && !has('space.builder.lock')) { toast('Access denied','Widget lock permission is required.','error'); return; }
  if (!canEditBuilderTarget()) return;
  snapshotBuilder(); item[property] = !item[property]; render();
}
function reorderBuilder(sourceId,targetId) {
  const {layout} = getBuilderTarget();
  if (!canEditBuilderTarget()) return;
  const source = layout.find((entry)=>entry.id===sourceId);
  if (!source || (source.locked && currentUser().level>=3)) { toast('Widget locked','This widget position is locked.','error'); return; }
  const from = layout.findIndex((entry)=>entry.id===sourceId);
  const to = layout.findIndex((entry)=>entry.id===targetId);
  if (from<0 || to<0 || from===to) return;
  snapshotBuilder();
  const [moved] = layout.splice(from,1); layout.splice(to,0,moved);
  render();
}
function builderReset() {
  if (!canEditBuilderTarget()) return;
  snapshotBuilder();
  const {key} = getBuilderTarget();
  const type = state.builder.targetType;
  state.layouts[key] = clone(type==='organisation'?defaultLayouts.organisation:type==='personal'&&userById(state.builder.targetId)?.level===3?defaultLayouts.executive:defaultLayouts.manager);
  state.builder.selectedWidgetId = null; render(); toast('Layout reset','Default role-aware layout restored.');
}
function builderUndo() {
  if (!state.builder.history.length) return;
  const {key,layout} = getBuilderTarget();
  state.builder.future.push(clone(layout));
  state.layouts[key] = state.builder.history.pop();
  state.builder.selectedWidgetId = null; render();
}
function builderRedo() {
  if (!state.builder.future.length) return;
  const {key,layout} = getBuilderTarget();
  state.builder.history.push(clone(layout));
  state.layouts[key] = state.builder.future.pop();
  state.builder.selectedWidgetId = null; render();
}
function builderPublish() {
  if (!has('space.builder.publish') || !canEditBuilderTarget()) { toast('Access denied','Dashboard publish permission is missing.','error'); return; }
  const {layout} = getBuilderTarget();
  let recipients = [];
  if (state.builder.targetType === 'personal') recipients = [userById(state.builder.targetId)].filter(Boolean);
  else if (state.builder.targetType === 'team') recipients = state.users.filter((user)=>user.team===state.builder.targetId && user.status==='active');
  else if (state.builder.targetType === 'role') recipients = state.users.filter((user)=>user.roleId===state.builder.targetId && user.status==='active');
  else recipients = state.users.filter((user)=>user.status==='active');
  recipients.forEach((user)=> { state.layouts[layoutKey('personal',user.id)] = clone(layout); });
  logAudit('Published dashboard',`${state.builder.targetType}:${state.builder.targetId}`,'Dashboard','Success',`${recipients.length} users impacted; ${layout.length} widgets.`);
  persist(); toast('Dashboard published',`${recipients.length} user dashboards updated.`); render();
}

function updatePermissionState(roleId,code,nextState) {
  const role = roleById(roleId);
  if (!role || !permissionEditableForRole(role,code)) { toast('Permission locked','This change is outside your delegation ceiling.','error'); return; }
  role.allow = role.allow.filter((item)=>item!==code);
  role.deny = role.deny.filter((item)=>item!==code);
  if (nextState === 'allow') role.allow.push(code);
  if (nextState === 'deny') { role.deny.push(code); role.delegate = role.delegate.filter((item)=>item!==code); }
  render();
}
function togglePermissionDelegate(roleId,code) {
  const role = roleById(roleId);
  if (!role || currentUser().level !== 1 || !canEditRole(role) || rolePermissionState(role,code)!=='allow') return;
  if (role.delegate.includes(code)) role.delegate = role.delegate.filter((item)=>item!==code);
  else role.delegate.push(code);
  render();
}
function updateRoleScope(roleId,scope) {
  const role = roleById(roleId);
  if (!role || !canEditRole(role)) return;
  role.scope.type = scope;
  role.scope.values = scope==='all'?['All Units']:scope==='plant'?[currentUser().plant]:scope==='team'?[currentUser().team||'Managed Team']:['Assigned Records'];
  render();
}
function toggleRoleWidget(roleId,widgetId) {
  const role = roleById(roleId); const widget = widgetCatalog.find((item)=>item.id===widgetId);
  if (!role || !widget || !permissionEditableForRole(role,widget.permission)) return;
  if (role.widgetIds.includes(widgetId)) role.widgetIds = role.widgetIds.filter((id)=>id!==widgetId);
  else { role.widgetIds.push(widgetId); if (!role.allow.includes(widget.permission) && !role.allow.includes('*')) role.allow.push(widget.permission); role.deny = role.deny.filter((item)=>item!==widget.permission); }
  render();
}
function toggleDashboardRight(roleId,right) {
  const role = roleById(roleId);
  if (!role || !canEditRole(role)) return;
  role.dashboardRights[right] = !role.dashboardRights[right];
  render();
}
function saveRolePublish() {
  const role = roleById(state.roleStudio.roleId);
  if (!role || !canEditRole(role)) return;
  logAudit('Published role policy',role.name,'Access','Success',`${role.allow.length} allows, ${role.deny.length} denies, ${role.delegate.length} delegable.`);
  persist(); toast('Role published',`${role.name} effective access is updated.`); render();
}
function saveNewRole() {
  const name = $('#newRoleName')?.value.trim();
  const description = $('#newRoleDescription')?.value.trim();
  const level = Number($('#newRoleLevel')?.value || 3);
  const parentId = $('#newRoleParent')?.value;
  if (!name || !description) { toast('Missing details','Role name and description are required.','error'); return; }
  if (level <= currentUser().level) { toast('Invalid hierarchy','New role must be below your hierarchy level.','error'); return; }
  const role = {id:uid('role'),name,label:`Level ${level} · Custom`,level,parentId,color:'#0fbd8c',soft:'#e7fbf4',description,scope:{type:$('#newRoleScope')?.value||'assigned',values:['Assigned Records']},allow:[],deny:[],delegate:[],widgetIds:[],dashboardRights:{personal:level===3,team:false,role:false,org:false,publish:false,lock:false}};
  state.roles.push(role); state.roleStudio.roleId = role.id; state.roleStudio.tab='permissions';
  logAudit('Created role',role.name,'Access','Success','Default deny role created.');
  closeOverlay(); render(); toast('Role created',`${role.name} starts with default deny.`);
}

function saveDirectGrant(userId) {
  const user = userById(userId);
  const permission = $('#grantPermission')?.value;
  const effect = $('#grantEffect')?.value;
  const expiresAt = $('#grantExpiry')?.value;
  const reason = $('#grantReason')?.value.trim();
  if (!user || !permission || !reason || !expiresAt) { toast('Missing details','Permission, expiry and business reason are required.','error'); return; }
  if (!isSubordinate(currentUser(),user) || !canDelegate(permission) || !has('space.users.direct_grant')) { toast('Grant blocked','The user or permission is outside your delegation ceiling.','error'); return; }
  user.direct = user.direct || [];
  user.direct.push({id:uid('grant'),permission,effect,reason,expiresAt,grantedBy:currentUser().id,grantedAt:new Date().toISOString()});
  logAudit(`Added direct ${effect}`,user.name,'Access','Success',`${permission} until ${expiresAt} · ${reason}`);
  closeOverlay(); render(); toast('Direct access added',`${effect.toUpperCase()} ${permission} for ${user.name}.`);
}
function revokeGrant(userId,grantId) {
  const user = userById(userId);
  if (!user || !isSubordinate(currentUser(),user)) return;
  const grant = user.direct.find((item)=>item.id===grantId);
  user.direct = user.direct.filter((item)=>item.id!==grantId);
  logAudit('Revoked direct grant',user.name,'Access','Success',grant?.permission||grantId);
  state.overlay = {type:'grant',id:userId}; render(); toast('Direct access revoked',grant?.permission||'Permission');
}
function saveUser(userId) {
  const editing = Boolean(userId);
  const roleId = $('#editUserRole')?.value; const role = roleById(roleId);
  const name = $('#editUserName')?.value.trim(); const email = $('#editUserEmail')?.value.trim();
  if (!name || !email || !role) { toast('Missing details','Name, email and role are required.','error'); return; }
  if (role.level <= currentUser().level) { toast('Invalid role','You can assign only a role below your hierarchy level.','error'); return; }
  const plant = $('#editUserPlant')?.value;
  if (currentUser().level===2 && !currentRole().scope.values.some((value)=>value.includes(plant))) { toast('Scope blocked','The selected plant is outside your manager scope.','error'); return; }
  let user = editing ? userById(userId) : null;
  if (editing && !isSubordinate(currentUser(),user) && currentUser().id!==user.id) { toast('Access denied','You cannot edit this user.','error'); return; }
  if (!user) {
    user = {id:uid('u'),initials:name.split(' ').map((part)=>part[0]).join('').slice(0,2).toUpperCase(),level:role.level,vertical:role.name.replace(' Executive','').replace(' Manager',''),lastActive:new Date().toISOString(),direct:[]};
    state.users.push(user);
  }
  Object.assign(user,{name,email,phone:$('#editUserPhone')?.value||'',status:$('#editUserStatus')?.value||'active',roleId,level:role.level,plant,team:$('#editUserTeam')?.value||'Assigned Team',managerId:$('#editUserManager')?.value||currentUser().id,title:role.name});
  logAudit(editing?'Updated user':'Created user',user.name,'Access','Success',`${role.name} · ${plant}`);
  closeOverlay(); render(); toast(editing?'User updated':'User created',user.name);
}

function runSimulator() {
  const userId = $('#simUser')?.value || state.simulator.userId;
  const permission = $('#simPermission')?.value || state.simulator.permission;
  const plant = $('#simPlant')?.value || state.simulator.plant;
  const assignedTo = $('#simAssigned')?.value || null;
  state.simulator.userId=userId; state.simulator.permission=permission; state.simulator.plant=plant;
  state.simulator.result = resolvePermission(userById(userId),permission,{plant,assignedTo});
  render();
}
function executeCommand(command,value) {
  closeOverlay();
  if (command === 'navigate') navigate(value);
  else if (command === 'open-task') openOverlay({type:'task',id:value});
  else if (command === 'view-user-access') openOverlay({type:'userAccess',id:value});
}
function widgetDrilldown(widgetId) {
  const widget = widgetCatalog.find((item)=>item.id===widgetId);
  if (!widget || !has(widget.permission)) { toast('Access denied','Widget data permission is missing.','error'); return; }
  const route = widgetId==='myTasks'?'work':widgetId==='approvalQueue'?'approvals':widgetId==='exceptions'?'exceptions':null;
  if (route) navigate(route); else toast(`${widget.name} drilldown`,'Plant, SKU, batch, machine and warehouse filters are available in the production integration.');
}

function exportCurrent(kind) {
  if (kind==='audit' && !has('space.audit.export')) { toast('Access denied','Audit export permission is missing.','error'); return; }
  if (kind!=='audit' && !has('space.export')) { toast('Access denied','Export permission is missing.','error'); return; }
  let rows=[]; let filename=`tan90-${kind}.csv`;
  if (kind==='work') rows=visibleTasksFor().map(({id,type,module,title,plant,team,status,priority,due,reference})=>({id,type,module,title,plant,team,status,priority,due,reference}));
  else if (kind==='approvals') rows=visibleApprovalsFor().map(({id,type,title,requester,department,plant,amount,risk,sla,status})=>({id,type,title,requester,department,plant,amount:has('field.financial_value.view')?amount:'MASKED',risk,sla,status}));
  else if (kind==='exceptions') rows=visibleExceptionsFor().map(({id,category,severity,title,plant,owner,age,impact,status,reference})=>({id,category,severity,title,plant,owner,age,impact,status,reference}));
  else if (kind==='audit') rows=state.audit.map(({id,at,actor,action,object,category,result,detail})=>({id,at,actor,action,object,category,result,detail}));
  if (!rows.length) { toast('Nothing to export','No authorised rows are available.','error'); return; }
  downloadCsv(filename,rows); logAudit(`Exported ${kind}`,filename,'Export','Success',`${rows.length} rows`); toast('Export ready',`${rows.length} rows downloaded.`);
}
function downloadCsv(filename,rows) {
  const headers=Object.keys(rows[0]);
  const csv=[headers.join(','),...rows.map((row)=>headers.map((header)=>`"${String(row[header]??'').replace(/"/g,'""')}"`).join(','))].join('\n');
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}); const url=URL.createObjectURL(blob); const anchor=document.createElement('a'); anchor.href=url; anchor.download=filename; anchor.click(); URL.revokeObjectURL(url);
}

function setupCanvas(canvas) {
  if (!canvas) return null;
  const rect = canvas.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1,2);
  canvas.width = Math.max(1,Math.floor(rect.width*dpr));
  canvas.height = Math.max(1,Math.floor(rect.height*dpr));
  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr,0,0,dpr,0,0);
  return {ctx,width:rect.width,height:rect.height};
}
function cssVar(name) { return getComputedStyle(document.documentElement).getPropertyValue(name).trim(); }
function drawDashboardCharts() {
  drawProductionTrend($('#productionTrendCanvas'));
  drawUnitPerformance($('#unitPerformanceCanvas'));
}
function drawProductionTrend(canvas) {
  const setup=setupCanvas(canvas); if(!setup) return;
  const {ctx,width,height}=setup; const pad={l:34,r:10,t:14,b:26}; const w=width-pad.l-pad.r; const h=height-pad.t-pad.b;
  const actual=[12.6,14.2,13.8,16.5,17.1,18.4,18.9]; const target=[13.2,13.8,14.6,15.4,16.3,17.0,17.8]; const good=[12.1,13.8,13.4,15.9,16.5,17.9,18.2]; const labels=['29 Jul','30','31','01 Aug','02','03','04']; const max=20;
  ctx.clearRect(0,0,width,height); ctx.font='7px Inter, sans-serif'; ctx.fillStyle=cssVar('--subtle')||'#98a3b4'; ctx.strokeStyle=cssVar('--line')||'#e3e8ef'; ctx.lineWidth=1;
  for(let i=0;i<=4;i++){const y=pad.t+h-(i/4)*h;ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(width-pad.r,y);ctx.stroke();ctx.fillText(String(i*5),4,y+3);}
  labels.forEach((label,i)=>{const x=pad.l+(i/(labels.length-1))*w;ctx.fillText(label,x-8,height-7);});
  const draw=(data,color,dash=[])=>{ctx.beginPath();ctx.setLineDash(dash);ctx.strokeStyle=color;ctx.lineWidth=2;data.forEach((value,i)=>{const x=pad.l+(i/(data.length-1))*w;const y=pad.t+h-(value/max)*h;i?ctx.lineTo(x,y):ctx.moveTo(x,y);});ctx.stroke();ctx.setLineDash([]);if(!dash.length){data.forEach((value,i)=>{const x=pad.l+(i/(data.length-1))*w;const y=pad.t+h-(value/max)*h;ctx.beginPath();ctx.arc(x,y,2.5,0,Math.PI*2);ctx.fillStyle=color;ctx.fill();});}};
  draw(target,'#91a0b5',[4,4]); draw(good,'#2979ff'); draw(actual,'#0fbd8c');
}
function drawUnitPerformance(canvas) {
  const setup=setupCanvas(canvas); if(!setup) return;
  const {ctx,width,height}=setup; const labels=['Output','Quality','SLA','Utilisation']; const values=[[92,88,95,84],[85,94,89,78],[76,91,82,74]]; const colors=['#0fbd8c','#2979ff','#7857e8']; const pad={l:35,r:10,t:12,b:28}; const w=width-pad.l-pad.r; const h=height-pad.t-pad.b;
  ctx.clearRect(0,0,width,height);ctx.font='7px Inter, sans-serif';ctx.strokeStyle=cssVar('--line')||'#e3e8ef';ctx.fillStyle=cssVar('--subtle')||'#98a3b4';
  for(let i=0;i<=4;i++){const y=pad.t+h-(i/4)*h;ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(width-pad.r,y);ctx.stroke();ctx.fillText(String(i*25),5,y+3);}
  const groupW=w/labels.length; const barW=Math.min(16,groupW/5);
  labels.forEach((label,index)=>{const base=pad.l+index*groupW+groupW/2;ctx.fillText(label,base-13,height-8);values.forEach((series,s)=>{const value=series[index];const x=base+(s-1)*barW*1.15-barW/2;const bh=(value/100)*h;ctx.fillStyle=colors[s];ctx.beginPath();ctx.roundRect(x,pad.t+h-bh,barW,bh,3);ctx.fill();});});
}

window.addEventListener('resize',()=>{ if(state.view==='dashboard') requestAnimationFrame(drawDashboardCharts); });
document.addEventListener('focusin',(event)=>{ if(event.target.id==='globalSearch'){ openOverlay({type:'command',query:event.target.value||''}); } });
document.addEventListener('input',(event)=>{ if(event.target.id==='globalSearch'){ openOverlay({type:'command',query:event.target.value||''}); } });

render();
