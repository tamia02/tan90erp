# Research Basis and Design Decisions

## Tan90 requirements used

The supplied Tan90 material describes an end-to-end manufacturing flow from customer demand and planning through procurement, GRN, QC, inventory, material issue, production/machine usage/wastage, finished-goods stock, dispatch, POD closure and reporting. Space 01 therefore acts as an aggregation and action layer over those processes rather than a replacement for each transaction module.

The public Tan90 blueprint similarly positions the MVP around material, production, quality and dispatch, with cockpit KPIs for production, pending QC, low stock and dispatch closure.

Sources:
- https://tan90.tesmed.in/
- https://tan90.tesmed.in/modules.html
- User-provided `Pasted text(11).txt`

## Manufacturing architecture

ISA-95 defines a technology-neutral framework for integrating enterprise/business functions with manufacturing operations and control. Its activity-oriented separation supports the decision to keep Space 01 as an ERP/MOM command and work surface while operational transactions remain owned by their respective domain modules.

Sources:
- https://www.isa.org/standards-and-publications/isa-standards/isa-95-standard
- https://www.isa.org/standards-and-publications/isa-standards/isa-standards-committees/isa95

## Access-control architecture

NIST's RBAC model includes core RBAC and hierarchical RBAC, which supports the Super Admin → Manager → Executive hierarchy and role inheritance. The MVP extends role decisions with contextual scopes and individual overrides because manufacturing access also depends on plant, team, assigned work and record context.

Sources:
- https://csrc.nist.gov/projects/role-based-access-control
- https://csrc.nist.gov/Projects/role-based-access-control/faqs

OWASP authorization guidance recommends least privilege, deny by default, validation on every request, logging and authorization test cases. The proposed backend therefore treats frontend visibility as convenience only and re-evaluates permission and scope on every API action.

Source:
- https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html

## Traceability and event design

GS1 traceability guidance distinguishes Critical Tracking Events from their Key Data Elements. Space 01's task, approval, exception and audit events are therefore designed to retain who/what/where/when/why context and link to original GRN, batch, work order, machine or dispatch records.

Sources:
- https://www.gs1.org/standards/traceability
- https://www.gs1.org/standards/gs1-global-traceability-standard/current-standard

## Key product decisions

1. **One focused space, not a second ERP navigation tree.** The home experience prioritises what needs attention now.
2. **Read models for speed.** KPI widgets should consume projections, not execute cross-domain transactional joins on every refresh.
3. **Tasks are deep links, not duplicate transaction forms.** Existing domain pages remain the source of truth.
4. **Permission and dashboard rules are independent.** Users need both data authorization and layout inclusion.
5. **Default deny and explicit delegation.** A manager cannot manufacture access that the parent did not delegate.
6. **Particular-user exceptions are first-class and expiring.** This prevents shared-role proliferation while preserving auditability.
7. **Every decision is explainable.** The Access Simulator exposes the effective-access trace for administrators and support teams.
8. **Responsive and role-aware.** The same space adapts to control-room, desktop and mobile execution without exposing unauthorised information.
