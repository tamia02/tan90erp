# QA Report — Tan90 Space 01 MVP

## Build verified

- JavaScript syntax: passed with Node `--check`.
- Standalone load: passed with all CSS and JavaScript embedded during browser automation.
- Browser console errors: none during automated walkthrough.
- Desktop viewport tested: 1600 × 1000.
- Mobile viewport tested: 390 × 844.

## Automated walkthrough passed

1. Categorised login screen renders.
2. Level 1 Super Admin login opens Command Center.
3. Command Center role-aware shell and widgets render.
4. My Work page opens.
5. Task detail drawer opens and closes.
6. Dashboard Builder renders its widget library and canvas.
7. Role Permission Studio renders the permission matrix.
8. Users & Direct Grants renders hierarchy-aware user cards.
9. Access Simulator runs and returns a decision trace.
10. Persona switch returns to demo login.
11. Level 3 Production Executive mobile dashboard renders.
12. No page or console errors were captured in the walkthrough.

## Functional interactions implemented

- Login and persona switching
- Light/dark theme
- Responsive sidebar
- Command palette/search
- Dashboard drilldown placeholders and quick actions
- Work filters, board/list mode and task status actions
- Approval decision flows
- Exception acknowledge/assign/resolve/create flows
- Widget add/remove/reorder/resize/lock/mandatory controls
- Dashboard target/device selection, preview, reset and publish
- Permission state and delegation toggles
- Role scope/widget/dashboard-right editing
- User create/edit/status/role/manager/plant/team controls
- Direct allow/deny grant with expiry and reason
- Audit filtering and CSV export
- Effective-access simulation and trace
- Browser persistence through localStorage
- PWA shell/service-worker cache when served over HTTP

## Limits of this frontend MVP

- Data is simulated and stored in the current browser.
- It does not post to the existing Tan90 Laravel database.
- Authorization is demonstrated client-side; production security must be server-side.
- Charts are lightweight custom HTML/CSS/SVG representations, not a live BI engine.
- Email/SMS/push notifications are simulated.
- Real-time shop-floor, PLC/MES, vendor or GPS integrations are not included.
- Existing Tan90 transaction routes must be connected during backend integration.

## Preview files

- `previews/01-login.png`
- `previews/02-command-center.png`
- `previews/03-dashboard-builder.png`
- `previews/04-role-permission-studio.png`
- `previews/05-users-direct-grants.png`
- `previews/06-mobile-login.png`
- `previews/07-mobile-executive.png`
