# Tan90 Pulse — Space 01: Command Center & My Work

A self-contained, responsive HTML/CSS/JavaScript MVP for the first Tan90 ERP workspace. It combines live operational visibility, personal work, approvals, exceptions, dashboard personalisation and three-level access governance in one focused space.

## Run

### Fastest
Open `index.html` in Chrome, Edge, Firefox or Safari.

### Recommended local mode
- Windows: double-click `RUN-WINDOWS.bat`
- macOS/Linux: run `./RUN-MAC-LINUX.sh`
- Then open `http://localhost:8080`

Local-server mode also enables the included offline service worker/PWA cache.

## Demo hierarchy

### Level 1 — Super Admin
- **Aarav Malhotra**
- Organisation-wide command center
- All units, roles, users, permissions and dashboard templates
- Can create Level 2 and Level 3 roles, publish organisation baselines and inspect every audit event

### Level 2 — Managers
- **Karan Mehta — Operations Manager**
- **Meera Iyer — Quality Manager**
- Plant/vertical-scoped command center
- Team queues, approvals, exceptions, subordinate users, direct grants and role/team dashboards
- Can delegate only permissions marked delegable and only inside the parent ceiling

### Level 3 — Executives
- **Neha Patel — Production Executive**
- **Riya Nair — QC Executive**
- **Vikram Singh — Store Executive**
- **Aditya Bose — Logistics Executive**
- **Sana Khan — GRN + QC Executive**
- Personal task queue and authorised widgets only
- Can rearrange and resize unlocked personal widgets

No password is required; select a persona from the categorised demo-login screen.

## Functional areas

1. **Command Center** — KPI cards, production trend, E2E readiness, task queue, approval queue, exception radar, unit performance, live activity and quick actions.
2. **My Work** — role-aware board/list views, search, priority/module filters, claim/update/complete actions and task detail drawer.
3. **Approval Center** — scoped requests, amount/risk/SLA indicators, approve/reject/return flows and decision audit.
4. **Alerts & Exceptions** — severity categorisation, acknowledge, assign, resolve and create exception flows.
5. **Dashboard Builder** — authorised widget library, drag/drop, resize, add/remove, lock/mandatory flags, organisation/role/team/personal targets, device preview and publish.
6. **Role Permission Studio** — three-level hierarchy, allow/deny/inherit state, delegation ceiling, data scope, widget access, dashboard rights, assigned users and effective preview.
7. **Users & Direct Grants** — hierarchy-aware user cards, role/manager/plant/team editing, temporary user-specific allow/deny grants with reason and expiry.
8. **Activity & Audit** — operational, dashboard and access events, denied-action logging, filters and CSV export.
9. **Access Simulator** — explains identity, direct override, role policy, data scope and final authorization decision.

## Permission model

Permission codes follow `space.resource.action`, for example:

- `space.dashboard.view`
- `space.tasks.complete`
- `space.approvals.approve`
- `space.exceptions.assign`
- `space.builder.team`
- `space.users.direct_grant`
- `field.internal_notes.view`
- `widget.qc.view`

An effective decision is resolved in this order:

1. Active identity
2. Active direct user deny
3. Active direct user allow
4. Explicit role deny
5. Role allow or wildcard
6. Plant/team/assigned-record scope
7. Final deny-by-default result

UI visibility never acts as the security boundary in the proposed backend architecture. Every data fetch and action must repeat the same authorization decision server-side.

## Dashboard inheritance

`Organisation baseline → role/team template → individual assignment → personal unlocked changes`

A user needs both:
- permission for the underlying data/widget; and
- a layout containing that widget.

Locked or mandatory widgets cannot be removed by lower levels. Executives can customise only unlocked properties.

## Data and persistence

This package is a **fully interactive frontend MVP**. Demo data and user changes persist in browser `localStorage`. It does not include a production database, Laravel APIs, SSO, real-time plant integrations or a server-side authorization engine.

Use `Reset` in Dashboard Builder or clear browser site data to restore defaults.

## Package contents

- `index.html` — application shell
- `styles.css` — complete responsive luxury UI system
- `app.js` — state, demo data, permission engine and all interactions
- `manifest.json`, `sw.js`, `logo.svg` — installable/offline-ready shell
- `ARCHITECTURE.md` — implementation architecture
- `FUNCTIONAL-FLOWS.md` — end-to-end user flows
- `ROLE-PERMISSION-MATRIX.md` — hierarchy and control rules
- `RESEARCH.md` — research basis and design decisions
- `QA-REPORT.md` — tested functions and limits
- `previews/` — desktop and mobile screenshots
