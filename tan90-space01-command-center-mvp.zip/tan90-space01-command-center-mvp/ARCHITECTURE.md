# Space 01 Architecture — Command Center & My Work

## 1. Purpose

Space 01 is the operational entry point for Tan90 ERP. It is not another isolated business module. It aggregates authorised information and actions from procurement, inbound/GRN, inventory, production, quality, warehouse and dispatch into one decision-and-work surface.

It should be added beside current Tan90 pages and workflows, not used to replace them. Deep links from cards and tasks should open the existing operational transaction pages when integrated with Laravel.

## 2. Bounded capabilities

```text
SPACE 01 — COMMAND CENTER & MY WORK
│
├── Cockpit Read Models
│   ├── KPI snapshots
│   ├── trend series
│   ├── unit/plant comparisons
│   └── E2E readiness
│
├── Work Orchestration
│   ├── personal tasks
│   ├── team tasks
│   ├── claims and assignments
│   ├── SLA/escalation
│   └── completion deep links
│
├── Decision Orchestration
│   ├── approvals
│   ├── returns/rejections
│   ├── risk and amount limits
│   └── evidence/comments
│
├── Exception Management
│   ├── alert rules
│   ├── acknowledgement
│   ├── assignment
│   ├── containment/resolution
│   └── escalation
│
├── Personalisation
│   ├── widget catalogue
│   ├── dashboard templates
│   ├── dashboard versions
│   └── user layout preferences
│
└── Access Governance
    ├── roles and hierarchy
    ├── delegation ceilings
    ├── direct user grants
    ├── data scopes
    ├── effective-access resolver
    └── audit trail
```

## 3. Three-level hierarchy

```text
L1 Super Admin
  ├─ owns organisation policy and all-unit visibility
  ├─ creates/manages Level 2 and Level 3 roles
  ├─ defines permission and delegation ceilings
  ├─ publishes organisation dashboard baselines
  └─ audits every access and operational decision
       │
       ▼
L2 Manager
  ├─ restricted by plant/vertical scope and parent ceiling
  ├─ creates subordinate Level 3 roles
  ├─ assigns users in managed teams
  ├─ grants temporary/direct access within delegated rights
  ├─ publishes role/team dashboards
  └─ controls queues, approvals and exceptions in scope
       │
       ▼
L3 Executive
  ├─ sees assigned/authorised work and data only
  ├─ executes GRN, QC, material, production or dispatch actions
  ├─ acknowledges authorised exceptions
  └─ personalises only unlocked dashboard widgets
```

## 4. Permission and scope model

### Permission object

```json
{
  "code": "space.tasks.complete",
  "effect": "allow|deny|inherit",
  "delegable": true,
  "scope": {
    "organisation_ids": [],
    "plant_ids": [],
    "warehouse_ids": [],
    "team_ids": [],
    "record_mode": "all|managed_team|assigned|created_by_me"
  },
  "valid_from": null,
  "valid_until": null,
  "reason": null,
  "locked_by_parent": false
}
```

### Decision precedence

```text
disabled identity                        => DENY
active direct user DENY                  => DENY
explicit role DENY                       => DENY
active direct user ALLOW + valid scope   => ALLOW
role ALLOW + valid scope                 => ALLOW
otherwise                                => DENY
```

A direct allow never bypasses an immutable parent/system denial. A manager may grant only a permission present in the manager's delegable set and may not increase the data scope beyond the manager's own scope.

### Scope intersection

```text
Effective scope = role scope
                ∩ parent ceiling
                ∩ direct-grant scope
                ∩ request context
```

## 5. Dashboard architecture

### Template precedence

```text
Organisation baseline
  ↓ merge permitted overrides
Role or team template
  ↓ merge assigned-user layout
Individual assigned dashboard
  ↓ merge unlocked preferences
Personal dashboard
```

### Widget policy

Each widget has:
- a data permission;
- minimum role/scope requirements;
- allowed sizes;
- refresh/read-model source;
- optional actions;
- locks for visibility, position, size and configuration;
- mandatory flag;
- device layouts.

A layout does not grant data permission. A permission does not automatically add a widget. Both conditions must pass.

## 6. Suggested Laravel implementation

### Additive route group

```text
/workspace
/workspace/my-work
/workspace/approvals
/workspace/exceptions
/workspace/dashboards
/access/roles
/access/users
/access/simulator
/audit
```

Keep existing operational routes unchanged. Workspace actions should call application services that already own GRN/QC/production/dispatch rules.

### Suggested application services

- `EffectiveAccessService`
- `ScopeResolver`
- `DelegationGuard`
- `DashboardResolver`
- `WidgetRegistry`
- `WorkQueueService`
- `ApprovalInboxService`
- `ExceptionService`
- `AuditTrailService`

### Suggested tables

```text
access_roles
access_permissions
access_role_permissions
access_role_hierarchy
access_user_roles
access_user_overrides
access_scope_policies
access_delegation_policies
workspace_tasks
workspace_task_events
workspace_approvals
workspace_approval_events
workspace_exceptions
workspace_exception_events
dashboard_widgets
dashboard_templates
dashboard_template_items
dashboard_assignments
dashboard_user_preferences
dashboard_versions
audit_events
```

Existing users and operational records should be referenced by foreign keys rather than duplicated.

## 7. Read-model strategy

The command center should query purpose-built read models instead of running complex joins across every module on every page load.

Recommended projections:
- `kpi_snapshot_by_plant_shift`
- `open_work_by_user`
- `approval_inbox_by_user`
- `open_exception_by_scope`
- `production_trend_daily`
- `inventory_coverage_by_item`
- `quality_hold_summary`
- `dispatch_closure_summary`

Update projections through domain events or queued jobs. Show a data freshness timestamp on every widget.

## 8. Integration event examples

```text
GrnCreated
IncomingQcCompleted
StockReleased
MaterialIssued
ProductionOutputRecorded
MachineDowntimeRaised
QualityHoldCreated
QualityHoldReleased
DispatchCreated
PodUploaded
DispatchClosed
ApprovalRequested
ApprovalDecided
ExceptionRaised
```

## 9. Security and audit

- Authorize on every API request.
- Deny by default.
- Never trust hidden navigation/buttons.
- Log subject, permission, resource, scope, decision, reason, request ID and timestamp.
- Require reason and expiry for sensitive direct grants.
- Prevent managers from changing their own role or ceiling.
- Record before/after state for permission and dashboard publications.
- Rate-limit exports and sensitive simulation endpoints.

## 10. Non-functional targets

- Initial dashboard shell: under 2 seconds on typical office network.
- Widget data: independently refreshable and failure-isolated.
- WCAG-oriented keyboard/focus states.
- Responsive from 360px mobile to large control-room displays.
- Deterministic authorization with unit and integration tests.
- Optimistic UI only for reversible operations; approvals and postings require server confirmation.
