@echo off
cd /d "%~dp0"
where python >nul 2>nul
if %errorlevel%==0 (
  echo Opening Tan90 Pulse at http://localhost:8080
  start http://localhost:8080
  python -m http.server 8080
) else (
  echo Python was not found. Open index.html directly in Chrome or Edge.
  pause
)
