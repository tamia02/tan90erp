#!/usr/bin/env sh
cd "$(dirname "$0")" || exit 1
printf 'Opening Tan90 Pulse at http://localhost:8080\n'
if command -v python3 >/dev/null 2>&1; then
  (sleep 1; command -v xdg-open >/dev/null && xdg-open http://localhost:8080 >/dev/null 2>&1 || command -v open >/dev/null && open http://localhost:8080) &
  python3 -m http.server 8080
else
  printf 'Python 3 not found. Open index.html directly in a modern browser.\n'
fi
