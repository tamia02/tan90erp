# Three-Level Role and Permission Matrix

## Hierarchy summary

| Capability | L1 Super Admin | L2 Manager | L3 Executive |
|---|---:|---:|---:|
| Organisation-wide dashboard | Yes | No | No |
| Plant/vertical dashboard | Yes | Managed scope | Assigned scope |
| Personal dashboard | Yes | Yes | Yes, unlocked widgets only |
| Publish organisation baseline | Yes | No | No |
| Publish role/team dashboard | Yes | Managed roles/teams | No |
| Create manager role | Yes | No | No |
| Create executive role | Yes | Yes, below own ceiling | No |
| Manage users | All | Direct/managed subordinates | No |
| Give direct user permission | All | Delegable permission only | No |
| Change permission ceiling | Yes | No | No |
| View approvals | All | In scope | Only when explicitly granted |
| Approve/reject | All | Policy/limit/scope based | Normally no; explicit role only |
| Assign exception | All | In scope | Only when explicitly granted |
| Export audit | Yes | In scope when granted | No by default |
| Access simulator | Yes | Managed scope | Self-explanation only |

## Permission states

- **Inherit** — use the parent/template decision.
- **Allow** — grant action within effective scope.
- **Deny** — explicit deny; wins over lower-priority allows.
- **Delegable** — role holder may grant this permission to a subordinate.
- **Locked** — lower hierarchy cannot alter the decision.

## Data scopes

- Organisation
- Plant/unit
- Warehouse
- Vertical/department
- Managed team
- Assigned records
- Created-by-me records
- Shift
- Item/SKU category
- Specific saved view

## Direct grants

A Level 2 manager may grant an individual Level 3 user additional access without changing the shared role when all conditions pass:

1. The user is a subordinate.
2. The manager has the permission.
3. The permission is marked delegable.
4. The requested scope is a subset of the manager's scope.
5. No locked parent/system denial exists.
6. A reason is recorded.
7. Sensitive grants have an expiry and, in production, optional secondary approval.

## Dashboard controls

Dashboard rights are distinct from data rights:

| Right | Meaning |
|---|---|
| Personal customise | Reorder/resize/remove unlocked widgets in own layout |
| Team build | Define default for managed team |
| Role build | Define default for subordinate role |
| Organisation build | Define baseline for all users |
| Publish | Activate a saved draft |
| Lock visibility | Prevent lower level from hiding/removing widget |
| Lock position | Prevent movement |
| Lock size | Prevent resize |
| Lock configuration | Prevent filter/metric changes |

## Example effective decisions

### Production Executive opens approval action
- Role lacks `space.approvals.approve`.
- No active direct allow.
- Result: **DENY**.

### GRN + QC Executive opens incoming-QC task
- Role allows task view/update/complete.
- Widget and field permissions are present.
- Plant matches Bangalore scope.
- Result: **ALLOW**.

### Operations Manager grants QC widget to Production Executive
- Manager has `widget.qc.view` and it is delegable.
- User is a direct subordinate in Bangalore.
- Temporary allow has reason and expiry.
- Result: **ALLOW until expiry**, but the widget appears only if added to the user's effective layout.

### Manager tries to publish organisation dashboard
- Manager's dashboard rights exclude organisation baseline.
- Result: **DENY**, even if the button is manipulated in the browser.
