# Tan90 Origin — Source to Stock

Space 04 is the procurement, supplier collaboration, receiving, incoming-quality and raw-material inventory workspace of the Tan90 Manufacturing ERP architecture.

## Run

1. Extract the ZIP.
2. Open `index.html` for a direct offline demo.
3. For service-worker/PWA behavior, run `RUN-WINDOWS.bat` or `RUN-MAC-LINUX.sh`, then open the local URL shown in the terminal.

All demo identities use the displayed password `demo123`; the prototype uses persona cards rather than a real authentication server.

## Main flow

Material requirement → Purchase requisition → Approval → RFQ → Quote comparison → Purchase order → Vendor ASN → Dock booking → Gate/weighment → Unloading → Incoming QC → GRN → Putaway → Available raw-material stock → Supplier claim/performance.

## Working screens

- Source-to-Stock Command Centre
- Material Requirements
- Purchase Requisitions
- RFQ & Quote Comparison
- Purchase Orders
- Vendor ASN & Dock Scheduling
- Gate & Unloading
- Incoming Quality
- GRN & Receipt Posting
- Putaway & Bin Allocation
- Raw Material Inventory & Immutable Ledger
- Suppliers, Scorecards & Claims
- Access Control & Access Simulator
- Cross-space Connectivity

## Demo hierarchy

- Level 1: Super Administrator
- Level 2: Head of Supply Chain
- Level 3: Procurement, Store/Inbound and Incoming Quality Managers
- Level 4: Buyer, Gate, Store, QC and Vendor Portal users

## Prototype boundary

This package is a frontend MVP. It persists demo changes in browser `localStorage`. Real authentication, database transactions, approval locks, inventory posting, server-side authorization, queues, integrations and digital signatures must be implemented in the Tan90 backend.
