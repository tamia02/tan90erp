# Space 04 Architecture — Tan90 Origin

## Purpose

Origin is the authoritative transaction space between approved material demand and trusted raw-material availability. It prevents direct, disconnected purchasing by preserving the chain from demand signal to supplier commitment, physical receipt, quality disposition, inventory recognition and exact bin placement.

## Bounded ownership

### Origin consumes

- **Blueprint:** released materials, UOMs, vendors, storage classes and incoming-quality specifications.
- **Forge:** net requirements, work-order demand, reservations and required dates.
- **Nexus:** identities, reporting hierarchy, role permissions, delegation ceilings and plant/team scope.

### Origin owns

- Material requirement procurement handoff
- Purchase requisition and approval state
- RFQ, quote response and commercial evaluation
- Purchase order and amendment versions
- ASN and dock appointment
- Gate entry, vehicle, seal, document and weighment evidence
- Unloading receipt and discrepancy
- Incoming quality inspection and disposition
- GRN posting reference
- Putaway task and receipt-side stock movement
- Supplier claim and performance evidence

### Origin publishes

- **Pulse:** tasks, approvals, SLA risks and receiving exceptions.
- **Forge:** released lots, available quantities, blocked stock and shortages.
- **Lens:** PO–GRN references, landed-value inputs, claims and audit events.
- **Flow:** inter-warehouse receipt availability where applicable.

## Logical layers

1. **Experience layer:** responsive SPA, hierarchy lens, process animation, work queues and builders.
2. **Application layer:** PR approval, sourcing, receiving, quality, GRN and putaway use cases.
3. **Domain layer:** requisition, RFQ, quote, PO, ASN, receipt, inspection, GRN, pallet, bin, movement and claim aggregates.
4. **Policy layer:** action permission, delegation ceiling, plant/warehouse/record scope and approval thresholds.
5. **Infrastructure layer:** Laravel persistence, queues, document storage, notifications, barcode/scanner adapters and integration events.

## Transaction integrity rules

- A PR must retain demand source, quantity, need date, plant, requester and business justification.
- RFQ creation requires an approved PR or authorised contract demand.
- Quote award is a controlled decision; evaluation score does not silently award a supplier.
- PO release freezes an auditable version; amendments create new versions.
- ASN quantity cannot exceed PO open quantity without an approved exception.
- Gate and unloading evidence remains linked to ASN, vehicle and supplier.
- QC disposition is quantity-balanced: accepted + rejected + hold = received quantity.
- GRN posting requires valid PO/ASN/receipt/QC references and creates an append-only inventory movement.
- Putaway validates warehouse, bin capacity, temperature, quality status and material rules.
- Inventory adjustment never overwrites history; it creates an approval-controlled movement.

## Suggested Laravel modular structure

```text
app/Domain/Origin/
  Requirements/
  Requisitions/
  Sourcing/
  PurchaseOrders/
  VendorCollaboration/
  Receiving/
  IncomingQuality/
  GoodsReceipts/
  Putaway/
  InventoryLedger/
  SupplierClaims/
  Access/
```

Use domain events such as `PurchaseOrderReleased`, `AsnArrived`, `IncomingLotReleased`, `GoodsReceiptPosted`, `PutawayCompleted` and `SupplierClaimApproved` to connect spaces without sharing mutable internals.
