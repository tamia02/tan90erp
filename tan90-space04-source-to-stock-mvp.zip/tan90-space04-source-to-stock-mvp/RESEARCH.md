# Requirement Basis

This MVP is based on the supplied Tan90 manufacturing requirement in which purchasing, inward/GRN, incoming QC, inventory, production supply, warehouse visibility and dispatch reporting form one end-to-end operational chain.

The Space 04 boundary intentionally combines the closely related procurement and inbound capabilities instead of presenting them as disconnected menus. It covers the raw-material side of the chain:

- requirement and procurement planning handoff;
- PR, sourcing, quote comparison and PO;
- supplier ASN and dock collaboration;
- gate, unloading and discrepancy evidence;
- incoming quality disposition;
- GRN, putaway and immutable stock movement;
- supplier performance, claim and return linkage.

The prototype makes three architecture choices explicit:

1. **Demand-backed procurement:** buying originates from governed demand or approved exceptions.
2. **Quantity and evidence continuity:** every status change preserves source documents, lots, quantities and actor evidence.
3. **Separate transaction ownership with event connectivity:** Origin owns source-to-stock transactions while Blueprint, Forge, Nexus, Pulse and Lens exchange released business objects/events.

No claim is made that the uploaded Tan90 backend already contains every flow represented here; this package is a client-facing frontend MVP and implementation blueprint.
