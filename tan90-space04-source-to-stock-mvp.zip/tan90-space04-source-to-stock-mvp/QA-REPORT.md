# QA Report

## Static checks

- `app.js` passed `node --check` after final changes.
- HTML, CSS, JavaScript, manifest, service worker, launch scripts and SVG logo are present.
- Modal controls are delegated through `overlayRoot`, so create/save/close actions work outside the main application root.
- New GRN receipt is placed in inbound staging rather than incorrectly appearing as available in a quality-hold bin.

## Browser smoke coverage

Validated using Chromium against an inline offline build:

- 14 application routes render under the Super Administrator lens.
- Hierarchy login screen renders Level 1–4 personas.
- Desktop and mobile navigation render.
- PR creation opens a modal, saves a draft, closes the modal and routes to Purchase Requisitions.
- Direct-access grant and effective-access simulator render.
- Inventory-adjustment request modal operates.
- Putaway screen exposes draggable pallets and policy-aware bin drop targets.
- Mobile Store Executive view renders Gate & Unloading.
- Preview screenshots were captured for command centre, quote comparison, ASN/dock, incoming quality, putaway, access, connectivity and mobile inbound.

## Not production tested

The prototype does not contain a real database, concurrent transaction locking, server-side policy enforcement, external supplier portal integration, scanner hardware, digital signatures, accounting posting or load/performance tests. Those belong to backend implementation and UAT.
