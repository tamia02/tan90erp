# Functional Flows

## 1. Requirement to purchase requisition

1. Forge publishes production/material demand.
2. Origin nets gross demand against available stock, reservations, safety stock and firm receipts.
3. Buyer reviews the shortage and creates a PR.
4. System records material, quantity, UOM, plant, need date, priority, demand source and reason.
5. Duplicate/open-demand checks run before submission.
6. Approval routes by value, plant and material group.

## 2. RFQ and quote award

1. Approved PR is converted to an RFQ.
2. Eligible approved suppliers receive the inquiry.
3. Quotes capture unit price, freight, taxes, lead time, validity, payment terms, quality and OTIF context.
4. Comparison calculates an explainable commercial/operational score.
5. Authorised manager selects the supplier and records the award.
6. Award creates a PO draft; no automatic silent award occurs.

## 3. Purchase order lifecycle

Draft → Review → Released → Partially received → Fully received/closed, with versioned amendments. Release validates supplier status, budget/approval, quantity, price, delivery, warehouse, tax and terms.

## 4. Vendor ASN and dock scheduling

1. Vendor creates ASN against PO open lines.
2. ASN includes vehicle, driver, packages, quantity, vendor lot, certificates and ETA.
3. Warehouse confirms dock/time slot based on capacity.
4. Document completeness and quantity tolerance are checked.
5. Arrival creates a gate task.

## 5. Gate, weighment and unloading

1. Security scans ASN and verifies vehicle/driver/seal.
2. Gross/tare weights and document evidence are captured.
3. Vehicle is admitted to the assigned dock.
4. Store records package/quantity/condition during unloading.
5. Damage, short/excess quantity and seal mismatch create linked discrepancies.
6. Completion creates incoming-QC work.

## 6. Incoming quality

1. Released material specification selects sampling plan and tests.
2. QC records method, result, pass/fail and evidence.
3. Manager disposes quantities as accepted, rejected and hold.
4. Quantity balance is validated.
5. Accepted quantity updates the GRN draft; rejected quantity may start claim/return.

## 7. GRN and stock recognition

1. Draft links PO, ASN, receipt, QC, vendor lot, invoice and warehouse.
2. Posting checks open PO quantity, QC release, duplicate receipt/invoice and batch policy.
3. Posted GRN creates an immutable receipt movement and inbound staging pallet.
4. Finance/Lens receives matching references; inventory is not yet production-available until required putaway/status rules pass.

## 8. Putaway builder

1. Pallets appear in inbound staging or quality hold.
2. User drags a pallet to an eligible bin.
3. Policy validates capacity, storage temperature, lot status, warehouse scope and quality hold.
4. Successful move updates pallet location and writes audit evidence.
5. Confirmed available stock is published to Forge.

## 9. Supplier claim

Receipt/QC discrepancy → Claim draft → Manager approval → Return/debit-note handoff → Supplier response → Recovery/closure. Claim remains traceable to PO, receipt, lot, quantity, evidence and value.

## 10. Access resolution

Active identity → explicit direct deny → role permission → direct allow within ceiling → plant/warehouse/record scope → approval/value limit → final allow or default deny. Every production API must repeat this decision server-side.
