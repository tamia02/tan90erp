# Role and Permission Matrix

## Hierarchy

| Level | Role group | Primary authority |
|---|---|---|
| 1 | Super Administrator | All entities, plants, suppliers, transactions and policy configuration |
| 2 | Head of Supply Chain | Supply-chain portfolio, cross-plant oversight and manager delegation |
| 3 | Procurement Manager | PR approval, RFQ, quote award, PO release and supplier commercial control |
| 3 | Store & Inbound Manager | ASN, gate, unloading, GRN, putaway, stock and discrepancy control |
| 3 | Incoming Quality Manager | Sampling, inspection, hold, release/reject and supplier-quality claims |
| 4 | Buyer Executive | Requirements, PR/RFQ/PO preparation and supplier follow-up |
| 4 | Gate Executive | Vehicle, documents, seal, gate entry and weighment |
| 4 | Store Executive | Unloading, discrepancy, GRN draft and putaway execution |
| 4 | Incoming QC Executive | Test execution and evidence; release depends on delegated authority |
| 4 | Vendor Portal User | Own PO/ASN visibility and permitted ASN collaboration only |

## Permission catalogue

- `origin.dashboard.view`
- `origin.requirement.view`
- `origin.pr.create`, `origin.pr.approve`
- `origin.rfq.manage`, `origin.quote.award`
- `origin.po.create`, `origin.po.release`
- `origin.asn.manage`
- `origin.gate.register`, `origin.unloading.inspect`
- `origin.qc.inspect`, `origin.qc.release`
- `origin.grn.create`, `origin.grn.post`
- `origin.putaway.execute`
- `origin.inventory.view`, `origin.inventory.adjust`
- `origin.claim.create`, `origin.claim.approve`
- `origin.vendor.performance`
- `origin.access.grant`, `origin.audit.view`

## Particular-user grants

A manager may grant a temporary user-specific allow/deny only when:

1. The target reports below the manager.
2. The permission is held by the manager.
3. It is marked delegable.
4. The requested plant/warehouse/record scope is inside the manager's scope.
5. A business reason and expiry are supplied for temporary elevation.
6. The grant does not bypass a parent lock or approval/value threshold.

The frontend includes a direct-grant form and effective-access simulator. Production enforcement must live in backend policies/middleware, not merely in hidden buttons.
