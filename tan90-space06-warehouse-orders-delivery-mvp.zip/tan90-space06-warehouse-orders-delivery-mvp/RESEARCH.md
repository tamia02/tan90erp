# Tan90 Flow — Requirement and Design Basis

## Source-derived requirement

The supplied Tan90 requirement describes an end-to-end manufacturing ERP where finished goods move from production and final quality into warehouse stock, then through dispatch, POD upload and delivery closure. It also identifies warehouse/stock transfer, logistics/dispatch closure, dashboard and audit as explicit modules.

Space 06 bundles those requirements into a single fulfilment operating space rather than scattering them across unrelated menus.

## Design conclusions

1. Finished inventory must remain traceable to the exact production batch and released definitions.
2. Quality status, temperature profile and remaining shelf life must be hard eligibility gates for ATP and allocation.
3. Available stock, allocation, picking and physical movement must not be represented by one editable quantity field.
4. Allocation should reserve exact lot and location, defaulting to FEFO.
5. Warehouse execution benefits from drag-and-drop planning but every drop must still trigger server validation.
6. Barcode/QR scanning should be idempotent and verify bin, batch and remaining quantity.
7. Cartons/handling units require independent identities so delivery and return exposure can be traced below shipment level.
8. Cold-chain delivery requires both time-temperature evidence and custody evidence.
9. POD is a business state transition, not only a file upload.
10. Returns must enter blocked stock and require inspection/disposition before restock.
11. Hierarchical role inheritance needs contextual warehouse, customer, route, shift and record scopes.
12. Current Tan90 pages should remain untouched; the advanced Flow capability should be additive and feature-flagged.

## MVP versus production

The prototype demonstrates workflows, interactions, information architecture and validation concepts. Production implementation additionally requires:

- Laravel database transactions;
- server-side policies;
- real identity and SSO;
- barcode/QR devices;
- printer and label templates;
- temperature logger and GPS integrations;
- carrier APIs;
- signed POD storage;
- immutable stock ledger;
- job queues and notifications;
- observability, backup and disaster recovery;
- automated unit, policy, integration and UAT tests.
