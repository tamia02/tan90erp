@echo off
start "Tan90 Flow" http://localhost:8080
python -m http.server 8080
