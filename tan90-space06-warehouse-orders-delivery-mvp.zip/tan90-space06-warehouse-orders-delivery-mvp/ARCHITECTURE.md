# Tan90 Flow — MVP Architecture

## 1. Space responsibility

Flow is the authoritative operational owner for:

- finished-goods receipt and physical location;
- lot, pallet, bin and sellable status;
- customer-order promise and fulfilment state;
- ATP and inventory reservation;
- warehouse waves, picks, cartons and handling units;
- dispatch, vehicle, dock, seal and custody;
- in-transit temperature and delivery evidence;
- POD, delivery closure, returns and claims.

It does not own product definitions, raw-material stock, production execution, users or cross-space financial analytics. Those remain governed by Blueprint, Origin, Forge, Nexus and Lens.

## 2. Bundled module architecture

```text
SPACE 06 — FLOW
│
├── Fulfilment Control
│   ├── Command Centre
│   ├── SLA / exception radar
│   └── Personal work and approvals
│
├── Finished-Goods Warehouse
│   ├── FG receipt from Forge
│   ├── Quality-release validation
│   ├── Putaway and slot compatibility
│   ├── Lot / pallet / bin inventory
│   ├── Append-only stock ledger
│   └── Inter-warehouse transfer
│
├── Customer Promise
│   ├── Customer order
│   ├── Commercial and fulfilment holds
│   ├── Available-to-promise
│   ├── Shelf-life and temperature eligibility
│   └── FEFO allocation
│
├── Warehouse Execution
│   ├── Wave Builder
│   ├── Pick task and route sequence
│   ├── Barcode / QR scan confirmation
│   ├── Short-pick exception
│   ├── Cartonisation
│   ├── Package label and seal
│   └── Pack reconciliation
│
├── Transport & Delivery
│   ├── Shipment creation
│   ├── Dock and loading plan
│   ├── Transporter / vehicle / driver
│   ├── Temperature logger
│   ├── Dispatch release
│   ├── GPS and temperature evidence
│   ├── POD
│   └── Delivery closure
│
├── Reverse Logistics
│   ├── RMA
│   ├── Return receipt
│   ├── Inspection
│   ├── Restock / rework / scrap / reject
│   └── Customer or transporter claim
│
└── Governance
    ├── Hierarchical roles
    ├── Direct user grants
    ├── Access simulator
    ├── Audit events
    └── Space contracts
```

## 3. Core business objects

Recommended aggregates:

- `FinishedGoodsReceipt`
- `InventoryLot`
- `InventoryMovement`
- `StockTransfer`
- `CustomerOrder`
- `OrderPromise`
- `InventoryAllocation`
- `PickingWave`
- `PickTask`
- `HandlingUnit`
- `Shipment`
- `VehicleAssignment`
- `TemperatureJourney`
- `Delivery`
- `ProofOfDelivery`
- `ReturnAuthorisation`
- `ReturnInspection`
- `Claim`

Every state-changing aggregate should have its own version and immutable event/audit references.

## 4. Inventory truth

Do not store inventory only as a mutable quantity. Production implementation should post immutable movements and build balances by lot and location.

```text
FG_RECEIPT
PUTAWAY
ALLOCATION
DEALLOCATION
PICK
PACK
TRANSFER_DISPATCH
TRANSFER_RECEIPT
DISPATCH
CUSTOMER_RETURN
RESTOCK
SCRAP
ADJUSTMENT
```

Each movement must carry:

- organisation, plant and warehouse;
- zone and bin;
- SKU and released revision;
- finished batch / lot;
- handling unit when applicable;
- quantity and UOM;
- quality and availability status;
- business reference;
- actor and timestamp;
- reason and approval reference.

## 5. Order-to-delivery state model

```text
DRAFT
→ VALIDATED
→ RELEASED
→ ATP_CONFIRMED / ATP_PARTIAL
→ ALLOCATED
→ WAVED
→ PICKING
→ PICKED
→ PACKING
→ PACKED
→ DISPATCH_PLANNED
→ LOADING
→ IN_TRANSIT
→ POD_RECEIVED
→ DELIVERED / CLOSED
```

Cancellation, hold, short-pick, temperature-hold and return are explicit side paths, never silent quantity edits.

## 6. ATP and allocation

ATP uses only stock that is:

- quality released;
- available rather than allocated or picked;
- in an eligible warehouse/network node;
- temperature compatible;
- above customer minimum remaining shelf-life;
- not expired, blocked, recalled or under investigation.

Allocation should preserve a reservation by exact lot and location. FEFO is the default strategy, while manual override requires permission and reason.

## 7. Hierarchy and authorisation

```text
Level 1 — Super Administrator
    ↓
Level 2 — Head of Warehouse & Fulfilment
    ↓
Level 3 — Warehouse / Logistics / Customer Fulfilment Manager
    ↓
Level 4 — FG Store / Picker-Packer / Dispatch / Transport / Closure Executive
```

Effective access resolution:

```text
identity active
→ parent delegation ceiling
→ direct deny
→ explicit role deny
→ direct allow
→ inherited/explicit role allow
→ warehouse / zone / lane / customer / shift / assigned-record scope
→ final allow or default deny
```

A frontend control is never the security boundary. Laravel policies/middleware must validate every command and query.

## 8. Cross-space contracts

### Consumed

- `finished_batch.released` from Forge
- SKU, shelf-life, pack, label and temperature policy from Blueprint
- user, role, hierarchy and scopes from Nexus
- task, exception and SLA context from Pulse

### Published

- `fg_receipt.posted`
- `inventory.moved`
- `order.atp_calculated`
- `order.allocated`
- `wave.published`
- `pick.confirmed`
- `pick.short_recorded`
- `handling_unit.sealed`
- `dispatch.released`
- `temperature.excursion_detected`
- `pod.received`
- `delivery.closed`
- `return.dispositioned`

Lens consumes these contracts for OTIF, revenue fulfilment, freight, claims, return cost and end-to-end batch genealogy.

## 9. Suggested Laravel implementation

Keep the current Tan90 pages and functionality intact. Add Flow as bounded additive modules with:

- application commands and query services;
- domain policies and state-transition validators;
- transactional outbox for cross-space events;
- idempotency keys for scanners, POD and carrier callbacks;
- database constraints preventing negative stock;
- queues for notifications, label generation and carrier sync;
- append-only audit and inventory movement tables;
- feature flags for legacy / hybrid / advanced users.
