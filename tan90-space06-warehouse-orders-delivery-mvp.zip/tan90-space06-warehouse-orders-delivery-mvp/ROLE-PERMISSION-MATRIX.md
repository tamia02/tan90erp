# Tan90 Flow — Role and Permission Matrix

## Hierarchy

| Level | Role group | Primary authority |
|---|---|---|
| L1 | Super Administrator | Organisation, all warehouses, all permissions and delegation |
| L2 | Head of Warehouse & Fulfilment | Network inventory, orders, logistics and delivery governance |
| L3 | Warehouse Manager | FG receipt, stock, transfer, wave, pick and packing |
| L3 | Logistics Manager | Dispatch, vehicle, cold-chain and delivery closure |
| L3 | Customer Fulfilment Manager | Orders, ATP, allocation, returns and claims |
| L4 | FG Store Executive | Receipt, putaway, inventory and transfer execution |
| L4 | Picker & Packer | Assigned waves, scan picks, packing and labels |
| L4 | Dispatch Executive | Dock, loading, vehicle readiness and custody |
| L4 | Transport Coordinator | Tracking, temperature and POD coordination |
| L4 | Delivery Closure Executive | Assigned POD, return and claim activity |

## Permission catalogue

### Finished-goods warehouse

- `flow.fg.receive`
- `flow.fg.putaway`
- `flow.inventory.view`
- `flow.inventory.adjust`
- `flow.transfer.create`
- `flow.transfer.approve`
- `flow.transfer.dispatch`
- `flow.transfer.receive`

### Customer promise

- `flow.order.view`
- `flow.order.create`
- `flow.order.release`
- `flow.atp.run`
- `flow.allocation.manage`

### Warehouse execution

- `flow.wave.create`
- `flow.wave.publish`
- `flow.pick.execute`
- `flow.pick.short`
- `flow.pack.execute`
- `flow.label.generate`

### Dispatch and transport

- `flow.dispatch.plan`
- `flow.dispatch.release`
- `flow.vehicle.assign`
- `flow.loading.confirm`
- `flow.temperature.monitor`
- `flow.temperature.disposition`

### Delivery and reverse logistics

- `flow.pod.upload`
- `flow.delivery.close`
- `flow.return.create`
- `flow.return.inspect`
- `flow.return.disposition`
- `flow.claim.manage`

### Governance

- `flow.batch.trace`
- `flow.access.grant`
- `flow.audit.view`
- `flow.report.export`

## Data scopes

Permissions must be combined with one or more data scopes:

- organisation;
- plant;
- FG warehouse;
- zone and bin;
- delivery region or route/lane;
- customer segment or named customer;
- shift;
- team;
- assigned dispatch/order/return;
- created-by-me;
- managed-subordinates.

## Individual direct grant

A manager may give a particular subordinate an extra Allow or Deny without editing the shared role when:

1. the manager holds the permission;
2. the permission is marked delegable;
3. the subordinate is inside the manager’s hierarchy;
4. requested scope does not exceed the manager’s scope;
5. the parent policy does not lock or deny it;
6. a reason and expiry are recorded when temporary.

Direct deny takes precedence over direct allow and role allow. Expired grants are ignored automatically.
