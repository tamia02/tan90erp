# Tan90 Flow — Space 06

## Warehouse, Orders & Delivery interactive MVP

Tan90 Flow bundles every finished-goods and customer-fulfilment capability into one connected operating space:

**Forge FG release → FG receipt → putaway → inventory → customer order → ATP → FEFO allocation → wave → scan pick → pack → dispatch → temperature monitoring → POD → delivery closure → returns and claims**

## Start

- Open `index.html` directly, or
- Windows: run `RUN-WINDOWS.bat`
- Mac/Linux: run `./RUN-MAC-LINUX.sh`, then open `http://localhost:8080`

All demo identities use the displayed demo password `demo123`; the prototype uses persona cards rather than a real credential server.

## Included modules

1. Fulfilment Command Centre
2. Finished-Goods Receipt from Forge
3. Finished-Goods Inventory and Append-Only Ledger
4. Inter-Warehouse Transfers
5. Customer Orders
6. ATP and FEFO Batch Allocation
7. Drag-and-Drop Wave Builder
8. Mobile Picking and Scan Confirmation
9. Packing, Cartonisation and Labelling
10. Drag-and-Drop Dispatch Dock Planner
11. Cold-Chain Temperature Control
12. Delivery and POD Closure
13. Returns, RMA and Claims
14. Four-Level Hierarchy and Advanced Access Control
15. Cross-Space Connectivity

## Functional prototype behaviour

The package uses browser `localStorage`, so order, receipt, allocation, wave, pick, carton, shipment, POD, return and direct-permission changes remain available after refresh in the same browser.

The frontend contains operational validations such as:

- final-QC release required before sellable FG receipt;
- temperature-compatible putaway zones;
- quality-hold stock excluded from ATP;
- FEFO batch allocation;
- wave-capacity checks;
- bin and batch scan matching;
- order/carton compatibility;
- cold shipment blocked from ambient-only docks;
- vehicle, dock, seal and logger readiness before release;
- POD required before delivery closure;
- return stock blocked until inspection and disposition;
- manager direct grants limited by delegable ceiling.

## Production implementation boundary

This is a client-ready interactive **frontend MVP**. It does not claim real Laravel persistence, authentication, stock posting, barcode hardware, GPS, temperature logger, carrier API, document upload, accounting integration or server-side authorisation. The included architecture documents define how those components should be implemented without replacing current Tan90 pages and workflows.
