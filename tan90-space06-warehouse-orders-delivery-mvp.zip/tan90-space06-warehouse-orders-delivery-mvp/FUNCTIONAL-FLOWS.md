# Tan90 Flow — Functional Flows

## 1. Finished batch to available inventory

```text
Forge final QC release
→ Flow receives batch-release event
→ FG Store verifies batch and quantity
→ FG receipt posted
→ Lot and pallet identities created
→ Stock enters staging
→ Temperature-compatible putaway task
→ Bin confirmation
→ Available inventory updated
→ Ledger and trace events published
```

A quality-hold batch is routed only to the controlled hold zone and is excluded from ATP.

## 2. Customer order promise

```text
Create/import order
→ Validate customer, SKU, quantity, destination and temperature
→ Check commercial hold
→ Run ATP across eligible network stock
→ Confirm / partially confirm / decline promise
→ Release order
→ Allocate exact FEFO batches
→ Create warehouse execution demand
```

## 3. FEFO allocation

```text
Order requirement
→ Eligible SKU lots
→ Remove hold, expired and incompatible lots
→ Enforce minimum shelf life
→ Sort by earliest expiry
→ Reserve quantity lot-by-lot
→ Update order coverage
→ Publish shortage if remaining demand > 0
```

## 4. Warehouse wave and picking

```text
Allocated order lines
→ Pick tasks
→ Group by warehouse, cut-off, temperature and route
→ Drag into draft wave
→ Validate capacity and compatibility
→ Publish wave
→ Picker receives sequence
→ Scan bin
→ Scan batch
→ Enter/scan quantity
→ Confirm pick or short-pick exception
→ Move stock to packing custody
```

## 5. Packing

```text
Picked quantity
→ Select approved packaging configuration
→ Create handling unit/carton
→ Pack quantity
→ Capture weight
→ Generate label
→ Apply temperature handling mark
→ Seal handling unit
→ Reconcile picked versus packed quantity
→ Release to dispatch staging
```

## 6. Dispatch

```text
Packed orders
→ Create shipment
→ Consolidate compatible route and temperature
→ Assign dock
→ Assign transporter, vehicle and driver
→ Verify vehicle condition
→ Attach temperature logger
→ Load in sequence
→ Confirm package count
→ Apply seal
→ Release shipment
→ Start GPS and temperature journey
```

## 7. Temperature excursion

```text
Logger reading outside profile
→ Excursion event
→ Shipment/lot/customer exposure identified
→ Quality hold
→ Duration and peak evaluated
→ Product-core evidence reviewed
→ Authorised disposition
   ├── release shipment
   ├── continue with customer deviation
   └── return to warehouse
→ Evidence retained in genealogy
```

## 8. POD and delivery closure

```text
Vehicle arrives
→ Receiver identity
→ Package and seal verification
→ Quantity accepted / exception recorded
→ POD image/signature and timestamp
→ Temperature journey attached
→ Customer notification
→ Delivery closure approval
→ OTIF and fulfilment facts published to Lens
```

## 9. Return and claim

```text
Customer issue
→ RMA request
→ Original order and batch validation
→ Reverse pickup
→ Return receipt into blocked stock
→ Quantity and condition inspection
→ Temperature and trace review
→ Disposition
   ├── restock after QC
   ├── rework through Forge
   ├── scrap
   └── reject RMA / return to customer
→ Customer or transporter claim
→ Financial recovery and audit
```
