# Space 02 Architecture

## Purpose

Space 02 is the administration and governance foundation shared by every Tan90 operating space. It owns identities, reporting structure, roles, permission ceilings, user-specific exceptions, saved views and dashboard assignments. It does not replace existing Tan90 operational pages.

## Bounded hierarchy

```text
Tan90 Organisation
└── Level 1: Super Administrator
    ├── Level 2: Head of Manufacturing
    │   └── Level 3: Production Manager
    │       └── Level 4: Production Executive
    ├── Level 2: Head of Quality
    │   └── Level 3: Quality Manager
    │       └── Level 4: QC Executive
    ├── Level 2: Head of Store & Procurement
    │   └── Level 3: Store Manager
    │       └── Level 4: GRN + QC Executive
    └── Level 2: Head of Warehouse & Logistics
        └── Level 3: Logistics Manager
            └── Level 4: Logistics Executive
```

## Organisation model

```text
Legal Entity
  → Vertical / Business Unit
    → Plant / Location / Operating Site
      → Team
        → Shift
          → Position / User
```

A user also has a reporting manager, one or more roles, access mode, status and optional direct decisions.

## Permission key model

```text
space.resource.action
```

Examples:

```text
org.teams.move
people.subordinates.transfer
access.roles.publish
access.permissions.delegate
access.direct_grants.grant
experience.saved_views.assign
experience.dashboard.publish
experience.personal.resize
ops.production.release
ops.source_stock.post
gov.simulator.run
```

## Role decision states

- `inherit`: recursively resolve the parent role.
- `allow`: grant the action within the role data scope.
- `deny`: block the action even if another normal role allows it.
- `delegable`: the holder may pass the permission to an allowed child role or particular subordinate.
- `locked`: the child cannot alter the decision because it is outside the parent ceiling.

## Effective access order

```text
1. Identity must be active
2. Active direct user deny
3. Explicit role deny
4. Active direct user allow
5. Explicit or inherited role allow
6. Data-scope and hierarchy match
7. Final allow; otherwise default deny
```

Every production API must repeat this decision server-side. Hiding a menu, field or dashboard widget is not authorization.

## Particular-user access

A manager can issue a direct allow or deny to one subordinate when:

- the target is inside the manager reporting hierarchy;
- the permission is effective for the manager;
- the manager permission is delegable;
- the requested data scope is not broader than the manager scope;
- a business reason is recorded;
- any temporary expiry is enforced.

## Dashboard inheritance

```text
Organisation baseline
  → Vertical template
    → Role template
      → Team template
        → Individual assignment
          → Personal customisation
```

Widget properties can be locked independently:

- removal / mandatory status;
- position;
- size;
- configuration.

A widget is available only when its underlying permission is effective.

## Backward-compatible implementation strategy

Production implementation should add an advanced access mode alongside current Tan90 access behavior:

- `legacy`: current navigation, pages and authorization remain unchanged;
- `hybrid`: current roles plus selected advanced policies;
- `advanced`: hierarchy, permission engine, views and dashboards resolved by Space 02.

No existing route, page, form, workflow or business operation needs to be renamed or removed.
