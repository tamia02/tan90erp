# Tan90 Nexus — Space 02 MVP

## People, Access & Organisation

This is a complete interactive front-end MVP for Tan90's organisation, user, hierarchy, role, permission, delegation, saved-view and dashboard administration workspace.

## Run

- Extract the ZIP.
- Open `index.html` directly in a modern browser, or run `RUN-WINDOWS.bat` / `RUN-MAC-LINUX.sh` for the local PWA server.
- Choose a hierarchy-wise demo identity. Password shown in the UI is `demo123`; the offline prototype uses persona buttons and does not contact a server.

## Four-level hierarchy

1. Super Administrator — organisation policy and complete control.
2. Head of Vertical — vertical, plant, manager and bounded child-role control.
3. Manager — team, executive role, direct-user access and individual dashboard control.
4. Executive — own identity, inherited access and personal drag-and-drop dashboard.

## Included working areas

- People Command Center
- Organisation Designer
- Users & Reporting Hierarchy
- Role & Permission Studio
- Direct User Access
- Saved View Builder
- Dashboard Builder
- Categorised Demo Identities
- Audit & Access Simulator

## Important behavior

- Role decisions support inherit, allow and deny.
- Permissions are resolved recursively through the parent role.
- Parent ceilings lock permissions that cannot be delegated.
- Managers can add an extra allow or deny for one particular subordinate without changing the shared role.
- Direct decisions support reason, scope and expiry.
- Dashboard templates support organisation, vertical, role, team and individual levels.
- Executives can customise only their personal dashboard and only with widgets backed by an underlying permission.
- Team movement and configuration changes create audit evidence.
- Browser localStorage persists demo changes; Reset Demo restores seed data.

## Front-end MVP boundary

The package demonstrates workflows and stores data in browser localStorage. Production integration still requires Laravel migrations, policies/middleware, server-side scope enforcement, authentication, APIs, audit persistence and real operational data adapters.
