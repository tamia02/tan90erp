# Functional Flows

## 1. Create organisation structure

```text
Select node type
→ Choose valid parent
→ Add code, owner, status and reason
→ Validate hierarchy scope
→ Save node
→ Write audit event
```

The hierarchy designer supports vertical, plant/location and team nodes. An authorised user can drag a team to another plant; the prototype records the previous and new plant in audit history.

## 2. Create and place a user

```text
Create identity
→ Set hierarchy level
→ Select bounded role
→ Select vertical / plant / team
→ Assign reporting manager
→ Choose legacy, hybrid or advanced mode
→ Activate or invite
→ Audit the change
```

Heads see users in their vertical. Managers see themselves and their direct subordinates. Executives see their own identity profile.

## 3. Create a child role

```text
Select parent role
→ Create child at the next hierarchy level
→ Inherit parent policy
→ Configure allowed decisions inside parent ceiling
→ Mark selected allows as delegable
→ Set data scope
→ Preview assigned users and dashboard
→ Publish a version
```

Permissions outside the parent ceiling are locked.

## 4. Grant a particular user extra access

```text
Manager selects subordinate
→ Select direct allow or direct deny
→ Select delegable permission
→ Select bounded scope
→ Enter reason
→ Optional expiry
→ Validate hierarchy and ceiling
→ Save direct decision
→ Audit and simulate
```

This avoids creating a new shared role for one employee exception.

## 5. Build a saved view

```text
Choose resource
→ Add/remove columns
→ Drag columns to reorder
→ Add filters and sorting
→ Set organisation/vertical/role/team/individual scope
→ Preview rows
→ Publish and assign
```

Saved views control presentation only; field and row authorization still comes from the access engine.

## 6. Build a dashboard

```text
Select template level and target
→ Drag authorised widgets from library
→ Reorder widgets
→ Set small/medium/large size
→ Lock removal, position or configuration
→ Preview responsive layout
→ Publish version
```

A manager can open the dashboard builder directly for a particular subordinate. An individual template is created from the personal baseline when required.

## 7. Executive personal customisation

```text
Receive inherited individual dashboard
→ See only authorised personal widgets
→ Reorder unlocked widgets
→ Resize unlocked widgets
→ Remove non-mandatory widgets
→ Save personal layout
```

Executives cannot publish organisation, vertical, role or team templates.

## 8. Simulate an access decision

```text
Select identity
→ Select permission
→ Select requested context
→ Evaluate status
→ Evaluate direct deny/allow
→ Evaluate recursive role inheritance
→ Evaluate scope
→ Explain final allow or deny
```
