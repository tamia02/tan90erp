@echo off
cd /d "%~dp0"
start "Tan90 Space 02" http://localhost:8082
python -m http.server 8082
