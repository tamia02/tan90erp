# Role and Permission Matrix

| Capability | Super Admin | Head of Vertical | Manager | Executive |
|---|---:|---:|---:|---:|
| Organisation-wide structure | Full | Own vertical | View assigned structure | No |
| Create vertical | Yes | No | No | No |
| Create/edit plant | Yes | Own vertical if delegated | No | No |
| Create/move team | Yes | Own vertical | Own plant if delegated | No |
| Manage users | All | Own vertical | Direct subordinates | Own profile only |
| Create roles | L2–L4 | L3–L4 | L4 | No |
| Set permission ceiling | Full | Within parent ceiling | Within parent ceiling | No |
| Direct user allow/deny | Any non-root user | Own vertical | Direct subordinates | No |
| Temporary access expiry | Yes | Yes | Yes | No |
| Saved views | All levels | Vertical/role/team/user | Team/user | Personal only when assigned |
| Dashboard templates | Organisation downward | Vertical downward | Team and individual | Personal layout |
| Lock widget properties | Yes | Within target scope | Within target scope | No |
| Access simulator | Organisation | Own vertical | Own scope | Own decisions if granted |
| Audit visibility | Organisation | Own vertical | Own actions/team | Own activity if granted |

## Permission groups implemented in the MVP

- Organisation: company, verticals, plants, teams, shifts.
- People: users, subordinates, assignments, activity.
- Access: roles, permission matrix, direct grants, delegation, demo identities.
- Experience: saved views, dashboard templates, personal customisation.
- Operational bundles: Control Tower, Source to Stock, Plan/Make/Quality, Warehouse/Delivery, Finance/Intelligence.
- Governance: audit, simulator, policy settings and configuration snapshots.

## Data scopes

- Organisation
- Vertical
- Plant
- Warehouse
- Team
- Shift
- Managed team
- Assigned records
- Own records
