# Tan90 Forge Functional Flows

## Flow 1 — Demand to frozen production plan

1. Demand enters from sales forecast, management requirement, replenishment or manual demand.
2. Planner reviews due date, priority, plant and SKU.
3. System loads released BOM/recipe/routing/specification from Blueprint.
4. MRP nets required quantity against available, reserved and scheduled receipts from Origin.
5. Capacity engine checks approved work centres, shifts, calendars and maintenance blocks.
6. Planner creates a plan version and resolves material/capacity exceptions.
7. Authorised manager approves and freezes the plan.
8. Plan approval emits tasks/events and enables work-order creation.

Controls: no unreleased product definition; no invalid UOM conversion; plan revisions remain auditable.

## Flow 2 — Work-order release

1. Create work order from an approved plan line.
2. Snapshot released definition revisions and target quantity.
3. Validate plant, work centre, routing, quality gates and batch-number policy.
4. Check material and capacity readiness thresholds.
5. Manager releases work order.
6. System creates reservation, kitting and job-card tasks.

Controls: duplicate release blocked; release is role/scope/state controlled.

## Flow 3 — Finite capacity scheduling

1. Released work-order cards appear in the scheduler.
2. Planner drags a card to a machine/day/shift.
3. System validates SKU-routing compatibility.
4. System blocks maintenance windows and unavailable shifts.
5. System recalculates scheduled/available hours and peak utilisation.
6. Publish creates a schedule revision and informs supervisors.

The frontend MVP demonstrates compatible drag/drop and maintenance/routing blocking.

## Flow 4 — Material kitting and issue

1. Work-order requirement is exploded by released BOM and planned quantity.
2. Origin returns released lots using FEFO/FIFO and quality/temperature rules.
3. Store/supervisor stages lots against required lines.
4. User drags a lot into the issue lane in the MVP.
5. Backend validates item, lot status, expiry, available quantity, UOM and work-order state.
6. Issue posts immutable material movement and links the lot to genealogy.
7. Unused material is returned with the same trace link.

## Flow 5 — Digital job execution

1. Supervisor assigns authorised job cards by routing sequence.
2. Operator performs safety, line-clearance and material-verification checks.
3. Job starts only after predecessor and hold validation.
4. Operator records process parameters, output and evidence.
5. Out-of-range parameter creates a quality/deviation event.
6. Job may pause for planned stop, breakdown, material shortage or quality hold.
7. Completion validates quantities and mandatory evidence.
8. Shift handover carries remaining quantity and open exceptions.

## Flow 6 — Machine and OEE

1. Machine state changes among idle, setup, running, down and maintenance.
2. Downtime event captures exact start, category, severity, observation and owner.
3. Availability is derived from planned production time minus downtime.
4. Performance compares ideal cycle output with actual output.
5. Quality uses good output divided by total output.
6. OEE is availability × performance × quality.
7. Maintenance closure records root cause, action, parts and evidence.

## Flow 7 — Production entry and reconciliation

1. Operator/supervisor records good, rework and rejected output.
2. Consumption is captured by issued-lot quantity or backflush policy.
3. System checks material balance and output reconciliation.
4. Draft entries are reviewed by authorised production manager.
5. Approval posts output, consumption, WIP and variance events.
6. Work-order progress and job-card totals update from posted events.

## Flow 8 — Wastage and scrap

1. User records material/product, quantity, UOM, reason and source step.
2. System assigns normal/exception approval based on threshold and value.
3. Disposition can be rework, recover, return, destruction or approved scrap.
4. Approved scrap posts inventory/cost events and remains linked to the work order.
5. Pareto and yield views use reason-coded records.

## Flow 9 — In-process quality

1. Routing checkpoint creates IPQC inspection task.
2. QC user receives released specification and sampling plan.
3. Results are recorded with method, instrument and evidence.
4. Pass lets the job continue.
5. Fail creates a process hold and deviation/non-conformance.
6. Only authorised quality role can release hold after disposition/evidence.

## Flow 10 — Final quality and finished-batch release

1. Production reconciliation creates a finished-batch inspection lot.
2. QC records final specification results.
3. System validates accepted, rejected and rework quantities.
4. Genealogy completeness and required evidence are checked.
5. Quality Manager releases conforming quantity, creates rework, or rejects.
6. Release publishes finished-goods receipt to Flow.
7. Lens receives actual cost and trace events; Pulse receives exceptions/tasks.

## Flow 11 — Deviation, rework and CAPA

1. Deviation is opened from process, quality, machine or traceability event.
2. Immediate containment and affected batch/quantity are recorded.
3. Investigation captures root cause and evidence.
4. Disposition may include use-as-is approval, rework, reject or return.
5. CAPA actions receive owners and target dates.
6. Effectiveness check is mandatory before closure.
7. All links remain attached to batch/work-order genealogy.

## Flow 12 — Backward and forward traceability

Backward trace:

```text
Finished batch → final QC → production entries → job cards → work order
→ released recipe/BOM/routing → issued raw lots → GRN/vendor lots
```

Forward trace:

```text
Raw/vendor lot → issue/consumption → WIP/jobs → finished batches
→ FG locations → allocations/dispatches → customers/POD
```

The MVP visualises the Forge portion and the space contracts needed to complete customer exposure in Flow.
