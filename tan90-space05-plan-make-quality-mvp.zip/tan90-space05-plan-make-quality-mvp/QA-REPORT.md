# QA Report — Tan90 Forge MVP

## Build checks

- JavaScript syntax: passed with `node --check app.js`
- Core files present: `index.html`, `styles.css`, `app.js`, manifest, service worker and launchers
- Desktop and mobile screenshot rendering: passed
- Browser runtime console/page errors during route and modal smoke tests: none observed

## Route-render tests

All 15 routes rendered successfully in a headless Chromium smoke test:

- Command Centre
- Demand & Plans
- Capacity Scheduler
- Work Orders
- Material Kitting
- Job Cards
- Machines & OEE
- Production Entry
- Wastage & Scrap
- In-Process Quality
- Final Quality
- Deviation & CAPA
- Batch Genealogy
- Access Control
- Space Connectivity

## Modal smoke tests

The following actions opened working forms without runtime errors:

- Create demand
- Create work order
- Record production
- Record scrap
- Log downtime
- Create deviation
- Grant particular-user access

## Drag-and-drop tests

- Work-order schedule card successfully moved to a compatible machine/day target.
- Material lot successfully staged in the work-order issue lane.
- Scheduler includes explicit maintenance-block and routing-compatibility validations.

## Responsive checks

- 1600 × 1000 desktop screens captured for key routes.
- 390 × 844 operator view captured.
- Mobile sidebar overlay behaviour corrected so content remains usable when the sidebar is closed.

## Preview assets

- `previews/01-login.png`
- `previews/02-command-centre.png`
- `previews/03-capacity-scheduler.png`
- `previews/04-job-cards.png`
- `previews/05-machines-oee.png`
- `previews/06-final-quality.png`
- `previews/07-access-control.png`
- `previews/08-batch-genealogy.png`
- `previews/09-space-connectivity.png`
- `previews/10-mobile-operator.png`

## Known production gaps

Not implemented as production backend functionality:

- Laravel/database persistence
- real authentication and password flows
- server-side authorisation/policies
- transactional inventory ledger
- concurrency/idempotency controls
- barcode/QR/RFID or PLC integration
- background queues and event outbox
- ERP/accounting/dispatch integrations
- electronic signatures and regulated validation

These limitations are explicit so the package can be used honestly as a client-facing frontend MVP and implementation blueprint.
