# Research and Requirement Basis

## Source-derived scope

The supplied Tan90 requirement describes an end-to-end manufacturing operation covering customer/sales demand, planning, raw-material requirement, procurement, inward/GRN, QC, material stock, material issue, production, machine usage, wastage, finished stock, dispatch, POD closure and management reporting.

The expanded module inventory specifically calls out production planning, work-order management, production entry, machine usage, wastage/scrap tracking and quality control. Forge bundles those closely related capabilities into one space while preserving contracts with procurement/inventory and warehouse/dispatch.

## Design decisions derived from the process

### One work-order context

Planning, material issue, execution, machine events, quality and output all update the same work-order/batch genealogy. This avoids duplicated records and makes client demonstrations easier to understand.

### Quality embedded in production

Quality is not treated as a disconnected final screen. Forge includes pre-start clearance, in-process checkpoints, holds, final disposition, deviation and CAPA.

### Machine usage as execution evidence

Machine state, downtime, shift and operator are tied to job/output records so OEE and production reporting are explainable.

### Immutable quantity events

The production architecture should post reserve, issue, consumption, output, scrap, rework and release events rather than directly editing stock totals.

### Bundled but bounded

Forge is a single user-facing space, but internally it remains split into planning, execution, assets, quality and traceability subdomains. Other spaces remain authoritative for product definitions, identity, raw stock, finished-goods logistics and analytics.

## MVP interpretation

The current package demonstrates all major Forge workflows using representative records, browser persistence, modals and drag/drop interactions. It is intentionally a frontend MVP and architecture visualisation, not a production manufacturing system. Backend rules described in the architecture are required before operational deployment.
