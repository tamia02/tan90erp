# Tan90 Forge — Space 05: Plan, Make & Quality

Tan90 Forge is an interactive frontend MVP that bundles all manufacturing-planning, shop-floor execution, machine, wastage and quality capabilities into one connected operational space.

## Run

- Open `index.html` directly, or
- Windows: run `RUN-WINDOWS.bat`
- macOS/Linux: run `RUN-MAC-LINUX.sh`

The local launcher starts a small HTTP server so the PWA manifest and service worker can operate normally.

## Demo hierarchy

| Level | Demo personas | Purpose |
|---|---|---|
| L1 | Super Administrator | Organisation-wide authority and access governance |
| L2 | Head of Manufacturing | Manufacturing-vertical owner across plants |
| L3 | Production, Quality and Maintenance Managers | Functional, plant and team control |
| L4 | Planner, Shift Supervisor, Operator, QC Executive, Maintenance Technician | Assigned operational work |

No password is required in this frontend prototype. Select a hierarchy card on the demo-login screen.

## Included routes

1. Manufacturing Command Centre
2. Demand, MRP & Production Plans
3. Finite Capacity Scheduler
4. Work Orders
5. Material Kitting & Issue
6. Job Cards & Shift Execution
7. Machines, OEE & Downtime
8. Production Entry & Reconciliation
9. Wastage & Scrap
10. In-Process Quality
11. Final Quality & FG Release
12. Deviation, Rework & CAPA
13. Batch Genealogy
14. Access Control
15. Space Connectivity

## Interactive functions

- Create production demand, plan and work order records
- Run an MRP visual calculation and approve/freeze plans
- Drag work orders across compatible machines and dates
- Prevent routing-incompatible and maintenance-blocked scheduling
- Drag released material lots into a work-order issue lane
- Start, pause and complete job cards
- Record output, rework, rejection and consumption
- Log machine downtime and update machine status
- Record wastage/scrap with disposition
- Perform IPQC decisions and release process holds
- Perform final inspection and release finished batches
- Create deviations, rework actions and CAPA records
- Trace raw-material lots through jobs, machines, QC and finished batch
- Grant temporary particular-user Allow/Deny access within delegation ceilings
- Simulate effective access decisions
- Switch between light/dark themes and hierarchy lenses
- Persist demo data in browser `localStorage`

## Important implementation boundary

This package is a client-ready, working **frontend MVP**. It does not claim to implement production Laravel authentication, database transactions, immutable stock-ledger posting, server-side policies, queues, machine integrations, scanners or accounting integrations. The included architecture documents map those backend responsibilities explicitly.
