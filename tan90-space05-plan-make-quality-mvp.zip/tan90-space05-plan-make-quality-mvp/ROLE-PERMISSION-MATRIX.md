# Forge Role and Permission Matrix

## Hierarchy model

| Level | Role family | Can manage | Typical scope |
|---|---|---|---|
| L1 | Super Administrator | All lower levels, global policies and direct grants | Organisation |
| L2 | Head of Manufacturing | Manufacturing managers, vertical roles and dashboard policy | Manufacturing vertical / multiple plants |
| L3 | Production, Quality, Maintenance Managers | Their teams, subordinate roles, selected direct grants | Plant + function + teams |
| L4 | Planner, Supervisor, Operator, QC Executive, Technician | Own work and permitted personal dashboard | Assigned plant/line/shift/records |

## Permission catalogue

| Domain | Permission | L1 | Head | Production Manager | Quality Manager | Maintenance Manager | Typical L4 |
|---|---|---:|---:|---:|---:|---:|---|
| Dashboard | `forge.dashboard.view` | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Demand | `forge.demand.view` | ✓ | ✓ | ✓ | ✓ | — | Planner |
| Planning | `forge.plan.create` | ✓ | ✓ | ✓ | — | — | Planner |
| Planning | `forge.plan.approve` | ✓ | ✓ | ✓ | — | — | — |
| MRP | `forge.mrp.run` | ✓ | ✓ | ✓ | — | — | Planner |
| Capacity | `forge.capacity.schedule` | ✓ | ✓ | ✓ | — | ✓ | Planner |
| Work order | `forge.workorder.create` | ✓ | ✓ | ✓ | limited | — | Planner/Supervisor |
| Work order | `forge.workorder.release` | ✓ | ✓ | ✓ | — | — | — |
| Material | `forge.material.reserve` | ✓ | ✓ | ✓ | — | — | Supervisor |
| Material | `forge.material.issue` | ✓ | ✓ | ✓ | — | — | Supervisor by scope |
| Job | `forge.jobcard.start` | ✓ | ✓ | ✓ | — | — | Supervisor/Operator |
| Job | `forge.jobcard.record` | ✓ | ✓ | ✓ | — | — | Supervisor/Operator |
| Job | `forge.jobcard.complete` | ✓ | ✓ | ✓ | — | — | Supervisor/Operator by policy |
| Machine | `forge.machine.view` | ✓ | ✓ | ✓ | ✓ | ✓ | Assigned operational users |
| Machine | `forge.machine.status` | ✓ | ✓ | ✓ | — | ✓ | Supervisor/Technician |
| Machine | `forge.machine.downtime` | ✓ | ✓ | ✓ | — | ✓ | Supervisor/Technician |
| Production | `forge.production.record` | ✓ | ✓ | ✓ | limited | — | Supervisor/Operator |
| Production | `forge.production.approve` | ✓ | ✓ | ✓ | — | — | — |
| Scrap | `forge.scrap.record` | ✓ | ✓ | ✓ | ✓ | — | Supervisor/Operator |
| Scrap | `forge.scrap.approve` | ✓ | ✓ | ✓ | limited | — | — |
| IPQC | `forge.ipqc.inspect` | ✓ | ✓ | limited | ✓ | — | QC Executive |
| IPQC | `forge.ipqc.release` | ✓ | ✓ | — | ✓ | — | — |
| Final QC | `forge.finalqc.inspect` | ✓ | ✓ | — | ✓ | — | QC Executive |
| Final QC | `forge.finalqc.release` | ✓ | ✓ | — | ✓ | — | — |
| Deviation | `forge.deviation.create` | ✓ | ✓ | ✓ | ✓ | ✓ | Relevant L4 |
| Deviation | `forge.deviation.approve` | ✓ | ✓ | — | ✓ | limited | — |
| Rework | `forge.rework.manage` | ✓ | ✓ | ✓ | ✓ | — | Assigned supervisor/QC |
| CAPA | `forge.capa.manage` | ✓ | ✓ | limited | ✓ | ✓ | Assigned action owner |
| Trace | `forge.batch.trace` | ✓ | ✓ | ✓ | ✓ | limited | Assigned records/read scope |
| Access | `forge.access.grant` | ✓ | bounded | bounded | bounded | bounded | — |
| Audit | `forge.audit.view` | ✓ | ✓ | ✓ | ✓ | ✓ | own activity only |

`limited` means read or workflow-participant access under a narrow scope, not full approval authority.

## Data scopes

- organisation
- manufacturing vertical
- plant
- work centre/line
- machine
- team
- shift
- assigned work order/job/inspection
- created-by-me
- temporary date range

## Direct user overrides

A manager can add a particular-user Allow or Deny without editing the shared role when all rules pass:

1. Target is a real subordinate.
2. Permission is inside the manager's effective access.
3. Permission is marked delegable.
4. Requested data scope is no broader than the manager's scope.
5. Parent-locked denial cannot be overridden.
6. Reason is mandatory.
7. Temporary access has expiry.
8. Grant, use and revoke actions are audited.

A direct deny takes precedence over role allows. A direct allow cannot exceed the hierarchy/delegation ceiling.
