# Tan90 Forge Architecture

## 1. Space purpose

Forge is the manufacturing execution space between governed product definitions/material availability and finished-goods release. It combines related capabilities so a user follows one continuous work-order context instead of switching between disconnected modules.

### Inbound contracts

- **Pulse:** demand priority, task ownership, SLA and exception signals
- **Nexus:** identity, hierarchy, roles, data scope and delegation ceiling
- **Blueprint:** released SKU, recipe, BOM, routing, quality specification and standard cost
- **Origin:** quality-released raw-material lots, warehouse/bin and available quantity

### Outbound contracts

- **Pulse:** holds, downtime alerts, approval tasks, deviations and exceptions
- **Origin:** material issue, return, consumption, scrap and lot exposure
- **Flow:** released finished batch, quantity, shelf-life, packaging and release status
- **Lens:** actual consumption, labour, machine time, yield, scrap, variance and genealogy events

## 2. Bounded capabilities

### Planning domain

- Demand intake
- Production-plan versioning
- MRP net requirement
- Finite capacity schedule
- Work-order authorisation

### Execution domain

- Material reservation and issue
- Digital job cards
- Shift execution
- Process parameters
- Output and consumption recording
- Work-order reconciliation

### Asset domain

- Machine/work-centre state
- OEE components
- Downtime and reason coding
- Maintenance blocks
- Condition evidence

### Quality domain

- Line clearance
- IPQC sampling and process holds
- Final inspection
- Accepted/rejected/rework disposition
- Deviation, non-conformance and CAPA

### Traceability domain

- Definition versions used
- Issued raw lots
- Work order and job cards
- Machine, operator and shift
- Process/quality evidence
- Finished batch and warehouse release

## 3. Recommended backend shape

Keep Forge as a Laravel modular-monolith bounded context rather than a separate application initially.

```text
app/Domains/Forge/
  Planning/
  WorkOrders/
  MaterialExecution/
  JobExecution/
  Machines/
  Production/
  Quality/
  Deviations/
  Traceability/
```

Each subdomain should contain application actions, policies, DTOs, domain services and events. Existing Tan90 pages should remain available while new advanced users are routed to Forge through feature flags/access mode.

## 4. Core aggregate ownership

| Aggregate | Authoritative space | Forge responsibility |
|---|---|---|
| Product/BOM/Recipe/Routing | Blueprint | Read released immutable revision |
| Raw-material stock/lot | Origin | Reserve, issue, return and consume through ledger commands |
| Production plan | Forge | Create, approve, freeze and version |
| Work order | Forge | Full lifecycle ownership |
| Job card | Forge | Execution state and evidence |
| Machine master | Blueprint/Nexus setup | Operational state and downtime events in Forge |
| Quality specification | Blueprint | Execute released tests and record results |
| Finished batch | Forge until release | Create genealogy and publish released receipt to Flow |
| Dispatch/customer exposure | Flow | Read for forward traceability |

## 5. Work-order state machine

```text
Draft
  → Material/definition/capacity validation
  → Released
  → Material reserved
  → Material issued
  → In progress
  → Production reconciliation
  → Final QC pending
  → Released to FG / Rework / Rejected
  → Closed
```

Transitions are commands, not editable status fields. Every command validates role, data scope, current state, released definitions, quantity balance and required evidence.

## 6. Inventory and genealogy rules

Forge must never directly overwrite a stock balance. Material reserve, issue, return, consumption, scrap and finished output create immutable inventory transactions through Origin/Flow contracts. Every quantity event stores:

- item and internal lot
- vendor lot where relevant
- plant, warehouse, bin and work centre
- work order/job card
- transaction type and quantity/UOM
- actor and timestamp
- source document and idempotency key
- reason/evidence

A finished batch cannot release until the genealogy completeness policy passes.

## 7. Access-control model

Forge uses hierarchical RBAC plus data scopes and direct user overrides.

```text
L1 Super Administrator
  ↓
L2 Head of Manufacturing
  ↓
L3 Production / Quality / Maintenance Manager
  ↓
L4 Planner / Supervisor / Operator / QC / Technician
```

Permission examples:

```text
forge.plan.approve
forge.capacity.schedule
forge.workorder.release
forge.material.issue
forge.jobcard.record
forge.machine.downtime
forge.production.approve
forge.ipqc.release
forge.finalqc.release
forge.deviation.approve
forge.batch.trace
```

Resolution order:

1. Active identity and advanced-access mode
2. Parent hierarchy/delegation ceiling
3. Direct user deny
4. Role deny
5. Direct user allow
6. Role allow/inheritance
7. Plant, line, shift, team and record scope
8. Object state/business rule
9. Final allow; otherwise default deny

The backend must enforce this sequence on every request. UI visibility is only a usability aid.

## 8. Event contracts

Representative domain events:

```text
production.plan.approved
work_order.released
material.reserved
material.issued
job.started
process.parameter.recorded
machine.downtime.started
ipqc.hold.created
production.output.recorded
scrap.recorded
finished_batch.released
deviation.opened
capa.closed
```

Events should use an outbox table and idempotent consumers for cross-space projections.

## 9. Non-functional requirements

- transaction-safe quantity posting
- optimistic locking for plan/work-order revisions
- idempotent scanner/API commands
- immutable audit events
- plant-timezone aware timestamps
- offline-tolerant operator capture with controlled sync
- role and scope checks in policies/services
- accessible responsive UI
- exportable genealogy evidence
- production metrics computed from authoritative events, not manually edited KPI fields
